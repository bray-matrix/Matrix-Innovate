import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dataSourceRouter from "./data-source";
import aiRouter from "./ai";
import entitiesRouter from "./entities";
import jiraRouter from "./jira";
import platformAuthRouter from "./platform-auth";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dataSourceRouter);
router.use(aiRouter);
router.use(entitiesRouter);
router.use(jiraRouter);
router.use(platformAuthRouter);

export default router;
