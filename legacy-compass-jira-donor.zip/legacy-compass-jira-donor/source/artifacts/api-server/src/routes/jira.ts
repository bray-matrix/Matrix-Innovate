// Read-only Jira connector endpoints. The browser reaches Jira data ONLY through
// these endpoints — it never holds Jira credentials or calls Jira directly.
//
// Reads come from PostgreSQL via the server-side Jira repositories. The single
// write path (POST /sync) runs the connector and upserts into PostgreSQL. Full
// errors are logged via req.log; only short, credential-free messages are
// returned. Drizzle rows are mapped through the generated zod response parsers,
// which strip persistence-only columns and validate the wire shape.
import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import {
  GetJiraStatusResponse,
  ListJiraProjectsResponse,
  GetJiraProjectResponse,
  ListJiraIssuesResponse,
  GetJiraIssueResponse,
  RunJiraSyncResponse,
  GetJiraConfigResponse,
  UpdateJiraConfigBody,
  UpdateJiraConfigResponse,
  TestJiraConnectionResponse,
  DiscoverJiraProjectsResponse,
  ListJiraDiscoveredProjectsResponse,
  DiscoverJiraFieldsResponse,
  ListJiraDiscoveredFieldsResponse,
  GetJiraProjectMappingsResponse,
  UpdateJiraProjectMappingsBody,
  UpdateJiraProjectMappingsResponse,
  GetJiraFieldMappingsResponse,
  UpdateJiraFieldMappingsBody,
  UpdateJiraFieldMappingsResponse,
  GetJiraStatusMappingsResponse,
  UpdateJiraStatusMappingsBody,
  UpdateJiraStatusMappingsResponse,
  GetJiraSyncSettingsResponse,
  UpdateJiraSyncSettingsBody,
  UpdateJiraSyncSettingsResponse,
  ListJiraSyncRunsResponse,
  GetJiraDiagnosticsResponse,
  ListJiraSnapshotsResponse,
  ListJiraProjectMetricsResponse,
} from "@workspace/api-zod";
import {
  jiraProjectRepository,
  jiraIssueRepository,
  jiraSyncRepository,
  jiraConfigRepository,
  jiraSyncSettingsRepository,
  jiraDiscoveredProjectRepository,
  jiraDiscoveredFieldRepository,
  jiraProjectMappingRepository,
  jiraFieldMappingRepository,
  jiraStatusMappingRepository,
  jiraSnapshotRepository,
  jiraProjectMetricRepository,
} from "../repositories/jira";
import { computeServerMetrics } from "../services/jira/intelligence";
import {
  isJiraConfigured,
  getJiraBaseUrl,
  getEffectiveJiraConfig,
} from "../services/jira/config";
import {
  probeJira,
  testConnection,
  discoverProjects,
  discoverFields,
} from "../services/jira/connector";
import { runJiraSync } from "../services/jira/sync";

const router: IRouter = Router();

// Default sync settings surfaced when no settings row has been saved yet.
const DEFAULT_SYNC_SETTINGS = {
  autoSyncEnabled: false,
  syncFrequency: "manual",
  maxIssuesPerRun: 500,
  syncMode: "full",
  issueTypes: [] as string[],
};

// A short, credential-free hint that a token is stored. Never derived from the
// token's own characters, so it can never leak any part of the secret.
function tokenHint(hasToken: boolean): string | null {
  return hasToken ? "••••••••" : null;
}

// Build the browser-safe config view. The api token is NEVER included.
async function buildConfigWire() {
  const row = await jiraConfigRepository.getConfig();
  const effective = await getEffectiveJiraConfig();
  const envConfigured = isJiraConfigured();
  const hasApiToken = Boolean(row?.apiToken) || envConfigured;
  return {
    baseUrl: row?.baseUrl ?? getJiraBaseUrl(),
    email: row?.email ?? null,
    enabled: row?.enabled ?? envConfigured,
    hasApiToken,
    apiTokenHint: tokenHint(hasApiToken),
    source: effective?.source ?? "none",
    serverTitle: row?.serverTitle ?? null,
    authenticatedUser: row?.authenticatedUser ?? null,
    lastTestAt: row?.lastTestAt ?? null,
    lastTestOk: row?.lastTestOk ?? null,
    lastTestMessage: row?.lastTestMessage ?? null,
  };
}

// Map a sync-run row (or null) to the wire JiraSyncRun shape.
function syncRunToWire(run: Awaited<ReturnType<typeof jiraSyncRepository.getLastSync>>) {
  if (!run) return null;
  return {
    id: run.id,
    syncStartedAt: run.syncStartedAt,
    syncCompletedAt: run.syncCompletedAt,
    status: run.status,
    recordsProcessed: run.recordsProcessed,
    recordsCreated: run.recordsCreated,
    recordsUpdated: run.recordsUpdated,
    errorMessage: run.errorMessage,
  };
}

// GET /jira/status — honest connector + persistence status.
router.get("/jira/status", async (req, res) => {
  const effective = await getEffectiveJiraConfig();
  const configured = effective !== null;
  const baseUrl = effective?.baseUrl ?? getJiraBaseUrl();
  try {
    const [reachable, projectCount, issueCount, lastSync] = await Promise.all([
      configured ? probeJira(req.log) : Promise.resolve(false),
      jiraProjectRepository.countProjects(),
      jiraIssueRepository.countIssues(),
      jiraSyncRepository.getLastSync(),
    ]);
    const message = configured
      ? reachable
        ? "Jira connector is configured and reachable."
        : "Jira credentials are configured but Jira could not be reached."
      : "Jira is not configured — sync uses sample connector data.";
    res.json(
      GetJiraStatusResponse.parse({
        configured,
        reachable,
        usingSampleData: !configured,
        message,
        checkedAt: new Date().toISOString(),
        baseUrl,
        projectCount,
        issueCount,
        lastSync: syncRunToWire(lastSync),
      }),
    );
  } catch (err) {
    req.log.error({ err }, "jira status failed");
    res.json(
      GetJiraStatusResponse.parse({
        configured,
        reachable: false,
        usingSampleData: !configured,
        message: "Could not read Jira status.",
        checkedAt: new Date().toISOString(),
        baseUrl,
        projectCount: 0,
        issueCount: 0,
        lastSync: null,
      }),
    );
  }
});

// GET /jira/projects
router.get("/jira/projects", async (req, res) => {
  try {
    const rows = await jiraProjectRepository.listProjects();
    res.json(ListJiraProjectsResponse.parse(rows));
  } catch (err) {
    req.log.error({ err }, "list jira projects failed");
    res.json(ListJiraProjectsResponse.parse([]));
  }
});

// GET /jira/projects/:id
router.get("/jira/projects/:id", async (req, res) => {
  try {
    const row = await jiraProjectRepository.getProject(req.params.id);
    if (!row) {
      res.status(404).json({ message: `No Jira project with id "${req.params.id}".` });
      return;
    }
    res.json(GetJiraProjectResponse.parse(row));
  } catch (err) {
    req.log.error({ err }, "get jira project failed");
    res.status(404).json({ message: "Jira project not found." });
  }
});

// GET /jira/issues?projectKey=&status=
router.get("/jira/issues", async (req, res) => {
  try {
    const projectKey = typeof req.query.projectKey === "string" ? req.query.projectKey : undefined;
    const status = typeof req.query.status === "string" ? req.query.status : undefined;
    const rows = await jiraIssueRepository.listIssues({ projectKey, status });
    res.json(ListJiraIssuesResponse.parse(rows));
  } catch (err) {
    req.log.error({ err }, "list jira issues failed");
    res.json(ListJiraIssuesResponse.parse([]));
  }
});

// GET /jira/issues/:id
router.get("/jira/issues/:id", async (req, res) => {
  try {
    const row = await jiraIssueRepository.getIssue(req.params.id);
    if (!row) {
      res.status(404).json({ message: `No Jira issue with id "${req.params.id}".` });
      return;
    }
    res.json(GetJiraIssueResponse.parse(row));
  } catch (err) {
    req.log.error({ err }, "get jira issue failed");
    res.status(404).json({ message: "Jira issue not found." });
  }
});

// POST /jira/sync — run the connector and upsert into PostgreSQL.
router.post("/jira/sync", async (req, res) => {
  try {
    const outcome = await runJiraSync(req.log);
    if (!outcome) {
      res.status(503).json({
        message: "Sync unavailable: PostgreSQL (DATABASE_URL) is not configured.",
      });
      return;
    }
    res.json(RunJiraSyncResponse.parse(outcome));
  } catch (err) {
    req.log.error({ err }, "jira sync route failed");
    res.status(503).json({ message: "Sync failed. See server logs for details." });
  }
});

// --- T022.5: configuration, discovery, mappings, settings, diagnostics --------

// GET /jira/config — browser-safe config (token never returned).
router.get("/jira/config", async (req, res) => {
  try {
    res.json(GetJiraConfigResponse.parse(await buildConfigWire()));
  } catch (err) {
    req.log.error({ err }, "get jira config failed");
    res.status(500).json({ message: "Could not read Jira configuration." });
  }
});

// PUT /jira/config — persist config server-side. The token is stored only when a
// non-empty value is supplied and is never echoed back.
router.put("/jira/config", async (req, res) => {
  const parsed = UpdateJiraConfigBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid Jira configuration payload." });
    return;
  }
  try {
    await jiraConfigRepository.saveConfig({
      baseUrl: parsed.data.baseUrl,
      email: parsed.data.email,
      apiToken: parsed.data.apiToken,
      enabled: parsed.data.enabled,
    });
    res.json(UpdateJiraConfigResponse.parse(await buildConfigWire()));
  } catch (err) {
    req.log.error({ err }, "save jira config failed");
    res.status(503).json({ message: "Could not save Jira configuration (PostgreSQL required)." });
  }
});

// POST /jira/config/test — probe Jira; records the outcome for diagnostics.
router.post("/jira/config/test", async (req, res) => {
  try {
    const result = await testConnection(req.log);
    await jiraConfigRepository.recordTest({
      ok: result.ok,
      message: result.message,
      authenticatedUser: result.authenticatedUser,
      serverTitle: result.serverTitle,
    });
    res.json(
      TestJiraConnectionResponse.parse({
        ok: result.ok,
        configured: !result.usingSampleData,
        usingSampleData: result.usingSampleData,
        message: result.message,
        authenticatedUser: result.authenticatedUser,
        serverTitle: result.serverTitle,
        baseUrl: result.baseUrl,
        checkedAt: new Date().toISOString(),
      }),
    );
  } catch (err) {
    req.log.error({ err }, "jira test connection failed");
    res.status(500).json({ message: "Could not test the Jira connection." });
  }
});

// POST /jira/discover/projects — snapshot the project catalog.
router.post("/jira/discover/projects", async (req, res) => {
  try {
    const { projects } = await discoverProjects(req.log);
    const discoveredAt = new Date().toISOString();
    const rows = projects.map((p) => ({
      id: `JIRA-DPROJ-${p.jiraProjectId}`,
      jiraProjectId: p.jiraProjectId,
      jiraProjectKey: p.jiraProjectKey,
      jiraProjectName: p.jiraProjectName,
      projectType: p.projectType,
      leadName: p.leadName,
      status: p.isActive ? "active" : "archived",
      discoveredAt,
    }));
    const saved = await jiraDiscoveredProjectRepository.replaceAll(rows);
    res.json(DiscoverJiraProjectsResponse.parse(saved));
  } catch (err) {
    req.log.error({ err }, "discover jira projects failed");
    res.status(503).json({ message: "Could not discover Jira projects (PostgreSQL required)." });
  }
});

// GET /jira/discovered-projects — last project snapshot.
router.get("/jira/discovered-projects", async (req, res) => {
  try {
    res.json(ListJiraDiscoveredProjectsResponse.parse(await jiraDiscoveredProjectRepository.list()));
  } catch (err) {
    req.log.error({ err }, "list discovered jira projects failed");
    res.json(ListJiraDiscoveredProjectsResponse.parse([]));
  }
});

// POST /jira/discover/fields — snapshot the field catalog.
router.post("/jira/discover/fields", async (req, res) => {
  try {
    const { fields } = await discoverFields(req.log);
    const discoveredAt = new Date().toISOString();
    const rows = fields.map((f) => ({
      id: `JIRA-FIELD-${f.fieldId}`,
      fieldId: f.fieldId,
      name: f.name,
      fieldType: f.fieldType,
      custom: f.custom,
      discoveredAt,
    }));
    const saved = await jiraDiscoveredFieldRepository.replaceAll(rows);
    res.json(DiscoverJiraFieldsResponse.parse(saved));
  } catch (err) {
    req.log.error({ err }, "discover jira fields failed");
    res.status(503).json({ message: "Could not discover Jira fields (PostgreSQL required)." });
  }
});

// GET /jira/discovered-fields — last field snapshot.
router.get("/jira/discovered-fields", async (req, res) => {
  try {
    res.json(ListJiraDiscoveredFieldsResponse.parse(await jiraDiscoveredFieldRepository.list()));
  } catch (err) {
    req.log.error({ err }, "list discovered jira fields failed");
    res.json(ListJiraDiscoveredFieldsResponse.parse([]));
  }
});

// GET /jira/project-mappings
router.get("/jira/project-mappings", async (req, res) => {
  try {
    res.json(GetJiraProjectMappingsResponse.parse(await jiraProjectMappingRepository.list()));
  } catch (err) {
    req.log.error({ err }, "list jira project mappings failed");
    res.json(GetJiraProjectMappingsResponse.parse([]));
  }
});

// PUT /jira/project-mappings — authoritative replace of the selection set.
router.put("/jira/project-mappings", async (req, res) => {
  const parsed = UpdateJiraProjectMappingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid project mappings payload." });
    return;
  }
  try {
    const rows = parsed.data.map((m) => ({
      id: m.jiraProjectKey,
      jiraProjectKey: m.jiraProjectKey,
      selected: m.selected,
      matrixProgramId: m.matrixProgramId ?? null,
      matrixPortfolioCategory: m.matrixPortfolioCategory ?? null,
    }));
    const saved = await jiraProjectMappingRepository.replaceAll(rows);
    res.json(UpdateJiraProjectMappingsResponse.parse(saved));
  } catch (err) {
    req.log.error({ err }, "save jira project mappings failed");
    res.status(503).json({ message: "Could not save project mappings (PostgreSQL required)." });
  }
});

// GET /jira/field-mappings
router.get("/jira/field-mappings", async (req, res) => {
  try {
    res.json(GetJiraFieldMappingsResponse.parse(await jiraFieldMappingRepository.list()));
  } catch (err) {
    req.log.error({ err }, "list jira field mappings failed");
    res.json(GetJiraFieldMappingsResponse.parse([]));
  }
});

// PUT /jira/field-mappings — authoritative replace.
router.put("/jira/field-mappings", async (req, res) => {
  const parsed = UpdateJiraFieldMappingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid field mappings payload." });
    return;
  }
  try {
    const rows = parsed.data.map((m) => ({
      id: m.matrixConcept,
      matrixConcept: m.matrixConcept,
      jiraFieldId: m.jiraFieldId ?? null,
      jiraFieldName: m.jiraFieldName ?? null,
    }));
    const saved = await jiraFieldMappingRepository.replaceAll(rows);
    res.json(UpdateJiraFieldMappingsResponse.parse(saved));
  } catch (err) {
    req.log.error({ err }, "save jira field mappings failed");
    res.status(503).json({ message: "Could not save field mappings (PostgreSQL required)." });
  }
});

// GET /jira/status-mappings
router.get("/jira/status-mappings", async (req, res) => {
  try {
    res.json(GetJiraStatusMappingsResponse.parse(await jiraStatusMappingRepository.list()));
  } catch (err) {
    req.log.error({ err }, "list jira status mappings failed");
    res.json(GetJiraStatusMappingsResponse.parse([]));
  }
});

// PUT /jira/status-mappings — authoritative replace.
router.put("/jira/status-mappings", async (req, res) => {
  const parsed = UpdateJiraStatusMappingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid status mappings payload." });
    return;
  }
  try {
    const rows = parsed.data.map((m) => ({
      id: `JIRA-STATUS-${m.jiraStatus.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
      jiraStatus: m.jiraStatus,
      matrixStatus: m.matrixStatus,
    }));
    const saved = await jiraStatusMappingRepository.replaceAll(rows);
    res.json(UpdateJiraStatusMappingsResponse.parse(saved));
  } catch (err) {
    req.log.error({ err }, "save jira status mappings failed");
    res.status(503).json({ message: "Could not save status mappings (PostgreSQL required)." });
  }
});

// GET /jira/sync-settings — returns saved settings, or defaults when unset.
router.get("/jira/sync-settings", async (req, res) => {
  try {
    const row = await jiraSyncSettingsRepository.getSettings();
    const wire = row
      ? {
          autoSyncEnabled: row.autoSyncEnabled,
          syncFrequency: row.syncFrequency,
          maxIssuesPerRun: row.maxIssuesPerRun,
          syncMode: row.syncMode,
          issueTypes: row.issueTypes,
        }
      : DEFAULT_SYNC_SETTINGS;
    res.json(GetJiraSyncSettingsResponse.parse(wire));
  } catch (err) {
    req.log.error({ err }, "get jira sync settings failed");
    res.json(GetJiraSyncSettingsResponse.parse(DEFAULT_SYNC_SETTINGS));
  }
});

// PUT /jira/sync-settings
router.put("/jira/sync-settings", async (req, res) => {
  const parsed = UpdateJiraSyncSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid sync settings payload." });
    return;
  }
  try {
    const saved = await jiraSyncSettingsRepository.saveSettings({
      autoSyncEnabled: parsed.data.autoSyncEnabled,
      syncFrequency: parsed.data.syncFrequency,
      maxIssuesPerRun: parsed.data.maxIssuesPerRun,
      syncMode: parsed.data.syncMode,
      issueTypes: parsed.data.issueTypes,
    });
    res.json(
      UpdateJiraSyncSettingsResponse.parse({
        autoSyncEnabled: saved.autoSyncEnabled,
        syncFrequency: saved.syncFrequency,
        maxIssuesPerRun: saved.maxIssuesPerRun,
        syncMode: saved.syncMode,
        issueTypes: saved.issueTypes,
      }),
    );
  } catch (err) {
    req.log.error({ err }, "save jira sync settings failed");
    res.status(503).json({ message: "Could not save sync settings (PostgreSQL required)." });
  }
});

// GET /jira/sync-runs?limit= — sync history, newest first.
router.get("/jira/sync-runs", async (req, res) => {
  try {
    const limit =
      typeof req.query.limit === "string" ? Math.max(1, Math.min(100, Number(req.query.limit) || 10)) : 10;
    const rows = await jiraSyncRepository.listSyncRuns(limit);
    res.json(ListJiraSyncRunsResponse.parse(rows.map(syncRunToWire)));
  } catch (err) {
    req.log.error({ err }, "list jira sync runs failed");
    res.json(ListJiraSyncRunsResponse.parse([]));
  }
});

// GET /jira/diagnostics — aggregated sync diagnostics + executive health rollup.
router.get("/jira/diagnostics", async (req, res) => {
  try {
    const [lastSync, lastSuccess, lastFail, totalRuns, projectCount, issueCount, recent, projects, issues] =
      await Promise.all([
        jiraSyncRepository.getLastSync(),
        jiraSyncRepository.getLastSyncByStatus("completed"),
        jiraSyncRepository.getLastSyncByStatus("failed"),
        jiraSyncRepository.countRuns(),
        jiraProjectRepository.countProjects(),
        jiraIssueRepository.countIssues(),
        jiraSyncRepository.listSyncRuns(10),
        jiraProjectRepository.listProjects(),
        jiraIssueRepository.listIssues(),
      ]);
    const metrics = computeServerMetrics(projects, issues);
    // Duration of the most recent successful sync, if both timestamps exist.
    let lastSyncDurationMs: number | null = null;
    if (lastSuccess?.syncStartedAt && lastSuccess.syncCompletedAt) {
      const start = Date.parse(lastSuccess.syncStartedAt);
      const end = Date.parse(lastSuccess.syncCompletedAt);
      if (!Number.isNaN(start) && !Number.isNaN(end) && end >= start) {
        lastSyncDurationMs = end - start;
      }
    }
    res.json(
      GetJiraDiagnosticsResponse.parse({
        lastSync: syncRunToWire(lastSync),
        lastSuccessfulSync: syncRunToWire(lastSuccess),
        lastFailedSync: syncRunToWire(lastFail),
        totalRuns,
        projectsImported: projectCount,
        issuesImported: issueCount,
        openIssues: metrics.summary.openIssues,
        completedIssues: metrics.summary.completedIssues,
        blockedIssues: metrics.summary.blockedIssues,
        overdueIssues: metrics.summary.overdueIssues,
        criticalIssues: metrics.summary.criticalIssues,
        healthScore: metrics.healthScore,
        lastSyncDurationMs,
        recentRuns: recent.map(syncRunToWire),
      }),
    );
  } catch (err) {
    req.log.error({ err }, "jira diagnostics failed");
    res.status(500).json({ message: "Could not read Jira diagnostics." });
  }
});

// GET /jira/snapshots?limit= — persisted portfolio snapshots (trend framework).
router.get("/jira/snapshots", async (req, res) => {
  try {
    const limit =
      typeof req.query.limit === "string"
        ? Math.max(1, Math.min(200, Number(req.query.limit) || 30))
        : 30;
    const rows = await jiraSnapshotRepository.list(limit);
    res.json(
      ListJiraSnapshotsResponse.parse(
        rows.map((r) => ({
          id: r.id,
          capturedAt: r.capturedAt.toISOString(),
          syncRunId: r.syncRunId,
          projectCount: r.projectCount,
          issueCount: r.issueCount,
          openCount: r.openCount,
          completedCount: r.completedCount,
          blockedCount: r.blockedCount,
          criticalCount: r.criticalCount,
          overdueCount: r.overdueCount,
          highestPriorityCount: r.highestPriorityCount,
          highPriorityCount: r.highPriorityCount,
          mediumPriorityCount: r.mediumPriorityCount,
          lowPriorityCount: r.lowPriorityCount,
          healthScore: r.healthScore,
        })),
      ),
    );
  } catch (err) {
    req.log.error({ err }, "list jira snapshots failed");
    res.json(ListJiraSnapshotsResponse.parse([]));
  }
});

// GET /jira/project-metrics — persisted per-project executive metrics.
router.get("/jira/project-metrics", async (req, res) => {
  try {
    const rows = await jiraProjectMetricRepository.list();
    res.json(
      ListJiraProjectMetricsResponse.parse(
        rows.map((r) => ({
          id: r.id,
          jiraProjectKey: r.jiraProjectKey,
          jiraProjectName: r.jiraProjectName,
          issueCount: r.issueCount,
          openCount: r.openCount,
          completedCount: r.completedCount,
          blockedCount: r.blockedCount,
          criticalCount: r.criticalCount,
          overdueCount: r.overdueCount,
          highPriorityOpenCount: r.highPriorityOpenCount,
          openStoryPoints: r.openStoryPoints,
          todoCount: r.todoCount,
          inProgressCount: r.inProgressCount,
          doneCount: r.doneCount,
          healthClass: r.healthClass,
          healthScore: r.healthScore,
          lastActivity: r.lastActivity,
          staleDays: r.staleDays,
          isStale: r.isStale,
          capturedAt: r.capturedAt.toISOString(),
        })),
      ),
    );
  } catch (err) {
    req.log.error({ err }, "list jira project metrics failed");
    res.json(ListJiraProjectMetricsResponse.parse([]));
  }
});

export default router;
