// Jira connector configuration. All credentials are server-side env vars only —
// they are NEVER sent to the browser, logged, or returned in any response.
//
//   JIRA_ENABLED    "true" to use the live Jira connector (default: off)
//   JIRA_BASE_URL   e.g. https://your-domain.atlassian.net
//   JIRA_EMAIL      Atlassian account email (Basic auth username)
//   JIRA_API_TOKEN  Atlassian API token (Basic auth password)
//
// When any required value is missing (or JIRA_ENABLED is not "true"), the
// connector falls back to sample data so the foundation stays demoable without
// real Jira credentials.

export interface JiraConfig {
  baseUrl: string;
  email: string;
  apiToken: string;
}

function readEnv(name: string): string {
  return (process.env[name] ?? "").trim();
}

// Normalize a Jira base URL: trim, strip trailing slashes, and ensure an
// https:// scheme so `fetch` can form an absolute URL (admins often paste a
// bare host like "your-domain.atlassian.net").
function normalizeBaseUrl(raw: string): string {
  const trimmed = raw.trim().replace(/\/+$/, "");
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

// Configured only when explicitly enabled AND all credentials are present.
export function isJiraConfigured(): boolean {
  if (readEnv("JIRA_ENABLED").toLowerCase() !== "true") return false;
  return Boolean(readEnv("JIRA_BASE_URL") && readEnv("JIRA_EMAIL") && readEnv("JIRA_API_TOKEN"));
}

// Returns the live config, or null when not fully configured. The api token is
// only ever read here and handed to the connector for the Authorization header.
export function getJiraConfig(): JiraConfig | null {
  if (!isJiraConfigured()) return null;
  return {
    baseUrl: normalizeBaseUrl(readEnv("JIRA_BASE_URL")),
    email: readEnv("JIRA_EMAIL"),
    apiToken: readEnv("JIRA_API_TOKEN"),
  };
}

// The base URL is safe to surface (no credentials); used in status only.
export function getJiraBaseUrl(): string | null {
  const url = normalizeBaseUrl(readEnv("JIRA_BASE_URL"));
  return url || null;
}

// --- T022.5: DB-backed config with env fallback ------------------------------
//
// The effective config prefers the saved DB configuration (the connector uses
// whatever the admin saved) and falls back to JIRA_* env when no usable DB row
// exists. The api token is read here only to build the Authorization header — it
// is never returned to callers that surface config to the browser.
import { jiraConfigRepository } from "../../repositories/jira";

export interface EffectiveJiraConfig extends JiraConfig {
  source: "database" | "env";
}

// Returns the connector-usable config (with token) or null when neither the DB
// row nor env is fully configured/enabled.
export async function getEffectiveJiraConfig(): Promise<EffectiveJiraConfig | null> {
  const row = await jiraConfigRepository.getConfig();
  if (
    row &&
    row.enabled &&
    row.baseUrl &&
    row.baseUrl.trim() &&
    row.email &&
    row.email.trim() &&
    row.apiToken &&
    row.apiToken.trim()
  ) {
    return {
      baseUrl: normalizeBaseUrl(row.baseUrl),
      email: row.email,
      apiToken: row.apiToken,
      source: "database",
    };
  }
  const env = getJiraConfig();
  if (env) return { ...env, source: "env" };
  return null;
}

// True when the connector can run live against Jira (DB row or env).
export async function isJiraEffectivelyConfigured(): Promise<boolean> {
  return (await getEffectiveJiraConfig()) !== null;
}

// The effective base URL (DB first, env fallback), safe to surface — no creds.
export async function getEffectiveJiraBaseUrl(): Promise<string | null> {
  const row = await jiraConfigRepository.getConfig();
  if (row?.baseUrl && row.baseUrl.trim()) return row.baseUrl.replace(/\/+$/, "");
  return getJiraBaseUrl();
}
