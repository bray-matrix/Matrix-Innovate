// Sample connector responses (the spec's "sample connector responses"). Used by
// the connector when Jira credentials are not configured so sync can still
// populate PostgreSQL and the foundation stays demoable end-to-end.
//
// These are NORMALIZED rows (already mapped out of Jira's REST shape), matching
// the connector's output contract. IDs are stable so repeated syncs upsert the
// same rows (idempotent).

export interface NormalizedJiraProject {
  jiraProjectId: string;
  jiraProjectKey: string;
  jiraProjectName: string;
  projectType: string | null;
  leadName: string | null;
  leadAccountId: string | null;
  isActive: boolean;
}

export interface NormalizedJiraField {
  fieldId: string;
  name: string;
  fieldType: string | null;
  custom: boolean;
}

export interface JiraServerInfo {
  authenticatedUser: string | null;
  serverTitle: string | null;
}

export interface NormalizedJiraIssue {
  jiraIssueId: string;
  jiraIssueKey: string;
  jiraProjectKey: string;
  summary: string;
  description: string | null;
  issueType: string | null;
  status: string | null;
  priority: string | null;
  assigneeName: string | null;
  assigneeAccountId: string | null;
  reporterName: string | null;
  storyPoints: number | null;
  createdDate: string | null;
  updatedDate: string | null;
  dueDate: string | null;
  resolutionDate: string | null;
  metadata: Record<string, unknown> | null;
}

export const SAMPLE_JIRA_PROJECTS: NormalizedJiraProject[] = [
  {
    jiraProjectId: "10001",
    jiraProjectKey: "MIG",
    jiraProjectName: "Client Migration Program",
    projectType: "software",
    leadName: "Dana Whitfield",
    leadAccountId: "acc-100",
    isActive: true,
  },
  {
    jiraProjectId: "10002",
    jiraProjectKey: "ONB",
    jiraProjectName: "Onboarding & Implementation",
    projectType: "software",
    leadName: "Marcus Lee",
    leadAccountId: "acc-101",
    isActive: true,
  },
  {
    jiraProjectId: "10003",
    jiraProjectKey: "SUP",
    jiraProjectName: "Production Support",
    projectType: "service_desk",
    leadName: "Priya Nair",
    leadAccountId: "acc-102",
    isActive: true,
  },
];

// Sample field catalog (Discover Fields). Mixes system and custom fields so the
// field-mapping UI is demoable. No field id is hardcoded anywhere downstream —
// mappings resolve concepts (e.g. story points) to whichever field id the user
// picks from this catalog.
export const SAMPLE_JIRA_FIELDS: NormalizedJiraField[] = [
  { fieldId: "summary", name: "Summary", fieldType: "string", custom: false },
  { fieldId: "description", name: "Description", fieldType: "string", custom: false },
  { fieldId: "status", name: "Status", fieldType: "status", custom: false },
  { fieldId: "priority", name: "Priority", fieldType: "priority", custom: false },
  { fieldId: "assignee", name: "Assignee", fieldType: "user", custom: false },
  { fieldId: "reporter", name: "Reporter", fieldType: "user", custom: false },
  { fieldId: "duedate", name: "Due date", fieldType: "date", custom: false },
  { fieldId: "customfield_10016", name: "Story Points", fieldType: "number", custom: true },
  { fieldId: "customfield_10020", name: "Sprint", fieldType: "array", custom: true },
  { fieldId: "customfield_10014", name: "Epic Link", fieldType: "string", custom: true },
];

// Sample identity/server info for Test Connection when Jira is not configured.
export const SAMPLE_JIRA_SERVER_INFO: JiraServerInfo = {
  authenticatedUser: "Sample Connector User",
  serverTitle: "Sample Jira Cloud (demo)",
};

export const SAMPLE_JIRA_ISSUES: NormalizedJiraIssue[] = [
  {
    jiraIssueId: "20001",
    jiraIssueKey: "MIG-101",
    jiraProjectKey: "MIG",
    summary: "Data mapping for legacy account import",
    description: "Map legacy CRM fields to the new schema before the cutover.",
    issueType: "Story",
    status: "In Progress",
    priority: "High",
    assigneeName: "Dana Whitfield",
    assigneeAccountId: "acc-100",
    reporterName: "Marcus Lee",
    storyPoints: 8,
    createdDate: "2026-05-02T09:15:00.000Z",
    updatedDate: "2026-06-18T14:30:00.000Z",
    dueDate: "2026-07-01",
    resolutionDate: null,
    metadata: { labels: ["migration", "data"] },
  },
  {
    jiraIssueId: "20002",
    jiraIssueKey: "MIG-102",
    jiraProjectKey: "MIG",
    summary: "Cutover runbook review",
    description: "Review and sign off the production cutover runbook.",
    issueType: "Task",
    status: "To Do",
    priority: "Medium",
    assigneeName: "Priya Nair",
    assigneeAccountId: "acc-102",
    reporterName: "Dana Whitfield",
    storyPoints: 3,
    createdDate: "2026-05-10T11:00:00.000Z",
    updatedDate: "2026-06-12T08:45:00.000Z",
    dueDate: "2026-07-05",
    resolutionDate: null,
    metadata: { labels: ["migration", "runbook"] },
  },
  {
    jiraIssueId: "20003",
    jiraIssueKey: "ONB-210",
    jiraProjectKey: "ONB",
    summary: "Configure tenant SSO",
    description: "Set up SAML SSO for the new client tenant.",
    issueType: "Story",
    status: "Done",
    priority: "High",
    assigneeName: "Marcus Lee",
    assigneeAccountId: "acc-101",
    reporterName: "Priya Nair",
    storyPoints: 5,
    createdDate: "2026-04-20T13:20:00.000Z",
    updatedDate: "2026-05-28T16:10:00.000Z",
    dueDate: "2026-05-25",
    resolutionDate: "2026-05-28T16:10:00.000Z",
    metadata: { labels: ["onboarding", "security"] },
  },
  {
    jiraIssueId: "20004",
    jiraIssueKey: "ONB-211",
    jiraProjectKey: "ONB",
    summary: "Welcome kit content review",
    description: "Review onboarding welcome kit copy with the client success team.",
    issueType: "Task",
    status: "In Progress",
    priority: "Low",
    assigneeName: "Dana Whitfield",
    assigneeAccountId: "acc-100",
    reporterName: "Marcus Lee",
    storyPoints: 2,
    createdDate: "2026-06-01T10:05:00.000Z",
    updatedDate: "2026-06-20T09:00:00.000Z",
    dueDate: "2026-07-10",
    resolutionDate: null,
    metadata: { labels: ["onboarding"] },
  },
  {
    jiraIssueId: "20005",
    jiraIssueKey: "SUP-330",
    jiraProjectKey: "SUP",
    summary: "Investigate elevated API latency",
    description: "P2 incident: API latency spiked after the latest release.",
    issueType: "Bug",
    status: "In Progress",
    priority: "Highest",
    assigneeName: "Priya Nair",
    assigneeAccountId: "acc-102",
    reporterName: "Dana Whitfield",
    storyPoints: null,
    createdDate: "2026-06-19T07:40:00.000Z",
    updatedDate: "2026-06-23T18:25:00.000Z",
    dueDate: null,
    resolutionDate: null,
    metadata: { labels: ["support", "incident"], severity: "P2" },
  },
];
