// Sync orchestration: createSyncRun(running) → connector fetch → upsert →
// updateSyncRun(completed/failed). Idempotent — the repositories upsert by the
// unique Jira id columns, so repeated syncs update existing rows rather than
// duplicating them.
import { randomUUID } from "node:crypto";
import type { Logger } from "pino";
import { isDatabaseConfigured } from "@workspace/db";
import {
  jiraProjectRepository,
  jiraIssueRepository,
  jiraSyncRepository,
  jiraSyncSettingsRepository,
  jiraProjectMappingRepository,
  jiraFieldMappingRepository,
  jiraStatusMappingRepository,
  jiraSnapshotRepository,
  jiraProjectMetricRepository,
} from "../../repositories/jira";
import { buildSnapshotRow, buildProjectMetricRows } from "./intelligence";
import { runConnector } from "./connector";
import type { NormalizedJiraProject, NormalizedJiraIssue } from "./sampleData";

// The Matrix concept used to resolve a Jira story-points field via field mapping.
const STORY_POINTS_CONCEPT = "storyPoints";

export interface SyncOutcome {
  ok: boolean;
  usingSampleData: boolean;
  message: string;
  run: {
    id: string;
    syncStartedAt: string;
    syncCompletedAt: string | null;
    status: string;
    recordsProcessed: number;
    recordsCreated: number;
    recordsUpdated: number;
    errorMessage: string | null;
  };
  projectCount: number;
  issueCount: number;
}

function projectToRow(p: NormalizedJiraProject) {
  return {
    id: `JIRA-PROJ-${p.jiraProjectId}`,
    jiraProjectId: p.jiraProjectId,
    jiraProjectKey: p.jiraProjectKey,
    jiraProjectName: p.jiraProjectName,
    projectType: p.projectType,
    leadName: p.leadName,
    leadAccountId: p.leadAccountId,
    isActive: p.isActive,
  };
}

function issueToRow(i: NormalizedJiraIssue) {
  return {
    id: `JIRA-ISSUE-${i.jiraIssueId}`,
    jiraIssueId: i.jiraIssueId,
    jiraIssueKey: i.jiraIssueKey,
    jiraProjectKey: i.jiraProjectKey,
    summary: i.summary,
    description: i.description,
    issueType: i.issueType,
    status: i.status,
    priority: i.priority,
    assigneeName: i.assigneeName,
    assigneeAccountId: i.assigneeAccountId,
    reporterName: i.reporterName,
    storyPoints: i.storyPoints,
    createdDate: i.createdDate,
    updatedDate: i.updatedDate,
    dueDate: i.dueDate,
    resolutionDate: i.resolutionDate,
    metadataJson: i.metadata,
  };
}

// Returns null when PostgreSQL is not configured — the route maps that to 503,
// since there is nowhere to persist the sync (PG is the system of record).
export async function runJiraSync(log: Logger): Promise<SyncOutcome | null> {
  if (!isDatabaseConfigured()) return null;

  const startedAt = new Date().toISOString();
  const run = await jiraSyncRepository.createSyncRun({
    id: randomUUID(),
    syncStartedAt: startedAt,
    syncCompletedAt: null,
    status: "running",
    recordsProcessed: 0,
    recordsCreated: 0,
    recordsUpdated: 0,
    errorMessage: null,
  });

  try {
    // Load saved configuration: settings (limits/issue types), project selections,
    // and field/status mappings. All are optional — when absent, sync behaves like
    // the original full import (backwards compatible).
    const [settings, projectMappings, fieldMappings, statusMappings] = await Promise.all([
      jiraSyncSettingsRepository.getSettings(),
      jiraProjectMappingRepository.list(),
      jiraFieldMappingRepository.list(),
      jiraStatusMappingRepository.list(),
    ]);

    const maxIssues = settings?.maxIssuesPerRun ?? 0;
    const issueTypeAllow = new Set((settings?.issueTypes ?? []).map((t) => t.toLowerCase()));
    const selectedKeys = new Set(
      projectMappings.filter((m) => m.selected).map((m) => m.jiraProjectKey),
    );
    // Once any project mappings have been saved, they are the authoritative
    // selection scope — even "all unselected" (zero keys) must import nothing.
    // Only when no mappings exist at all do we fall back to importing everything.
    const hasSelection = projectMappings.length > 0;
    const storyPointsFieldId =
      fieldMappings.find((m) => m.matrixConcept === STORY_POINTS_CONCEPT)?.jiraFieldId ?? null;
    const statusMap = new Map(statusMappings.map((m) => [m.jiraStatus, m.matrixStatus]));

    const raw = await runConnector(log, {
      storyPointsFieldId,
      maxIssues,
      // When a selection has been saved, bound the live query to it (empty =
      // import nothing); otherwise leave undefined for a full legacy import.
      projectKeys: hasSelection ? [...selectedKeys] : undefined,
    });
    const usingSampleData = raw.usingSampleData;

    // Filter projects to the admin's selection (if any).
    const projects = hasSelection
      ? raw.projects.filter((p) => selectedKeys.has(p.jiraProjectKey))
      : raw.projects;

    // Filter issues: selected projects + issue-type allow-list. Then translate
    // statuses through the status mapping. maxIssues was already applied upstream.
    const filteredIssues = raw.issues.filter((i) => {
      if (hasSelection && !selectedKeys.has(i.jiraProjectKey)) return false;
      if (issueTypeAllow.size > 0) {
        const type = (i.issueType ?? "").toLowerCase();
        if (!issueTypeAllow.has(type)) return false;
      }
      return true;
    });
    const issues = filteredIssues.map((i) => {
      const mapped = i.status ? statusMap.get(i.status) : undefined;
      return mapped ? { ...i, status: mapped } : i;
    });

    const projectResult = await jiraProjectRepository.upsertProjects(projects.map(projectToRow));
    const issueResult = await jiraIssueRepository.upsertIssues(issues.map(issueToRow));

    const created = projectResult.created + issueResult.created;
    const updated = projectResult.updated + issueResult.updated;
    const processed = projects.length + issues.length;
    const completedAt = new Date().toISOString();

    const updatedRun = await jiraSyncRepository.updateSyncRun(run.id, {
      syncCompletedAt: completedAt,
      status: "completed",
      recordsProcessed: processed,
      recordsCreated: created,
      recordsUpdated: updated,
      errorMessage: null,
    });

    // Persist executive intelligence from the FULL post-upsert portfolio (not
    // just this run's rows) so snapshots and project metrics reflect everything
    // stored. Best-effort: a failure here must not fail an otherwise good sync.
    try {
      const capturedAt = new Date();
      const [allProjects, allIssues] = await Promise.all([
        jiraProjectRepository.listProjects(),
        jiraIssueRepository.listIssues(),
      ]);
      await Promise.all([
        jiraSnapshotRepository.insert(
          buildSnapshotRow(allProjects, allIssues, run.id, capturedAt),
        ),
        jiraProjectMetricRepository.replaceAll(
          buildProjectMetricRows(allProjects, allIssues, capturedAt),
        ),
      ]);
    } catch (intelErr) {
      log.error({ err: intelErr }, "Jira executive intelligence persistence failed");
    }

    const message = usingSampleData
      ? "Sync completed using sample connector data (Jira not configured)."
      : "Sync completed from Jira Cloud.";

    return {
      ok: true,
      usingSampleData,
      message,
      run: {
        id: run.id,
        syncStartedAt: startedAt,
        syncCompletedAt: updatedRun?.syncCompletedAt ?? completedAt,
        status: "completed",
        recordsProcessed: processed,
        recordsCreated: created,
        recordsUpdated: updated,
        errorMessage: null,
      },
      projectCount: projects.length,
      issueCount: issues.length,
    };
  } catch (err) {
    // Log the full error server-side; return only a short, credential-free message.
    log.error({ err }, "Jira sync failed");
    const completedAt = new Date().toISOString();
    await jiraSyncRepository.updateSyncRun(run.id, {
      syncCompletedAt: completedAt,
      status: "failed",
      errorMessage: "Sync failed. See server logs for details.",
    });
    return {
      ok: false,
      usingSampleData: false,
      message: "Sync failed. See server logs for details.",
      run: {
        id: run.id,
        syncStartedAt: startedAt,
        syncCompletedAt: completedAt,
        status: "failed",
        recordsProcessed: 0,
        recordsCreated: 0,
        recordsUpdated: 0,
        errorMessage: "Sync failed. See server logs for details.",
      },
      projectCount: 0,
      issueCount: 0,
    };
  }
}
