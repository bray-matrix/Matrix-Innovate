// Server-side executive intelligence: map persisted Jira rows into the pure
// @workspace/jira-intelligence input shapes, compute, and produce snapshot /
// project-metric insert rows for persistence. The compute itself lives in the
// shared lib so the api-server and the frontend yield identical numbers.
import { randomUUID } from "node:crypto";
import {
  buildSnapshot,
  computeExecutiveMetrics,
  type ExecutiveMetrics,
  type IntelIssue,
  type IntelProject,
} from "@workspace/jira-intelligence";
import type {
  JiraIssueRow,
  JiraProjectRow,
  InsertJiraSyncSnapshot,
  InsertJiraProjectMetric,
} from "@workspace/db";

export function projectRowToIntel(p: JiraProjectRow): IntelProject {
  return { key: p.jiraProjectKey, name: p.jiraProjectName };
}

export function issueRowToIntel(i: JiraIssueRow): IntelIssue {
  return {
    key: i.jiraIssueKey,
    projectKey: i.jiraProjectKey,
    issueType: i.issueType,
    status: i.status,
    priority: i.priority,
    assigneeName: i.assigneeName,
    storyPoints: i.storyPoints,
    createdDate: i.createdDate,
    updatedDate: i.updatedDate,
    dueDate: i.dueDate,
    resolutionDate: i.resolutionDate,
  };
}

export function computeServerMetrics(
  projects: JiraProjectRow[],
  issues: JiraIssueRow[],
  now?: Date,
): ExecutiveMetrics {
  return computeExecutiveMetrics(
    projects.map(projectRowToIntel),
    issues.map(issueRowToIntel),
    now ? { now } : undefined,
  );
}

// Build a snapshot insert row from raw rows (used by sync to persist the trend).
export function buildSnapshotRow(
  projects: JiraProjectRow[],
  issues: JiraIssueRow[],
  syncRunId: string | null,
  capturedAt: Date,
): InsertJiraSyncSnapshot {
  const snap = buildSnapshot(
    projects.map(projectRowToIntel),
    issues.map(issueRowToIntel),
    capturedAt.toISOString(),
    { now: capturedAt },
  );
  return {
    id: `JIRA-SNAP-${randomUUID()}`,
    capturedAt,
    syncRunId,
    projectCount: snap.projectCount,
    issueCount: snap.issueCount,
    openCount: snap.openCount,
    completedCount: snap.completedCount,
    blockedCount: snap.blockedCount,
    criticalCount: snap.criticalCount,
    overdueCount: snap.overdueCount,
    highestPriorityCount: snap.priority.highest,
    highPriorityCount: snap.priority.high,
    mediumPriorityCount: snap.priority.medium,
    lowPriorityCount: snap.priority.low,
    healthScore: snap.healthScore,
  };
}

// Build per-project metric insert rows (full replace each sync).
export function buildProjectMetricRows(
  projects: JiraProjectRow[],
  issues: JiraIssueRow[],
  capturedAt: Date,
): InsertJiraProjectMetric[] {
  const metrics = computeServerMetrics(projects, issues, capturedAt);
  return metrics.projects.map((m) => ({
    id: m.key,
    jiraProjectKey: m.key,
    jiraProjectName: m.name,
    issueCount: m.issueCount,
    openCount: m.openCount,
    completedCount: m.completedCount,
    blockedCount: m.blockedCount,
    criticalCount: m.criticalCount,
    overdueCount: m.overdueCount,
    highPriorityOpenCount: m.highPriorityOpenCount,
    openStoryPoints: m.openStoryPoints,
    todoCount: m.status.todo,
    inProgressCount: m.status.inProgress,
    doneCount: m.status.done,
    healthClass: m.healthClass,
    healthScore: m.healthScore,
    lastActivity: m.lastActivity,
    staleDays: m.staleDays,
    isStale: m.isStale,
    capturedAt,
  }));
}
