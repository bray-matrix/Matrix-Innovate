// Connector layer — the ONLY place that talks to Jira Cloud.
//
// When Jira is configured (JIRA_ENABLED=true + credentials), it pulls projects
// and issues over the Jira Cloud REST API v3 using Basic auth and normalizes
// the responses. Otherwise it returns sample connector responses so sync can
// still run. The API token is used only in the Authorization header and is
// never logged or returned.
import type { Logger } from "pino";
import { getEffectiveJiraConfig, type JiraConfig } from "./config";
import {
  SAMPLE_JIRA_PROJECTS,
  SAMPLE_JIRA_ISSUES,
  SAMPLE_JIRA_FIELDS,
  SAMPLE_JIRA_SERVER_INFO,
  type NormalizedJiraProject,
  type NormalizedJiraIssue,
  type NormalizedJiraField,
  type JiraServerInfo,
} from "./sampleData";

export interface ConnectorResult {
  projects: NormalizedJiraProject[];
  issues: NormalizedJiraIssue[];
  usingSampleData: boolean;
}

export interface TestConnectionResult {
  ok: boolean;
  usingSampleData: boolean;
  authenticatedUser: string | null;
  serverTitle: string | null;
  baseUrl: string | null;
  message: string;
}

function authHeader(config: JiraConfig): string {
  const token = Buffer.from(`${config.email}:${config.apiToken}`).toString("base64");
  return `Basic ${token}`;
}

async function jiraGet<T>(config: JiraConfig, path: string): Promise<T> {
  const res = await fetch(`${config.baseUrl}${path}`, {
    headers: {
      Authorization: authHeader(config),
      Accept: "application/json",
    },
  });
  if (!res.ok) {
    // Include a truncated Jira error body to aid diagnosis. Jira REST error
    // responses describe the request problem (e.g. invalid JQL) and never echo
    // the Authorization header; this error is logged server-side only — routes
    // return a generic message to the browser.
    const body = await res.text().catch(() => "");
    throw new Error(`Jira request failed with status ${res.status}: ${body.slice(0, 400)}`);
  }
  return (await res.json()) as T;
}

// --- Jira REST response shapes (only the fields we read) ----------------------
interface JiraProjectApi {
  id: string;
  key: string;
  name: string;
  projectTypeKey?: string;
  lead?: { displayName?: string; accountId?: string };
  archived?: boolean;
}

interface JiraIssueApi {
  id: string;
  key: string;
  fields?: {
    summary?: string;
    description?: unknown;
    issuetype?: { name?: string };
    status?: { name?: string };
    priority?: { name?: string };
    assignee?: { displayName?: string; accountId?: string } | null;
    reporter?: { displayName?: string } | null;
    created?: string;
    updated?: string;
    duedate?: string | null;
    resolutiondate?: string | null;
    project?: { key?: string };
    [key: string]: unknown;
  };
}

interface JiraSearchApi {
  issues?: JiraIssueApi[];
  // The enhanced search endpoint (/rest/api/3/search/jql) paginates with an
  // opaque token and signals the end with isLast — it does NOT return total.
  nextPageToken?: string;
  isLast?: boolean;
}

function normalizeProject(p: JiraProjectApi): NormalizedJiraProject {
  return {
    jiraProjectId: p.id,
    jiraProjectKey: p.key,
    jiraProjectName: p.name,
    projectType: p.projectTypeKey ?? null,
    leadName: p.lead?.displayName ?? null,
    leadAccountId: p.lead?.accountId ?? null,
    isActive: p.archived !== true,
  };
}

// Jira may return story points in any custom field; we leave it null on the live
// path unless present in a common location, keeping the foundation honest.
// Story points are resolved through the configured field mapping (storyPointsFieldId)
// — no Jira field id is hardcoded. When unmapped or absent, storyPoints stays null.
function normalizeIssue(i: JiraIssueApi, storyPointsFieldId: string | null): NormalizedJiraIssue {
  const f = i.fields ?? {};
  const description =
    typeof f.description === "string" ? f.description : f.description ? "(rich text)" : null;
  let storyPoints: number | null = null;
  if (storyPointsFieldId) {
    const raw = f[storyPointsFieldId];
    if (typeof raw === "number") storyPoints = raw;
  }
  return {
    jiraIssueId: i.id,
    jiraIssueKey: i.key,
    jiraProjectKey: f.project?.key ?? i.key.split("-")[0] ?? "",
    summary: f.summary ?? "(no summary)",
    description,
    issueType: f.issuetype?.name ?? null,
    status: f.status?.name ?? null,
    priority: f.priority?.name ?? null,
    assigneeName: f.assignee?.displayName ?? null,
    assigneeAccountId: f.assignee?.accountId ?? null,
    reporterName: f.reporter?.displayName ?? null,
    storyPoints,
    createdDate: f.created ?? null,
    updatedDate: f.updated ?? null,
    dueDate: f.duedate ?? null,
    resolutionDate: f.resolutiondate ?? null,
    metadata: null,
  };
}

async function fetchLiveProjects(config: JiraConfig): Promise<NormalizedJiraProject[]> {
  const data = await jiraGet<JiraProjectApi[]>(config, "/rest/api/3/project");
  return data.map(normalizeProject);
}

async function fetchLiveIssues(
  config: JiraConfig,
  storyPointsFieldId: string | null,
  maxIssues: number,
  projectKeys: string[] | null,
): Promise<NormalizedJiraIssue[]> {
  // A saved-but-empty selection means "import nothing" — skip the query (an
  // empty `project in ()` clause is also invalid JQL).
  if (projectKeys !== null && projectKeys.length === 0) return [];
  const issues: NormalizedJiraIssue[] = [];
  const maxResults = 100;
  // The enhanced search endpoint returns only issue ids unless `fields` is
  // requested explicitly; list the navigable fields the normalizer reads, plus
  // the (dynamic) story-points custom field when one is mapped.
  const fields = [
    "summary",
    "description",
    "issuetype",
    "status",
    "priority",
    "assignee",
    "reporter",
    "created",
    "updated",
    "duedate",
    "resolutiondate",
    "project",
  ];
  if (storyPointsFieldId) fields.push(storyPointsFieldId);
  const fieldsParam = encodeURIComponent(fields.join(","));
  // The enhanced search endpoint rejects unbounded JQL, so always include a
  // search restriction: scope to the selected projects when a selection exists,
  // otherwise bound by a created-date floor that still matches every issue.
  const restriction =
    projectKeys && projectKeys.length
      ? `project in (${projectKeys.map((k) => `"${k}"`).join(",")})`
      : `created >= "1970-01-01"`;
  const jql = encodeURIComponent(`${restriction} order by updated DESC`);
  let nextPageToken: string | undefined;
  // Page through results with the opaque token; bounded to avoid runaway loops.
  for (let page = 0; page < 50; page += 1) {
    const tokenParam = nextPageToken ? `&nextPageToken=${encodeURIComponent(nextPageToken)}` : "";
    const data = await jiraGet<JiraSearchApi>(
      config,
      `/rest/api/3/search/jql?jql=${jql}&maxResults=${maxResults}&fields=${fieldsParam}${tokenParam}`,
    );
    const batch = data.issues ?? [];
    for (const issue of batch) issues.push(normalizeIssue(issue, storyPointsFieldId));
    if (maxIssues > 0 && issues.length >= maxIssues) break;
    if (data.isLast || batch.length === 0 || !data.nextPageToken) break;
    nextPageToken = data.nextPageToken;
  }
  return maxIssues > 0 ? issues.slice(0, maxIssues) : issues;
}

// --- Field discovery ---------------------------------------------------------
interface JiraFieldApi {
  id: string;
  name: string;
  custom?: boolean;
  schema?: { type?: string };
}

function normalizeField(f: JiraFieldApi): NormalizedJiraField {
  return {
    fieldId: f.id,
    name: f.name,
    fieldType: f.schema?.type ?? null,
    custom: f.custom === true,
  };
}

// --- Identity / server info --------------------------------------------------
interface JiraMyselfApi {
  displayName?: string;
  emailAddress?: string;
}
interface JiraServerInfoApi {
  serverTitle?: string;
  baseUrl?: string;
}

export interface ConnectorOptions {
  // Jira field id mapped to the Matrix "storyPoints" concept (no hardcoded id).
  storyPointsFieldId?: string | null;
  // Hard cap on issues per run (0 = no cap). Applied to live and sample paths.
  maxIssues?: number;
  // Selected Jira project keys that bound the live JQL query. `undefined` means
  // "no selection saved" → import everything (legacy parity); an empty array
  // means "selection saved but nothing chosen" → import nothing.
  projectKeys?: string[];
}

// Pulls projects + issues. Falls back to sample data when Jira is not configured.
export async function runConnector(
  log: Logger,
  options: ConnectorOptions = {},
): Promise<ConnectorResult> {
  const storyPointsFieldId = options.storyPointsFieldId ?? null;
  const maxIssues = options.maxIssues ?? 0;
  const projectKeys = options.projectKeys ?? null;
  const config = await getEffectiveJiraConfig();
  if (!config) {
    log.info("Jira not configured — using sample connector data for sync");
    const issues =
      maxIssues > 0 ? SAMPLE_JIRA_ISSUES.slice(0, maxIssues) : SAMPLE_JIRA_ISSUES;
    return {
      projects: SAMPLE_JIRA_PROJECTS,
      issues,
      usingSampleData: true,
    };
  }
  const [projects, issues] = await Promise.all([
    fetchLiveProjects(config),
    fetchLiveIssues(config, storyPointsFieldId, maxIssues, projectKeys),
  ]);
  return { projects, issues, usingSampleData: false };
}

// Discover the project catalog. Live when configured, sample otherwise.
export async function discoverProjects(
  log: Logger,
): Promise<{ projects: NormalizedJiraProject[]; usingSampleData: boolean }> {
  const config = await getEffectiveJiraConfig();
  if (!config) {
    log.info("Jira not configured — discovering sample projects");
    return { projects: SAMPLE_JIRA_PROJECTS, usingSampleData: true };
  }
  const projects = await fetchLiveProjects(config);
  return { projects, usingSampleData: false };
}

// Discover the field catalog. Live when configured, sample otherwise.
export async function discoverFields(
  log: Logger,
): Promise<{ fields: NormalizedJiraField[]; usingSampleData: boolean }> {
  const config = await getEffectiveJiraConfig();
  if (!config) {
    log.info("Jira not configured — discovering sample fields");
    return { fields: SAMPLE_JIRA_FIELDS, usingSampleData: true };
  }
  const data = await jiraGet<JiraFieldApi[]>(config, "/rest/api/3/field");
  return { fields: data.map(normalizeField), usingSampleData: false };
}

// Test the connection: identity (/myself) + server info (/serverInfo). Sample
// identity when not configured. Never throws — returns ok:false on failure.
export async function testConnection(log: Logger): Promise<TestConnectionResult> {
  const config = await getEffectiveJiraConfig();
  if (!config) {
    const sample: JiraServerInfo = SAMPLE_JIRA_SERVER_INFO;
    return {
      ok: true,
      usingSampleData: true,
      authenticatedUser: sample.authenticatedUser,
      serverTitle: sample.serverTitle,
      baseUrl: null,
      message: "Jira is not configured — returning sample connection data.",
    };
  }
  try {
    const [me, info] = await Promise.all([
      jiraGet<JiraMyselfApi>(config, "/rest/api/3/myself"),
      jiraGet<JiraServerInfoApi>(config, "/rest/api/3/serverInfo"),
    ]);
    return {
      ok: true,
      usingSampleData: false,
      authenticatedUser: me.displayName ?? null,
      serverTitle: info.serverTitle ?? null,
      baseUrl: config.baseUrl,
      message: "Connected to Jira Cloud.",
    };
  } catch (err) {
    log.error({ err }, "Jira test connection failed");
    return {
      ok: false,
      usingSampleData: false,
      authenticatedUser: null,
      serverTitle: null,
      baseUrl: config.baseUrl,
      message: "Could not connect to Jira. See server logs for details.",
    };
  }
}

// Lightweight reachability probe for the status endpoint. Returns false (never
// throws) so status reporting stays honest and credential-free.
export async function probeJira(log: Logger): Promise<boolean> {
  const config = await getEffectiveJiraConfig();
  if (!config) return false;
  try {
    await jiraGet(config, "/rest/api/3/myself");
    return true;
  } catch (err) {
    log.error({ err }, "Jira reachability probe failed");
    return false;
  }
}
