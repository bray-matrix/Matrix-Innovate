// Server-side Jira repository layer — the seam between the API server and
// PostgreSQL (the system of record for imported Jira data). Routes and the sync
// orchestrator go through these repositories; they never touch Drizzle directly.
//
// Honest about availability: when DATABASE_URL is unset, reads return empty /
// null and writes throw, so callers see a truthful "not available" rather than
// fabricated data. Upserts conflict on the unique Jira id columns, which keeps
// repeated syncs idempotent.
import { eq, and, desc, sql } from "drizzle-orm";
import {
  getDb,
  isDatabaseConfigured,
  jiraProjectsTable,
  jiraIssuesTable,
  jiraSyncRunsTable,
  jiraConfigurationTable,
  jiraSyncSettingsTable,
  jiraDiscoveredProjectsTable,
  jiraDiscoveredFieldsTable,
  jiraProjectMappingsTable,
  jiraFieldMappingsTable,
  jiraStatusMappingsTable,
  jiraSyncSnapshotsTable,
  jiraProjectMetricsTable,
  type JiraProjectRow,
  type JiraIssueRow,
  type JiraSyncRunRow,
  type InsertJiraProject,
  type InsertJiraIssue,
  type InsertJiraSyncRun,
  type JiraConfigurationRow,
  type JiraSyncSettingsRow,
  type JiraDiscoveredProjectRow,
  type JiraDiscoveredFieldRow,
  type JiraProjectMappingRow,
  type JiraFieldMappingRow,
  type JiraStatusMappingRow,
  type InsertJiraConfiguration,
  type InsertJiraSyncSettings,
  type InsertJiraDiscoveredProject,
  type InsertJiraDiscoveredField,
  type InsertJiraProjectMapping,
  type InsertJiraFieldMapping,
  type InsertJiraStatusMapping,
  type JiraSyncSnapshotRow,
  type JiraProjectMetricRow,
  type InsertJiraSyncSnapshot,
  type InsertJiraProjectMetric,
} from "@workspace/db";

// Fixed primary key for the single-row config/settings tables.
const SINGLETON_ID = "default";

export interface IssueFilters {
  projectKey?: string;
  status?: string;
}

// --- Projects -----------------------------------------------------------------
export const jiraProjectRepository = {
  async listProjects(): Promise<JiraProjectRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb().select().from(jiraProjectsTable).orderBy(jiraProjectsTable.jiraProjectKey);
  },

  async getProject(id: string): Promise<JiraProjectRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb().select().from(jiraProjectsTable).where(eq(jiraProjectsTable.id, id));
    return rows[0] ?? null;
  },

  async getProjectByKey(key: string): Promise<JiraProjectRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb()
      .select()
      .from(jiraProjectsTable)
      .where(eq(jiraProjectsTable.jiraProjectKey, key));
    return rows[0] ?? null;
  },

  async countProjects(): Promise<number> {
    if (!isDatabaseConfigured()) return 0;
    const rows = await getDb().select({ value: sql<number>`count(*)` }).from(jiraProjectsTable);
    return Number(rows[0]?.value ?? 0);
  },

  // Upsert by unique jiraProjectId. Returns how many rows were created vs updated.
  async upsertProjects(projects: InsertJiraProject[]): Promise<{ created: number; updated: number }> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    if (projects.length === 0) return { created: 0, updated: 0 };
    const db = getDb();
    let created = 0;
    let updated = 0;
    for (const project of projects) {
      const existing = await db
        .select({ id: jiraProjectsTable.id })
        .from(jiraProjectsTable)
        .where(eq(jiraProjectsTable.jiraProjectId, project.jiraProjectId));
      await db
        .insert(jiraProjectsTable)
        .values(project)
        .onConflictDoUpdate({
          target: jiraProjectsTable.jiraProjectId,
          set: {
            jiraProjectKey: project.jiraProjectKey,
            jiraProjectName: project.jiraProjectName,
            projectType: project.projectType,
            leadName: project.leadName,
            leadAccountId: project.leadAccountId,
            isActive: project.isActive,
            updatedAt: new Date(),
          },
        });
      if (existing.length > 0) updated += 1;
      else created += 1;
    }
    return { created, updated };
  },
};

// --- Issues -------------------------------------------------------------------
export const jiraIssueRepository = {
  async listIssues(filters: IssueFilters = {}): Promise<JiraIssueRow[]> {
    if (!isDatabaseConfigured()) return [];
    const conditions = [];
    if (filters.projectKey) conditions.push(eq(jiraIssuesTable.jiraProjectKey, filters.projectKey));
    if (filters.status) conditions.push(eq(jiraIssuesTable.status, filters.status));
    const base = getDb().select().from(jiraIssuesTable);
    const query = conditions.length > 0 ? base.where(and(...conditions)) : base;
    return query.orderBy(jiraIssuesTable.jiraIssueKey);
  },

  async getIssue(id: string): Promise<JiraIssueRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb().select().from(jiraIssuesTable).where(eq(jiraIssuesTable.id, id));
    return rows[0] ?? null;
  },

  async getIssueByKey(key: string): Promise<JiraIssueRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb()
      .select()
      .from(jiraIssuesTable)
      .where(eq(jiraIssuesTable.jiraIssueKey, key));
    return rows[0] ?? null;
  },

  async countIssues(): Promise<number> {
    if (!isDatabaseConfigured()) return 0;
    const rows = await getDb().select({ value: sql<number>`count(*)` }).from(jiraIssuesTable);
    return Number(rows[0]?.value ?? 0);
  },

  // Upsert by unique jiraIssueId. Returns how many rows were created vs updated.
  async upsertIssues(issues: InsertJiraIssue[]): Promise<{ created: number; updated: number }> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    if (issues.length === 0) return { created: 0, updated: 0 };
    const db = getDb();
    let created = 0;
    let updated = 0;
    for (const issue of issues) {
      const existing = await db
        .select({ id: jiraIssuesTable.id })
        .from(jiraIssuesTable)
        .where(eq(jiraIssuesTable.jiraIssueId, issue.jiraIssueId));
      await db
        .insert(jiraIssuesTable)
        .values(issue)
        .onConflictDoUpdate({
          target: jiraIssuesTable.jiraIssueId,
          set: {
            jiraIssueKey: issue.jiraIssueKey,
            jiraProjectKey: issue.jiraProjectKey,
            summary: issue.summary,
            description: issue.description,
            issueType: issue.issueType,
            status: issue.status,
            priority: issue.priority,
            assigneeName: issue.assigneeName,
            assigneeAccountId: issue.assigneeAccountId,
            reporterName: issue.reporterName,
            storyPoints: issue.storyPoints,
            createdDate: issue.createdDate,
            updatedDate: issue.updatedDate,
            dueDate: issue.dueDate,
            resolutionDate: issue.resolutionDate,
            metadataJson: issue.metadataJson,
            updatedAt: new Date(),
          },
        });
      if (existing.length > 0) updated += 1;
      else created += 1;
    }
    return { created, updated };
  },
};

// --- Sync runs ----------------------------------------------------------------
export const jiraSyncRepository = {
  async getLastSync(): Promise<JiraSyncRunRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb()
      .select()
      .from(jiraSyncRunsTable)
      .orderBy(desc(jiraSyncRunsTable.createdAt))
      .limit(1);
    return rows[0] ?? null;
  },

  async listSyncRuns(limit = 10): Promise<JiraSyncRunRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraSyncRunsTable)
      .orderBy(desc(jiraSyncRunsTable.createdAt))
      .limit(limit);
  },

  async getLastSyncByStatus(status: string): Promise<JiraSyncRunRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb()
      .select()
      .from(jiraSyncRunsTable)
      .where(eq(jiraSyncRunsTable.status, status))
      .orderBy(desc(jiraSyncRunsTable.createdAt))
      .limit(1);
    return rows[0] ?? null;
  },

  async countRuns(): Promise<number> {
    if (!isDatabaseConfigured()) return 0;
    const rows = await getDb().select({ value: sql<number>`count(*)` }).from(jiraSyncRunsTable);
    return Number(rows[0]?.value ?? 0);
  },

  async createSyncRun(run: InsertJiraSyncRun): Promise<JiraSyncRunRow> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const rows = await getDb().insert(jiraSyncRunsTable).values(run).returning();
    return rows[0]!;
  },

  async updateSyncRun(id: string, patch: Partial<InsertJiraSyncRun>): Promise<JiraSyncRunRow | null> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const rows = await getDb()
      .update(jiraSyncRunsTable)
      .set({ ...patch, updatedAt: new Date() })
      .where(eq(jiraSyncRunsTable.id, id))
      .returning();
    return rows[0] ?? null;
  },
};

// --- Connection configuration (single row) -----------------------------------
// The api token lives only here, server-side. Callers that surface config to the
// browser must mask it (the routes return hasApiToken + a hint, never the token).
export const jiraConfigRepository = {
  async getConfig(): Promise<JiraConfigurationRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb()
      .select()
      .from(jiraConfigurationTable)
      .where(eq(jiraConfigurationTable.id, SINGLETON_ID));
    return rows[0] ?? null;
  },

  // Upsert the single config row. When apiToken is undefined the previously
  // stored token is preserved (an empty string is treated the same as undefined).
  async saveConfig(input: {
    baseUrl: string;
    email: string;
    apiToken?: string;
    enabled: boolean;
  }): Promise<JiraConfigurationRow> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    const existing = await this.getConfig();
    const token =
      input.apiToken && input.apiToken.length > 0 ? input.apiToken : existing?.apiToken ?? null;
    const values: InsertJiraConfiguration = {
      id: SINGLETON_ID,
      baseUrl: input.baseUrl,
      email: input.email,
      apiToken: token,
      enabled: input.enabled,
    };
    const rows = await db
      .insert(jiraConfigurationTable)
      .values(values)
      .onConflictDoUpdate({
        target: jiraConfigurationTable.id,
        set: {
          baseUrl: input.baseUrl,
          email: input.email,
          apiToken: token,
          enabled: input.enabled,
          updatedAt: new Date(),
        },
      })
      .returning();
    return rows[0]!;
  },

  // Record the outcome of a Test Connection so it can be surfaced in diagnostics.
  async recordTest(patch: {
    ok: boolean;
    message: string;
    authenticatedUser: string | null;
    serverTitle: string | null;
  }): Promise<void> {
    if (!isDatabaseConfigured()) return;
    const existing = await this.getConfig();
    if (!existing) return;
    await getDb()
      .update(jiraConfigurationTable)
      .set({
        lastTestAt: new Date().toISOString(),
        lastTestOk: patch.ok,
        lastTestMessage: patch.message,
        authenticatedUser: patch.authenticatedUser,
        serverTitle: patch.serverTitle,
        updatedAt: new Date(),
      })
      .where(eq(jiraConfigurationTable.id, SINGLETON_ID));
  },
};

// --- Sync settings (single row) ----------------------------------------------
export const jiraSyncSettingsRepository = {
  async getSettings(): Promise<JiraSyncSettingsRow | null> {
    if (!isDatabaseConfigured()) return null;
    const rows = await getDb()
      .select()
      .from(jiraSyncSettingsTable)
      .where(eq(jiraSyncSettingsTable.id, SINGLETON_ID));
    return rows[0] ?? null;
  },

  async saveSettings(input: {
    autoSyncEnabled: boolean;
    syncFrequency: string;
    maxIssuesPerRun: number;
    syncMode: string;
    issueTypes: string[];
  }): Promise<JiraSyncSettingsRow> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const values: InsertJiraSyncSettings = { id: SINGLETON_ID, ...input };
    const rows = await getDb()
      .insert(jiraSyncSettingsTable)
      .values(values)
      .onConflictDoUpdate({
        target: jiraSyncSettingsTable.id,
        set: { ...input, updatedAt: new Date() },
      })
      .returning();
    return rows[0]!;
  },
};

// --- Discovery snapshots ------------------------------------------------------
// Discovery is authoritative: each run replaces the snapshot so removed Jira
// projects/fields drop out rather than lingering.
export const jiraDiscoveredProjectRepository = {
  async list(): Promise<JiraDiscoveredProjectRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraDiscoveredProjectsTable)
      .orderBy(jiraDiscoveredProjectsTable.jiraProjectKey);
  },

  async replaceAll(rows: InsertJiraDiscoveredProject[]): Promise<JiraDiscoveredProjectRow[]> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    await db.delete(jiraDiscoveredProjectsTable);
    if (rows.length === 0) return [];
    await db.insert(jiraDiscoveredProjectsTable).values(rows);
    return this.list();
  },
};

export const jiraDiscoveredFieldRepository = {
  async list(): Promise<JiraDiscoveredFieldRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb().select().from(jiraDiscoveredFieldsTable).orderBy(jiraDiscoveredFieldsTable.name);
  },

  async replaceAll(rows: InsertJiraDiscoveredField[]): Promise<JiraDiscoveredFieldRow[]> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    await db.delete(jiraDiscoveredFieldsTable);
    if (rows.length === 0) return [];
    await db.insert(jiraDiscoveredFieldsTable).values(rows);
    return this.list();
  },
};

// --- Mappings -----------------------------------------------------------------
// PUT is authoritative: replace the whole set so the saved rows mirror the UI.
export const jiraProjectMappingRepository = {
  async list(): Promise<JiraProjectMappingRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraProjectMappingsTable)
      .orderBy(jiraProjectMappingsTable.jiraProjectKey);
  },

  async replaceAll(rows: InsertJiraProjectMapping[]): Promise<JiraProjectMappingRow[]> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    await db.delete(jiraProjectMappingsTable);
    if (rows.length > 0) await db.insert(jiraProjectMappingsTable).values(rows);
    return this.list();
  },
};

export const jiraFieldMappingRepository = {
  async list(): Promise<JiraFieldMappingRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraFieldMappingsTable)
      .orderBy(jiraFieldMappingsTable.matrixConcept);
  },

  async replaceAll(rows: InsertJiraFieldMapping[]): Promise<JiraFieldMappingRow[]> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    await db.delete(jiraFieldMappingsTable);
    if (rows.length > 0) await db.insert(jiraFieldMappingsTable).values(rows);
    return this.list();
  },
};

export const jiraStatusMappingRepository = {
  async list(): Promise<JiraStatusMappingRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraStatusMappingsTable)
      .orderBy(jiraStatusMappingsTable.jiraStatus);
  },

  async replaceAll(rows: InsertJiraStatusMapping[]): Promise<JiraStatusMappingRow[]> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    await db.delete(jiraStatusMappingsTable);
    if (rows.length > 0) await db.insert(jiraStatusMappingsTable).values(rows);
    return this.list();
  },
};

// --- T022.7 executive intelligence persistence -------------------------------
// Snapshots accumulate (one per sync) as the trend framework; project metrics are
// fully replaced each sync. Both are honest: empty when DATABASE_URL is unset.
export const jiraSnapshotRepository = {
  async list(limit = 30): Promise<JiraSyncSnapshotRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraSyncSnapshotsTable)
      .orderBy(desc(jiraSyncSnapshotsTable.capturedAt))
      .limit(limit);
  },

  async insert(row: InsertJiraSyncSnapshot): Promise<JiraSyncSnapshotRow> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const rows = await getDb().insert(jiraSyncSnapshotsTable).values(row).returning();
    return rows[0]!;
  },
};

export const jiraProjectMetricRepository = {
  async list(): Promise<JiraProjectMetricRow[]> {
    if (!isDatabaseConfigured()) return [];
    return getDb()
      .select()
      .from(jiraProjectMetricsTable)
      .orderBy(jiraProjectMetricsTable.jiraProjectKey);
  },

  // Full replace each sync: the persisted metrics always mirror the latest data.
  async replaceAll(rows: InsertJiraProjectMetric[]): Promise<JiraProjectMetricRow[]> {
    if (!isDatabaseConfigured()) throw new Error("Database is not configured");
    const db = getDb();
    await db.delete(jiraProjectMetricsTable);
    if (rows.length > 0) await db.insert(jiraProjectMetricsTable).values(rows);
    return this.list();
  },
};
