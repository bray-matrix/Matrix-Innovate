// Presentational components for Jira executive intelligence. These are pure
// renderers over the computed types from @workspace/jira-intelligence (re-exported
// through the repository types) — they never fetch or compute. The owning page /
// dashboard loads metrics via the repository and passes them in.
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PanelCard, StatTile } from "@/components/detail/shared";
import {
  AlertTriangle,
  Ban,
  CalendarClock,
  CheckCircle2,
  CircleDot,
  Flame,
  FolderGit2,
  HeartPulse,
  Info,
  ListTodo,
  TimerReset,
} from "lucide-react";
import type {
  ExecutiveMetrics,
  PortfolioHealth,
  StatusCounts,
  PriorityCounts,
  AgingCounts,
  RiskIndicators,
  ExecutiveAlert,
  HealthClass,
} from "@/repositories/jira/types";

// --- Shared helpers ----------------------------------------------------------

export const HEALTH_CLASS_STYLE: Record<HealthClass, { label: string; badge: string; bar: string }> = {
  healthy: { label: "Healthy", badge: "bg-emerald-50 text-emerald-700 border-emerald-200", bar: "bg-emerald-500" },
  watch: { label: "Watch", badge: "bg-amber-50 text-amber-700 border-amber-200", bar: "bg-amber-500" },
  atRisk: { label: "At Risk", badge: "bg-orange-50 text-orange-700 border-orange-200", bar: "bg-orange-500" },
  critical: { label: "Critical", badge: "bg-red-50 text-red-700 border-red-200", bar: "bg-red-500" },
};

export function HealthClassBadge({ value }: { value: HealthClass }) {
  const s = HEALTH_CLASS_STYLE[value];
  return (
    <Badge variant="outline" className={`text-[11px] px-2 py-0.5 ${s.badge}`}>
      {s.label}
    </Badge>
  );
}

function healthScoreColor(score: number): string {
  if (score >= 80) return "text-emerald-600";
  if (score >= 60) return "text-amber-600";
  if (score >= 40) return "text-orange-600";
  return "text-red-600";
}

// --- Executive summary -------------------------------------------------------

export function ExecutiveSummaryCards({ metrics }: { metrics: ExecutiveMetrics }) {
  const s = metrics.summary;
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
      <Card className="border-slate-200 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-500">Health score</p>
            <HeartPulse className="h-4 w-4 text-slate-400" />
          </div>
          <p className={`text-2xl font-bold mt-2 ${healthScoreColor(metrics.healthScore)}`}>
            {metrics.healthScore}
            <span className="text-base font-medium text-slate-400">/100</span>
          </p>
          <Progress value={metrics.healthScore} className="mt-2 h-1.5" />
        </CardContent>
      </Card>
      <StatTile icon={FolderGit2} value={s.importedProjects} label="Projects" />
      <StatTile icon={ListTodo} value={s.importedIssues} label="Issues" />
      <StatTile icon={CircleDot} value={s.openIssues} label="Open" hint={`${s.completedIssues} completed`} />
      <StatTile icon={Ban} value={s.blockedIssues} label="Blocked" />
      <StatTile icon={CalendarClock} value={s.overdueIssues} label="Overdue" />
      <StatTile icon={Flame} value={s.criticalIssues} label="Critical" />
      <StatTile icon={TimerReset} value={`${s.averageIssueAgeDays}d`} label="Avg issue age" />
    </div>
  );
}

// --- Portfolio health distribution -------------------------------------------

function distRow(label: string, count: number, total: number, bar: string) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-sm">
        <span className="text-slate-600">{label}</span>
        <span className="font-medium text-slate-900">{count}</span>
      </div>
      <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
        <div className={`h-full rounded-full ${bar}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function PortfolioHealthPanel({ health }: { health: PortfolioHealth }) {
  const total = health.healthy + health.watch + health.atRisk + health.critical;
  return (
    <PanelCard title="Portfolio Health" description="Projects classified by blocked-issue load.">
      {total === 0 ? (
        <p className="text-sm text-slate-500">No projects to classify yet.</p>
      ) : (
        <div className="space-y-3">
          {distRow("Healthy", health.healthy, total, HEALTH_CLASS_STYLE.healthy.bar)}
          {distRow("Watch", health.watch, total, HEALTH_CLASS_STYLE.watch.bar)}
          {distRow("At Risk", health.atRisk, total, HEALTH_CLASS_STYLE.atRisk.bar)}
          {distRow("Critical", health.critical, total, HEALTH_CLASS_STYLE.critical.bar)}
        </div>
      )}
    </PanelCard>
  );
}

// --- Status analytics --------------------------------------------------------

export function StatusAnalyticsPanel({ status }: { status: StatusCounts }) {
  const total = status.todo + status.inProgress + status.blocked + status.done;
  return (
    <PanelCard title="Status Breakdown" description="Issues by workflow status.">
      {total === 0 ? (
        <p className="text-sm text-slate-500">No issues yet.</p>
      ) : (
        <div className="space-y-3">
          {distRow("To Do", status.todo, total, "bg-slate-400")}
          {distRow("In Progress", status.inProgress, total, "bg-blue-500")}
          {distRow("Blocked", status.blocked, total, "bg-red-500")}
          {distRow("Done", status.done, total, "bg-emerald-500")}
        </div>
      )}
    </PanelCard>
  );
}

// --- Priority analytics ------------------------------------------------------

export function PriorityAnalyticsPanel({ priority }: { priority: PriorityCounts }) {
  const total = priority.highest + priority.high + priority.medium + priority.low;
  return (
    <PanelCard title="Priority Distribution" description="Issues by priority band.">
      {total === 0 ? (
        <p className="text-sm text-slate-500">No issues yet.</p>
      ) : (
        <div className="space-y-3">
          {distRow("Highest", priority.highest, total, "bg-red-500")}
          {distRow("High", priority.high, total, "bg-orange-500")}
          {distRow("Medium", priority.medium, total, "bg-amber-500")}
          {distRow("Low", priority.low, total, "bg-slate-400")}
        </div>
      )}
    </PanelCard>
  );
}

// --- Aging distribution ------------------------------------------------------

export function AgingDistributionPanel({ aging }: { aging: AgingCounts }) {
  const buckets: { label: string; value: number; bar: string }[] = [
    { label: "0–7 days", value: aging.d0_7, bar: "bg-emerald-500" },
    { label: "8–30 days", value: aging.d8_30, bar: "bg-lime-500" },
    { label: "31–60 days", value: aging.d31_60, bar: "bg-amber-500" },
    { label: "61–90 days", value: aging.d61_90, bar: "bg-orange-500" },
    { label: "90+ days", value: aging.d90plus, bar: "bg-red-500" },
  ];
  const total = buckets.reduce((sum, b) => sum + b.value, 0);
  return (
    <PanelCard title="Open Issue Aging" description="How long open issues have been outstanding.">
      {total === 0 ? (
        <p className="text-sm text-slate-500">No open issues to age.</p>
      ) : (
        <div className="space-y-3">
          {buckets.map((b) => (
            <div key={b.label}>{distRow(b.label, b.value, total, b.bar)}</div>
          ))}
        </div>
      )}
    </PanelCard>
  );
}

// --- Risk indicators ---------------------------------------------------------

export function RiskIndicatorsPanel({ risk }: { risk: RiskIndicators }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
      <StatTile icon={Ban} value={risk.blockedIssues} label="Blocked" />
      <StatTile icon={TimerReset} value={risk.agingIssues} label="Aging (>30d)" />
      <StatTile icon={CalendarClock} value={risk.overdueIssues} label="Overdue" />
      <StatTile icon={Flame} value={risk.highPriorityOpen} label="High-priority open" />
      <StatTile icon={FolderGit2} value={risk.staleProjects} label="Stale projects" />
    </div>
  );
}

// --- Executive alerts --------------------------------------------------------

const ALERT_STYLE: Record<ExecutiveAlert["severity"], { border: string; bg: string; icon: typeof AlertTriangle; iconColor: string }> = {
  critical: { border: "border-red-200", bg: "bg-red-50", icon: AlertTriangle, iconColor: "text-red-500" },
  warning: { border: "border-amber-200", bg: "bg-amber-50", icon: AlertTriangle, iconColor: "text-amber-500" },
  info: { border: "border-blue-200", bg: "bg-blue-50", icon: Info, iconColor: "text-blue-500" },
};

export function ExecutiveAlertsPanel({ alerts }: { alerts: ExecutiveAlert[] }) {
  return (
    <PanelCard title="Executive Alerts" description="Auto-derived signals that may need leadership attention.">
      {alerts.length === 0 ? (
        <div className="flex items-center gap-2 text-sm text-emerald-700">
          <CheckCircle2 className="h-4 w-4" />
          No active alerts — portfolio signals are within thresholds.
        </div>
      ) : (
        <div className="space-y-2">
          {alerts.map((a) => {
            const s = ALERT_STYLE[a.severity];
            const Icon = s.icon;
            return (
              <div key={a.id} className={`flex items-start gap-3 rounded-lg border p-3 ${s.border} ${s.bg}`}>
                <Icon className={`h-4 w-4 mt-0.5 flex-shrink-0 ${s.iconColor}`} />
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-900">
                    {a.title}
                    {a.projectKey && (
                      <span className="ml-2 text-xs font-normal text-slate-500">{a.projectKey}</span>
                    )}
                  </p>
                  <p className="text-xs text-slate-600 mt-0.5">{a.message}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </PanelCard>
  );
}
