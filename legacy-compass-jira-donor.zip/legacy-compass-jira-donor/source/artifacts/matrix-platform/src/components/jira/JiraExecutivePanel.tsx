// Compact Jira executive intelligence strip for the dashboard executive view.
// Self-loads through the repository layer (mock or postgres) so the dashboard
// stays synchronous elsewhere. Renders nothing while loading/empty so it never
// disrupts the executive dashboard layout.
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { PanelCard } from "@/components/detail/shared";
import { ExecutiveSummaryCards } from "@/components/jira/intelligence";
import { getJiraRepository } from "@/repositories/jira";
import type { ExecutiveMetrics } from "@/repositories/jira/types";
import { ArrowRight, GitMerge } from "lucide-react";

export function JiraExecutivePanel() {
  const [metrics, setMetrics] = useState<ExecutiveMetrics | null>(null);

  useEffect(() => {
    let cancelled = false;
    getJiraRepository()
      .getExecutiveMetrics()
      .then((m) => {
        if (!cancelled) setMetrics(m);
      })
      .catch(() => {
        // Jira intelligence is supplementary on the dashboard; swallow errors
        // so a Jira/connectivity issue never breaks the executive dashboard.
        if (!cancelled) setMetrics(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!metrics || metrics.summary.importedIssues === 0) return null;

  return (
    <PanelCard
      title={
        <span className="flex items-center gap-2">
          <GitMerge className="h-4 w-4 text-slate-400" />
          Jira Portfolio Intelligence
        </span>
      }
      description="Executive signals from synced Jira delivery data."
      action={
        <Button variant="outline" size="sm" asChild>
          <Link href="/jira-portfolio" className="flex items-center gap-1">
            View details <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </Button>
      }
    >
      <ExecutiveSummaryCards metrics={metrics} />
    </PanelCard>
  );
}
