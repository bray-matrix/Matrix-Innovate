import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plug,
  RefreshCw,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Loader2,
  FolderGit2,
  ListTodo,
  ShieldCheck,
  Save,
  Search,
  Settings2,
  History,
  Activity,
  Tags,
  HeartPulse,
  CircleDot,
  Ban,
  CalendarClock,
  Flame,
  Timer,
} from "lucide-react";
import { getDataSourceMode } from "@/repositories";
import {
  getJiraRepository,
  type JiraStatus,
  type JiraSyncResult,
  type JiraConfig,
  type JiraConnectionTest,
  type JiraDiscoveredProject,
  type JiraDiscoveredField,
  type JiraProjectMapping,
  type JiraFieldMapping,
  type JiraStatusMapping,
  type JiraSyncSettings,
  type JiraDiagnostics,
  type JiraSyncRun,
} from "@/repositories/jira";
import {
  MATRIX_FIELD_CONCEPTS,
  MATRIX_STATUS_OPTIONS,
} from "@/repositories/jira/sampleJira";

type Tone = "ok" | "warn" | "error";

const TONE_BADGE: Record<Tone, string> = {
  ok: "bg-emerald-100 text-emerald-700",
  warn: "bg-amber-100 text-amber-800",
  error: "bg-red-100 text-red-700",
};

const NONE_VALUE = "__none__";

function ConnBadge({ status }: { status: JiraStatus }) {
  const tone: Tone = status.configured && status.reachable ? "ok" : status.configured ? "error" : "warn";
  const label = status.configured
    ? status.reachable
      ? "Connected"
      : "Unreachable"
    : "Not Configured";
  const Icon = tone === "ok" ? CheckCircle2 : tone === "warn" ? AlertCircle : XCircle;
  return (
    <Badge variant="secondary" className={TONE_BADGE[tone]}>
      <Icon className="h-3.5 w-3.5 mr-1" />
      {label}
    </Badge>
  );
}

function StatTile({ icon: Icon, value, label }: { icon: typeof FolderGit2; value: number | string; label: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 flex items-center gap-3">
      <Icon className="h-5 w-5 text-slate-500" />
      <div>
        <div className="text-lg font-semibold text-slate-900 tabular-nums">{typeof value === "number" ? value.toLocaleString() : value}</div>
        <div className="text-xs text-slate-500">{label}</div>
      </div>
    </div>
  );
}

function SectionCard({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: typeof FolderGit2;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Card className="border-slate-200 shadow-sm">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Icon className="h-4 w-4 text-slate-500" /> {title}
        </CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  );
}

function Notice({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  const cls =
    tone === "ok"
      ? "border-emerald-200 bg-emerald-50 text-emerald-700"
      : tone === "warn"
        ? "border-amber-200 bg-amber-50 text-amber-800"
        : "border-red-200 bg-red-50 text-red-700";
  return <div className={`rounded-lg border px-3 py-2 text-sm ${cls}`}>{children}</div>;
}

// --- Connection --------------------------------------------------------------

function ConnectionSection({ repo }: { repo: ReturnType<typeof getJiraRepository> }) {
  const [config, setConfig] = useState<JiraConfig | null>(null);
  const [baseUrl, setBaseUrl] = useState("");
  const [email, setEmail] = useState("");
  const [apiToken, setApiToken] = useState("");
  const [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [test, setTest] = useState<JiraConnectionTest | null>(null);
  const [msg, setMsg] = useState<{ tone: Tone; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const c = await repo.getConfig();
      setConfig(c);
      setBaseUrl(c.baseUrl ?? "");
      setEmail(c.email ?? "");
      setEnabled(c.enabled);
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to load configuration." });
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    void load();
  }, [load]);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      // apiToken is sent only when the admin typed a new one; an empty value
      // leaves the stored token untouched (the server preserves it).
      const c = await repo.saveConfig({
        baseUrl,
        email,
        enabled,
        ...(apiToken.length > 0 ? { apiToken } : {}),
      });
      setConfig(c);
      setApiToken("");
      setMsg({ tone: "ok", text: "Configuration saved." });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to save configuration." });
    } finally {
      setSaving(false);
    }
  };

  const runTest = async () => {
    setTesting(true);
    setTest(null);
    try {
      const t = await repo.testConnection();
      setTest(t);
      await load();
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Connection test failed." });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <SectionCard icon={Plug} title="Connection">
        <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
      </SectionCard>
    );
  }

  return (
    <SectionCard
      icon={Plug}
      title="Connection"
      description="Credentials are stored server-side. The API token is never returned to the browser — only a masked hint."
    >
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      {config && (
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <Badge variant="secondary" className={config.enabled ? TONE_BADGE.ok : TONE_BADGE.warn}>
            {config.enabled ? "Enabled" : "Disabled"}
          </Badge>
          <span className="text-slate-500">
            Source: <span className="font-medium text-slate-700">{config.source}</span>
          </span>
          <span className="text-slate-500">
            Token: {config.hasApiToken ? `stored ${config.apiTokenHint ?? ""}` : "not set"}
          </span>
          {config.lastTestAt && (
            <span className={config.lastTestOk ? "text-emerald-700" : "text-red-700"}>
              Last test {config.lastTestOk ? "passed" : "failed"} ·{" "}
              {new Date(config.lastTestAt).toLocaleString()}
            </span>
          )}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="jira-base-url">Base URL</Label>
          <Input
            id="jira-base-url"
            placeholder="https://your-domain.atlassian.net"
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="jira-email">Account Email</Label>
          <Input
            id="jira-email"
            placeholder="integration@company.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="jira-token">API Token</Label>
          <Input
            id="jira-token"
            type="password"
            placeholder={config?.hasApiToken ? "•••••••• (leave blank to keep)" : "Paste API token"}
            value={apiToken}
            onChange={(e) => setApiToken(e.target.value)}
          />
          <p className="text-xs text-slate-400">
            Stored encrypted server-side and never sent back to the browser.
          </p>
        </div>
        <div className="flex items-center gap-3 pt-6">
          <Switch id="jira-enabled" checked={enabled} onCheckedChange={setEnabled} />
          <Label htmlFor="jira-enabled">Enable live Jira connection</Label>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 pt-1">
        <Button onClick={save} disabled={saving} size="sm">
          {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Save Configuration
        </Button>
        <Button onClick={runTest} disabled={testing} variant="outline" size="sm">
          {testing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <ShieldCheck className="h-4 w-4 mr-2" />
          )}
          Test Connection
        </Button>
        {test && (
          <span className={`text-sm ${test.ok ? "text-emerald-700" : "text-red-700"}`}>
            {test.message}
            {test.authenticatedUser ? ` · ${test.authenticatedUser}` : ""}
            {test.serverTitle ? ` @ ${test.serverTitle}` : ""}
          </span>
        )}
      </div>
    </SectionCard>
  );
}

// --- Project Selection -------------------------------------------------------

function ProjectSelectionSection({ repo }: { repo: ReturnType<typeof getJiraRepository> }) {
  const [discovered, setDiscovered] = useState<JiraDiscoveredProject[]>([]);
  const [mappings, setMappings] = useState<JiraProjectMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [discovering, setDiscovering] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ tone: Tone; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [d, m] = await Promise.all([repo.listDiscoveredProjects(), repo.getProjectMappings()]);
      setDiscovered(d);
      setMappings(m);
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to load projects." });
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    void load();
  }, [load]);

  const discover = async () => {
    setDiscovering(true);
    setMsg(null);
    try {
      const d = await repo.discoverProjects();
      setDiscovered(d);
      setMsg({ tone: "ok", text: `Discovered ${d.length} project(s).` });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Discovery failed." });
    } finally {
      setDiscovering(false);
    }
  };

  const mappingFor = (key: string): JiraProjectMapping | undefined =>
    mappings.find((m) => m.jiraProjectKey === key);

  const update = (key: string, patch: Partial<JiraProjectMapping>) => {
    setMappings((prev) => {
      const existing = prev.find((m) => m.jiraProjectKey === key);
      if (existing) {
        return prev.map((m) => (m.jiraProjectKey === key ? { ...m, ...patch } : m));
      }
      return [
        ...prev,
        {
          id: key,
          jiraProjectKey: key,
          selected: false,
          matrixProgramId: null,
          matrixPortfolioCategory: null,
          ...patch,
        },
      ];
    });
  };

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      const saved = await repo.saveProjectMappings(
        mappings.map((m) => ({
          jiraProjectKey: m.jiraProjectKey,
          selected: m.selected,
          matrixProgramId: m.matrixProgramId,
          matrixPortfolioCategory: m.matrixPortfolioCategory,
        })),
      );
      setMappings(saved);
      setMsg({ tone: "ok", text: "Project selection saved." });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to save selection." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <SectionCard
      icon={FolderGit2}
      title="Project Selection"
      description="Discover Jira projects, choose which to import, and map them onto Matrix programs/portfolio."
    >
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      <div className="flex flex-wrap items-center gap-3">
        <Button onClick={discover} disabled={discovering} size="sm">
          {discovering ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Search className="h-4 w-4 mr-2" />
          )}
          Discover Projects
        </Button>
        <Button onClick={save} disabled={saving} variant="outline" size="sm">
          {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Save Selection
        </Button>
      </div>

      {loading ? (
        <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
      ) : discovered.length === 0 ? (
        <p className="text-sm text-slate-500">
          No discovered projects yet. Click “Discover Projects” to fetch the catalog.
        </p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Import</TableHead>
              <TableHead>Key</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Matrix Program ID</TableHead>
              <TableHead>Portfolio Category</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {discovered.map((p) => {
              const m = mappingFor(p.jiraProjectKey);
              return (
                <TableRow key={p.id}>
                  <TableCell>
                    <Checkbox
                      checked={m?.selected ?? false}
                      onCheckedChange={(v) => update(p.jiraProjectKey, { selected: v === true })}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{p.jiraProjectKey}</TableCell>
                  <TableCell>{p.jiraProjectName}</TableCell>
                  <TableCell>
                    <Input
                      className="h-8"
                      placeholder="PRG-…"
                      value={m?.matrixProgramId ?? ""}
                      onChange={(e) =>
                        update(p.jiraProjectKey, { matrixProgramId: e.target.value || null })
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      className="h-8"
                      placeholder="Category"
                      value={m?.matrixPortfolioCategory ?? ""}
                      onChange={(e) =>
                        update(p.jiraProjectKey, { matrixPortfolioCategory: e.target.value || null })
                      }
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}
    </SectionCard>
  );
}

// --- Field Mapping -----------------------------------------------------------

function FieldMappingSection({ repo }: { repo: ReturnType<typeof getJiraRepository> }) {
  const [fields, setFields] = useState<JiraDiscoveredField[]>([]);
  const [mappings, setMappings] = useState<JiraFieldMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [discovering, setDiscovering] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ tone: Tone; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [f, m] = await Promise.all([repo.listDiscoveredFields(), repo.getFieldMappings()]);
      setFields(f);
      setMappings(m);
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to load fields." });
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    void load();
  }, [load]);

  const discover = async () => {
    setDiscovering(true);
    setMsg(null);
    try {
      const f = await repo.discoverFields();
      setFields(f);
      setMsg({ tone: "ok", text: `Discovered ${f.length} field(s).` });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Discovery failed." });
    } finally {
      setDiscovering(false);
    }
  };

  const fieldIdFor = (concept: string): string =>
    mappings.find((m) => m.matrixConcept === concept)?.jiraFieldId ?? NONE_VALUE;

  const setConcept = (concept: string, fieldId: string) => {
    const field = fields.find((f) => f.fieldId === fieldId);
    setMappings((prev) => {
      const others = prev.filter((m) => m.matrixConcept !== concept);
      if (fieldId === NONE_VALUE) return others;
      return [
        ...others,
        {
          id: concept,
          matrixConcept: concept,
          jiraFieldId: fieldId,
          jiraFieldName: field?.name ?? null,
        },
      ];
    });
  };

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      const saved = await repo.saveFieldMappings(
        mappings.map((m) => ({
          matrixConcept: m.matrixConcept,
          jiraFieldId: m.jiraFieldId,
          jiraFieldName: m.jiraFieldName,
        })),
      );
      setMappings(saved);
      setMsg({ tone: "ok", text: "Field mappings saved." });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to save mappings." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <SectionCard
      icon={Tags}
      title="Field Mapping"
      description="Map Matrix concepts (e.g. Story Points) onto Jira fields. No field IDs are hardcoded — story points are resolved through this mapping at sync time."
    >
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      <div className="flex flex-wrap items-center gap-3">
        <Button onClick={discover} disabled={discovering} size="sm">
          {discovering ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Search className="h-4 w-4 mr-2" />
          )}
          Discover Fields
        </Button>
        <Button onClick={save} disabled={saving} variant="outline" size="sm">
          {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Save Mappings
        </Button>
      </div>

      {loading ? (
        <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Matrix Concept</TableHead>
              <TableHead>Jira Field</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {MATRIX_FIELD_CONCEPTS.map((c) => (
              <TableRow key={c.concept}>
                <TableCell className="font-medium">{c.label}</TableCell>
                <TableCell>
                  <Select value={fieldIdFor(c.concept)} onValueChange={(v) => setConcept(c.concept, v)}>
                    <SelectTrigger className="h-8 w-72">
                      <SelectValue placeholder="Not mapped" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE_VALUE}>Not mapped</SelectItem>
                      {fields.map((f) => (
                        <SelectItem key={f.id} value={f.fieldId}>
                          {f.name} {f.custom ? "(custom)" : ""} · {f.fieldId}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      {fields.length === 0 && !loading && (
        <p className="text-xs text-slate-400">
          Run “Discover Fields” to populate the Jira field options.
        </p>
      )}
    </SectionCard>
  );
}

// --- Sync Settings -----------------------------------------------------------

const COMMON_ISSUE_TYPES = ["Story", "Task", "Bug", "Epic", "Sub-task"];

function SyncSettingsSection({ repo }: { repo: ReturnType<typeof getJiraRepository> }) {
  const [settings, setSettings] = useState<JiraSyncSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ tone: Tone; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setSettings(await repo.getSyncSettings());
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to load settings." });
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    void load();
  }, [load]);

  const patch = (p: Partial<JiraSyncSettings>) =>
    setSettings((prev) => (prev ? { ...prev, ...p } : prev));

  const toggleIssueType = (type: string, on: boolean) => {
    setSettings((prev) => {
      if (!prev) return prev;
      const set = new Set(prev.issueTypes);
      if (on) set.add(type);
      else set.delete(type);
      return { ...prev, issueTypes: Array.from(set) };
    });
  };

  const save = async () => {
    if (!settings) return;
    setSaving(true);
    setMsg(null);
    try {
      const saved = await repo.saveSyncSettings({
        autoSyncEnabled: settings.autoSyncEnabled,
        syncFrequency: settings.syncFrequency,
        maxIssuesPerRun: settings.maxIssuesPerRun,
        syncMode: settings.syncMode,
        issueTypes: settings.issueTypes,
      });
      setSettings(saved);
      setMsg({ tone: "ok", text: "Sync settings saved." });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to save settings." });
    } finally {
      setSaving(false);
    }
  };

  if (loading || !settings) {
    return (
      <SectionCard icon={Settings2} title="Sync Settings">
        <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
      </SectionCard>
    );
  }

  return (
    <SectionCard
      icon={Settings2}
      title="Sync Settings"
      description="Control how much is imported per run and which issue types are included. An empty issue-type selection imports all types."
    >
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="flex items-center gap-3">
          <Switch
            id="auto-sync"
            checked={settings.autoSyncEnabled}
            onCheckedChange={(v) => patch({ autoSyncEnabled: v })}
          />
          <Label htmlFor="auto-sync">Enable scheduled auto-sync</Label>
        </div>
        <div className="space-y-1.5">
          <Label>Frequency</Label>
          <Select value={settings.syncFrequency} onValueChange={(v) => patch({ syncFrequency: v })}>
            <SelectTrigger className="h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="manual">Manual</SelectItem>
              <SelectItem value="hourly">Hourly</SelectItem>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="max-issues">Max issues per run (0 = no cap)</Label>
          <Input
            id="max-issues"
            type="number"
            min={0}
            value={settings.maxIssuesPerRun}
            onChange={(e) => patch({ maxIssuesPerRun: Math.max(0, Number(e.target.value) || 0) })}
          />
        </div>
        <div className="space-y-1.5">
          <Label>Sync Mode</Label>
          <Select value={settings.syncMode} onValueChange={(v) => patch({ syncMode: v })}>
            <SelectTrigger className="h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="full">Full (upsert all)</SelectItem>
              <SelectItem value="incremental">Incremental</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Issue Types</Label>
        <div className="flex flex-wrap gap-4">
          {COMMON_ISSUE_TYPES.map((t) => (
            <label key={t} className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={settings.issueTypes.includes(t)}
                onCheckedChange={(v) => toggleIssueType(t, v === true)}
              />
              {t}
            </label>
          ))}
        </div>
        <p className="text-xs text-slate-400">
          {settings.issueTypes.length === 0
            ? "All issue types will be imported."
            : `Importing only: ${settings.issueTypes.join(", ")}.`}
        </p>
      </div>

      <Button onClick={save} disabled={saving} size="sm">
        {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
        Save Settings
      </Button>
    </SectionCard>
  );
}

// --- Sync History ------------------------------------------------------------

function runTone(run: JiraSyncRun): Tone {
  if (run.status === "completed") return "ok";
  if (run.status === "failed") return "error";
  return "warn";
}

function SyncHistorySection({ repo, activeMode }: { repo: ReturnType<typeof getJiraRepository>; activeMode: string }) {
  const [runs, setRuns] = useState<JiraSyncRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<JiraSyncResult | null>(null);
  const [msg, setMsg] = useState<{ tone: Tone; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setRuns(await repo.listSyncRuns(20));
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to load history." });
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    void load();
  }, [load]);

  const runSync = async () => {
    setSyncing(true);
    setSyncResult(null);
    setMsg(null);
    try {
      const result = await repo.runSync();
      setSyncResult(result);
      await load();
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Sync failed." });
    } finally {
      setSyncing(false);
    }
  };

  return (
    <SectionCard
      icon={History}
      title="Sync History"
      description="Run a sync now and review recent sync runs. Syncs honour the saved project selection, field/status mappings and settings."
    >
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      <div className="flex flex-wrap items-center gap-3">
        <Button onClick={runSync} disabled={syncing} size="sm">
          {syncing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4 mr-2" />
          )}
          Run Jira Sync
        </Button>
        <Button onClick={() => void load()} disabled={loading} variant="outline" size="sm">
          Refresh
        </Button>
        {syncResult && (
          <span className={`text-sm ${syncResult.ok ? "text-emerald-700" : "text-red-700"}`}>
            {syncResult.message}
            {syncResult.ok &&
              ` (${syncResult.run.recordsCreated} created, ${syncResult.run.recordsUpdated} updated)`}
          </span>
        )}
      </div>
      {activeMode === "mock" && (
        <p className="text-xs text-slate-400">
          In Mock mode the sync is simulated. Switch VITE_DATA_SOURCE to “postgres” to persist real
          records.
        </p>
      )}

      {loading ? (
        <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
      ) : runs.length === 0 ? (
        <p className="text-sm text-slate-500">No sync runs yet.</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Started</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Processed</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Updated</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {runs.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="whitespace-nowrap">
                  {new Date(r.syncStartedAt).toLocaleString()}
                </TableCell>
                <TableCell>
                  <Badge variant="secondary" className={TONE_BADGE[runTone(r)]}>
                    {r.status}
                  </Badge>
                </TableCell>
                <TableCell className="tabular-nums">{r.recordsProcessed}</TableCell>
                <TableCell className="tabular-nums">{r.recordsCreated}</TableCell>
                <TableCell className="tabular-nums">{r.recordsUpdated}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </SectionCard>
  );
}

// --- Status & Diagnostics ----------------------------------------------------

function StatusDiagnosticsSection({ repo }: { repo: ReturnType<typeof getJiraRepository> }) {
  const [status, setStatus] = useState<JiraStatus | null>(null);
  const [diag, setDiag] = useState<JiraDiagnostics | null>(null);
  const [statusMappings, setStatusMappings] = useState<JiraStatusMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ tone: Tone; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, d, sm] = await Promise.all([
        repo.getStatus(),
        repo.getDiagnostics(),
        repo.getStatusMappings(),
      ]);
      setStatus(s);
      setDiag(d);
      setStatusMappings(sm);
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to load diagnostics." });
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    void load();
  }, [load]);

  const updateStatusMap = (idx: number, patch: Partial<JiraStatusMapping>) => {
    setStatusMappings((prev) => prev.map((m, i) => (i === idx ? { ...m, ...patch } : m)));
  };

  const addStatusMap = () =>
    setStatusMappings((prev) => [
      ...prev,
      { id: `new-${prev.length}`, jiraStatus: "", matrixStatus: MATRIX_STATUS_OPTIONS[0] },
    ]);

  const removeStatusMap = (idx: number) =>
    setStatusMappings((prev) => prev.filter((_, i) => i !== idx));

  const saveStatusMaps = async () => {
    setSaving(true);
    setMsg(null);
    try {
      const saved = await repo.saveStatusMappings(
        statusMappings
          .filter((m) => m.jiraStatus.trim().length > 0)
          .map((m) => ({ jiraStatus: m.jiraStatus, matrixStatus: m.matrixStatus })),
      );
      setStatusMappings(saved);
      setMsg({ tone: "ok", text: "Status mappings saved." });
    } catch (err) {
      setMsg({ tone: "error", text: err instanceof Error ? err.message : "Failed to save status mappings." });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SectionCard icon={Activity} title="Status & Diagnostics">
        <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
      </SectionCard>
    );
  }

  return (
    <div className="space-y-6">
      <SectionCard
        icon={Activity}
        title="Diagnostics"
        description="Live connection status and import diagnostics from PostgreSQL."
      >
        {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
        {status && (
          <div className="flex flex-wrap items-center gap-3">
            <ConnBadge status={status} />
            {status.usingSampleData && (
              <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                Sample data
              </Badge>
            )}
            <span className="text-sm text-slate-600">{status.message}</span>
          </div>
        )}
        {diag && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatTile icon={FolderGit2} value={diag.projectsImported} label="Projects imported" />
            <StatTile icon={ListTodo} value={diag.issuesImported} label="Issues imported" />
            <StatTile icon={RefreshCw} value={diag.totalRuns} label="Total sync runs" />
            <StatTile
              icon={CheckCircle2}
              value={diag.lastSuccessfulSync?.recordsProcessed ?? 0}
              label="Last success records"
            />
          </div>
        )}
        {diag && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatTile
              icon={HeartPulse}
              value={`${diag.healthScore}/100`}
              label="Portfolio health score"
            />
            <StatTile icon={CircleDot} value={diag.openIssues} label="Open issues" />
            <StatTile icon={CheckCircle2} value={diag.completedIssues} label="Completed issues" />
            <StatTile icon={Ban} value={diag.blockedIssues} label="Blocked issues" />
            <StatTile icon={CalendarClock} value={diag.overdueIssues} label="Overdue issues" />
            <StatTile icon={Flame} value={diag.criticalIssues} label="Critical issues" />
            <StatTile
              icon={Timer}
              value={
                diag.lastSyncDurationMs == null
                  ? "—"
                  : `${(diag.lastSyncDurationMs / 1000).toFixed(1)}s`
              }
              label="Last sync duration"
            />
          </div>
        )}
        {diag && (
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-slate-500">
            {diag.lastSync && (
              <span>
                Last run: {new Date(diag.lastSync.syncStartedAt).toLocaleString()} ({diag.lastSync.status})
              </span>
            )}
            {diag.lastSuccessfulSync && (
              <span>
                Last success: {new Date(diag.lastSuccessfulSync.syncStartedAt).toLocaleString()}
              </span>
            )}
            {diag.lastFailedSync && (
              <span className="text-red-600">
                Last failure: {new Date(diag.lastFailedSync.syncStartedAt).toLocaleString()}
              </span>
            )}
          </div>
        )}
      </SectionCard>

      <SectionCard
        icon={Tags}
        title="Status Mapping"
        description="Translate Jira statuses onto Matrix statuses. Applied to every imported issue at sync time."
      >
        <div className="flex flex-wrap items-center gap-3">
          <Button onClick={addStatusMap} variant="outline" size="sm">
            Add Mapping
          </Button>
          <Button onClick={saveStatusMaps} disabled={saving} size="sm">
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Save Status Mappings
          </Button>
        </div>
        {statusMappings.length === 0 ? (
          <p className="text-sm text-slate-500">No status mappings. Add one to translate Jira statuses.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Jira Status</TableHead>
                <TableHead>Matrix Status</TableHead>
                <TableHead className="w-20" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {statusMappings.map((m, idx) => (
                <TableRow key={m.id}>
                  <TableCell>
                    <Input
                      className="h-8"
                      placeholder="e.g. In Review"
                      value={m.jiraStatus}
                      onChange={(e) => updateStatusMap(idx, { jiraStatus: e.target.value })}
                    />
                  </TableCell>
                  <TableCell>
                    <Select
                      value={m.matrixStatus}
                      onValueChange={(v) => updateStatusMap(idx, { matrixStatus: v })}
                    >
                      <SelectTrigger className="h-8 w-56">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MATRIX_STATUS_OPTIONS.map((s) => (
                          <SelectItem key={s} value={s}>
                            {s}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => removeStatusMap(idx)}>
                      Remove
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>
    </div>
  );
}

// --- Shell -------------------------------------------------------------------

export default function JiraConnector() {
  const activeMode = getDataSourceMode();
  const repo = getJiraRepository();

  return (
    <div className="space-y-6">
      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-slate-100 p-2">
                <Plug className="h-5 w-5 text-slate-600" />
              </div>
              <div>
                <CardTitle className="text-lg">Jira Connector</CardTitle>
                <CardDescription>
                  Configurable read-only ingestion of Jira projects and issues. The browser never
                  holds Jira credentials — config is stored server-side and data is read from
                  PostgreSQL through the API server.
                </CardDescription>
              </div>
            </div>
            <Badge variant="secondary" className="bg-slate-900 text-white shrink-0">
              Source: {activeMode === "postgres" ? "PostgreSQL" : "Mock"}
            </Badge>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="connection">
        <TabsList className="flex flex-wrap h-auto">
          <TabsTrigger value="connection">Connection</TabsTrigger>
          <TabsTrigger value="projects">Project Selection</TabsTrigger>
          <TabsTrigger value="fields">Field Mapping</TabsTrigger>
          <TabsTrigger value="settings">Sync Settings</TabsTrigger>
          <TabsTrigger value="history">Sync History</TabsTrigger>
          <TabsTrigger value="diagnostics">Status &amp; Diagnostics</TabsTrigger>
        </TabsList>

        <TabsContent value="connection" className="mt-4">
          <ConnectionSection repo={repo} />
        </TabsContent>
        <TabsContent value="projects" className="mt-4">
          <ProjectSelectionSection repo={repo} />
        </TabsContent>
        <TabsContent value="fields" className="mt-4">
          <FieldMappingSection repo={repo} />
        </TabsContent>
        <TabsContent value="settings" className="mt-4">
          <SyncSettingsSection repo={repo} />
        </TabsContent>
        <TabsContent value="history" className="mt-4">
          <SyncHistorySection repo={repo} activeMode={activeMode} />
        </TabsContent>
        <TabsContent value="diagnostics" className="mt-4">
          <StatusDiagnosticsSection repo={repo} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
