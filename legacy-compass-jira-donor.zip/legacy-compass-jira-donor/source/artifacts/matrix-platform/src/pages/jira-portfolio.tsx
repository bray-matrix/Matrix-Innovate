// Jira Portfolio Summary — executive intelligence over synced Jira data.
// Loads computed metrics + program/portfolio rollups + persisted snapshots
// through the repository layer (mock or postgres). The browser never touches
// Jira or PostgreSQL directly; all numbers come from @workspace/jira-intelligence
// via the repository.
import { useCallback, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Breadcrumbs, PanelCard, EmptyState, StatTile } from "@/components/detail/shared";
import {
  ExecutiveSummaryCards,
  PortfolioHealthPanel,
  StatusAnalyticsPanel,
  PriorityAnalyticsPanel,
  AgingDistributionPanel,
  RiskIndicatorsPanel,
  ExecutiveAlertsPanel,
  HealthClassBadge,
} from "@/components/jira/intelligence";
import { getDataSourceMode } from "@/repositories";
import { getJiraRepository } from "@/repositories/jira";
import type {
  JiraPortfolioSummary,
  JiraSyncSnapshot,
} from "@/repositories/jira/types";
import { Loader2, RefreshCw, Layers, FolderGit2, History } from "lucide-react";

export default function JiraPortfolio() {
  const activeMode = getDataSourceMode();
  const [summary, setSummary] = useState<JiraPortfolioSummary | null>(null);
  const [snapshots, setSnapshots] = useState<JiraSyncSnapshot[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const repo = getJiraRepository();
      const [s, snaps] = await Promise.all([repo.getPortfolioSummary(), repo.listSnapshots(20)]);
      setSummary(s);
      setSnapshots(snaps);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load Jira intelligence.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Breadcrumbs items={[{ label: "Administration", href: "/administration" }, { label: "Jira Portfolio" }]} />

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Jira Portfolio Summary</h1>
          <p className="text-slate-500 mt-1">
            Executive intelligence derived from synced Jira data.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="bg-slate-100 text-slate-600">
            Source: {activeMode}
          </Badge>
          <Button variant="outline" onClick={() => void load()} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
            Refresh
          </Button>
        </div>
      </div>

      {loading && !summary ? (
        <div className="flex items-center gap-3 text-slate-500 py-12 justify-center">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading executive intelligence…
        </div>
      ) : error ? (
        <Card className="border-red-200">
          <CardContent className="p-6 text-sm text-red-600">{error}</CardContent>
        </Card>
      ) : summary ? (
        <>
          <ExecutiveSummaryCards metrics={summary.metrics} />

          <ExecutiveAlertsPanel alerts={summary.metrics.alerts} />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PortfolioHealthPanel health={summary.metrics.portfolioHealth} />
            <StatusAnalyticsPanel status={summary.metrics.status} />
            <PriorityAnalyticsPanel priority={summary.metrics.priority} />
            <AgingDistributionPanel aging={summary.metrics.aging} />
          </div>

          <PanelCard title="Risk Indicators" description="Leading signals aggregated across the Jira portfolio.">
            <RiskIndicatorsPanel risk={summary.metrics.risk} />
          </PanelCard>

          <PortfolioRollupCards summary={summary} />

          <ProgramRollupTable summary={summary} />

          <ProjectMetricsTable summary={summary} />

          <SnapshotsTable snapshots={snapshots} />
        </>
      ) : null}
    </div>
  );
}

function PortfolioRollupCards({ summary }: { summary: JiraPortfolioSummary }) {
  const p = summary.portfolio;
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      <StatTile icon={Layers} value={p.programCount} label="Programs" />
      <StatTile icon={FolderGit2} value={p.projectCount} label="Mapped projects" />
      <StatTile value={p.totalOpen} label="Open issues" />
      <StatTile value={p.totalBlocked} label="Blocked" />
      <StatTile value={p.totalHighPriorityOpen} label="High-priority open" />
      <StatTile value={p.totalOverdue} label="Overdue" />
    </div>
  );
}

function ProgramRollupTable({ summary }: { summary: JiraPortfolioSummary }) {
  return (
    <PanelCard
      title="Program Rollups"
      description="Jira metrics rolled up onto Matrix programs via project mappings."
    >
      {summary.programs.length === 0 ? (
        <EmptyState message="No mapped programs yet — map Jira projects to Matrix programs in Administration → Jira → Project Selection." />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Program</TableHead>
              <TableHead>Health</TableHead>
              <TableHead className="text-right">Score</TableHead>
              <TableHead className="text-right">Projects</TableHead>
              <TableHead className="text-right">Issues</TableHead>
              <TableHead className="text-right">Open</TableHead>
              <TableHead className="text-right">Blocked</TableHead>
              <TableHead className="text-right">High-pri open</TableHead>
              <TableHead className="text-right">Overdue</TableHead>
              <TableHead className="text-right">Open SP</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {summary.programs.map((pr) => (
              <TableRow key={pr.programId}>
                <TableCell className="font-medium text-slate-900">{pr.programName}</TableCell>
                <TableCell><HealthClassBadge value={pr.healthClass} /></TableCell>
                <TableCell className="text-right">{pr.healthScore}</TableCell>
                <TableCell className="text-right">{pr.projectKeys.length}</TableCell>
                <TableCell className="text-right">{pr.issueCount}</TableCell>
                <TableCell className="text-right">{pr.openCount}</TableCell>
                <TableCell className="text-right">{pr.blockedCount}</TableCell>
                <TableCell className="text-right">{pr.highPriorityOpenCount}</TableCell>
                <TableCell className="text-right">{pr.overdueCount}</TableCell>
                <TableCell className="text-right">{pr.openStoryPoints}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </PanelCard>
  );
}

function ProjectMetricsTable({ summary }: { summary: JiraPortfolioSummary }) {
  const projects = summary.metrics.projects;
  return (
    <PanelCard title="Per-Project Metrics" description="Executive metrics for every synced Jira project.">
      {projects.length === 0 ? (
        <EmptyState message="No Jira projects synced yet." />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Project</TableHead>
              <TableHead>Health</TableHead>
              <TableHead className="text-right">Score</TableHead>
              <TableHead className="text-right">Issues</TableHead>
              <TableHead className="text-right">Open</TableHead>
              <TableHead className="text-right">Blocked</TableHead>
              <TableHead className="text-right">Critical</TableHead>
              <TableHead className="text-right">Overdue</TableHead>
              <TableHead className="text-right">Open SP</TableHead>
              <TableHead>Stale</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((m) => (
              <TableRow key={m.key}>
                <TableCell className="font-medium text-slate-900">
                  {m.name}
                  <span className="ml-2 text-xs font-normal text-slate-400">{m.key}</span>
                </TableCell>
                <TableCell><HealthClassBadge value={m.healthClass} /></TableCell>
                <TableCell className="text-right">{m.healthScore}</TableCell>
                <TableCell className="text-right">{m.issueCount}</TableCell>
                <TableCell className="text-right">{m.openCount}</TableCell>
                <TableCell className="text-right">{m.blockedCount}</TableCell>
                <TableCell className="text-right">{m.criticalCount}</TableCell>
                <TableCell className="text-right">{m.overdueCount}</TableCell>
                <TableCell className="text-right">{m.openStoryPoints}</TableCell>
                <TableCell>
                  {m.isStale ? (
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-amber-50 text-amber-700 border-amber-200">
                      {m.staleDays != null ? `${m.staleDays}d` : "Stale"}
                    </Badge>
                  ) : (
                    <span className="text-xs text-slate-400">—</span>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </PanelCard>
  );
}

function SnapshotsTable({ snapshots }: { snapshots: JiraSyncSnapshot[] }) {
  return (
    <PanelCard
      title={
        <span className="flex items-center gap-2">
          <History className="h-4 w-4 text-slate-400" />
          Sync Snapshots
        </span>
      }
      description="Point-in-time portfolio aggregates captured at each sync (trend framework)."
    >
      {snapshots.length === 0 ? (
        <EmptyState message="No snapshots captured yet — run a Jira sync to record one." />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Captured</TableHead>
              <TableHead className="text-right">Health</TableHead>
              <TableHead className="text-right">Projects</TableHead>
              <TableHead className="text-right">Issues</TableHead>
              <TableHead className="text-right">Open</TableHead>
              <TableHead className="text-right">Completed</TableHead>
              <TableHead className="text-right">Blocked</TableHead>
              <TableHead className="text-right">Critical</TableHead>
              <TableHead className="text-right">Overdue</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {snapshots.map((s) => (
              <TableRow key={s.id}>
                <TableCell className="text-slate-700">{new Date(s.capturedAt).toLocaleString()}</TableCell>
                <TableCell className="text-right font-medium">{s.healthScore}</TableCell>
                <TableCell className="text-right">{s.projectCount}</TableCell>
                <TableCell className="text-right">{s.issueCount}</TableCell>
                <TableCell className="text-right">{s.openCount}</TableCell>
                <TableCell className="text-right">{s.completedCount}</TableCell>
                <TableCell className="text-right">{s.blockedCount}</TableCell>
                <TableCell className="text-right">{s.criticalCount}</TableCell>
                <TableCell className="text-right">{s.overdueCount}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </PanelCard>
  );
}
