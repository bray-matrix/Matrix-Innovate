// Jira repository selector. Mirrors the domain repository: VITE_DATA_SOURCE
// chooses the active adapter (mock | postgres), defaulting to mock.
import { getDataSourceMode } from "@/repositories";
import type { JiraRepository } from "./types";
import { mockJiraRepository } from "./mock";
import { postgresJiraRepository } from "./postgres";

export * from "./types";
export { mockJiraRepository } from "./mock";
export { postgresJiraRepository } from "./postgres";

export function getJiraRepository(): JiraRepository {
  return getDataSourceMode() === "postgres" ? postgresJiraRepository : mockJiraRepository;
}
