// Mock Jira adapter (VITE_DATA_SOURCE=mock). Serves sample Jira data with no
// network or database, so Administration → Jira works when Jira is disabled. A
// "sync" here is synthetic — it returns a success result without persisting,
// since mock mode has no system of record.
//
// Configuration, mappings and settings are held in module-level state for the
// browser session so the admin UI is fully interactive in mock mode. Nothing is
// persisted; a reload resets to the sample defaults. The api token is never
// stored or echoed — only a presence flag and a masked hint, mirroring the
// server contract.
import {
  SAMPLE_JIRA_PROJECTS,
  SAMPLE_JIRA_ISSUES,
  SAMPLE_JIRA_LAST_SYNC,
  SAMPLE_JIRA_DISCOVERED_PROJECTS,
  SAMPLE_JIRA_DISCOVERED_FIELDS,
  SAMPLE_JIRA_STATUS_MAPPINGS,
} from "./sampleJira";
import {
  computeMetrics,
  computeSnapshot,
  computeProgramRollups,
  computePortfolioRollup,
} from "./intelligence";
import type {
  JiraRepository,
  JiraIssueFilters,
  JiraStatus,
  JiraProject,
  JiraIssue,
  JiraSyncResult,
  JiraConfig,
  JiraConfigInput,
  JiraConnectionTest,
  JiraDiscoveredProject,
  JiraDiscoveredField,
  JiraProjectMapping,
  JiraProjectMappingInput,
  JiraFieldMapping,
  JiraFieldMappingInput,
  JiraStatusMapping,
  JiraStatusMappingInput,
  JiraSyncSettings,
  JiraSyncSettingsInput,
  JiraDiagnostics,
  JiraSyncRun,
  JiraSyncSnapshot,
  ExecutiveMetrics,
  ProjectMetric,
  ProgramRollup,
  PortfolioRollup,
  JiraPortfolioSummary,
} from "./types";

// --- In-session mock state ---------------------------------------------------

interface MockConfigState {
  baseUrl: string | null;
  email: string | null;
  enabled: boolean;
  hasApiToken: boolean;
  serverTitle: string | null;
  authenticatedUser: string | null;
  lastTestAt: string | null;
  lastTestOk: boolean | null;
  lastTestMessage: string | null;
}

const configState: MockConfigState = {
  baseUrl: null,
  email: null,
  enabled: false,
  hasApiToken: false,
  serverTitle: null,
  authenticatedUser: null,
  lastTestAt: null,
  lastTestOk: null,
  lastTestMessage: null,
};

let discoveredProjects: JiraDiscoveredProject[] = [];
let discoveredFields: JiraDiscoveredField[] = [];

// Project mappings default to "all selected" so mock sync mirrors the legacy
// behaviour (import everything) until the admin narrows the selection.
let projectMappings: JiraProjectMapping[] = SAMPLE_JIRA_PROJECTS.map((p) => ({
  id: p.jiraProjectKey,
  jiraProjectKey: p.jiraProjectKey,
  selected: true,
  matrixProgramId: null,
  matrixPortfolioCategory: null,
}));

let fieldMappings: JiraFieldMapping[] = [
  {
    id: "storyPoints",
    matrixConcept: "storyPoints",
    jiraFieldId: "customfield_10016",
    jiraFieldName: "Story Points",
  },
];

let statusMappings: JiraStatusMapping[] = [...SAMPLE_JIRA_STATUS_MAPPINGS];

let syncSettings: JiraSyncSettings = {
  autoSyncEnabled: false,
  syncFrequency: "manual",
  maxIssuesPerRun: 500,
  syncMode: "full",
  issueTypes: [],
};

const syncRuns: JiraSyncRun[] = [SAMPLE_JIRA_LAST_SYNC];

function tokenHint(): string | null {
  return configState.hasApiToken ? "••••••••" : null;
}

function syncRunDurationMs(run: JiraSyncRun): number | null {
  if (!run.syncCompletedAt) return null;
  const ms = new Date(run.syncCompletedAt).getTime() - new Date(run.syncStartedAt).getTime();
  return Number.isFinite(ms) && ms >= 0 ? ms : null;
}

function buildConfig(): JiraConfig {
  return {
    baseUrl: configState.baseUrl,
    email: configState.email,
    enabled: configState.enabled,
    hasApiToken: configState.hasApiToken,
    apiTokenHint: tokenHint(),
    source: configState.hasApiToken ? "database" : "none",
    serverTitle: configState.serverTitle,
    authenticatedUser: configState.authenticatedUser,
    lastTestAt: configState.lastTestAt,
    lastTestOk: configState.lastTestOk,
    lastTestMessage: configState.lastTestMessage,
  };
}

export const mockJiraRepository: JiraRepository = {
  async getStatus(): Promise<JiraStatus> {
    return {
      configured: false,
      reachable: false,
      usingSampleData: true,
      message: "Mock data source — showing sample Jira data (no live connection).",
      checkedAt: new Date().toISOString(),
      baseUrl: null,
      projectCount: SAMPLE_JIRA_PROJECTS.length,
      issueCount: SAMPLE_JIRA_ISSUES.length,
      lastSync: SAMPLE_JIRA_LAST_SYNC,
    };
  },

  async listProjects(): Promise<JiraProject[]> {
    return SAMPLE_JIRA_PROJECTS;
  },

  async getProject(id: string): Promise<JiraProject | undefined> {
    return SAMPLE_JIRA_PROJECTS.find((p) => p.id === id);
  },

  async listIssues(filters: JiraIssueFilters = {}): Promise<JiraIssue[]> {
    return SAMPLE_JIRA_ISSUES.filter((i) => {
      if (filters.projectKey && i.jiraProjectKey !== filters.projectKey) return false;
      if (filters.status && i.status !== filters.status) return false;
      return true;
    });
  },

  async getIssue(id: string): Promise<JiraIssue | undefined> {
    return SAMPLE_JIRA_ISSUES.find((i) => i.id === id);
  },

  async runSync(): Promise<JiraSyncResult> {
    return {
      ok: true,
      usingSampleData: true,
      message: "Mock mode — sample data is already loaded; nothing to persist.",
      run: SAMPLE_JIRA_LAST_SYNC,
      projectCount: SAMPLE_JIRA_PROJECTS.length,
      issueCount: SAMPLE_JIRA_ISSUES.length,
    };
  },

  // --- T022.5 ---------------------------------------------------------------

  async getConfig(): Promise<JiraConfig> {
    return buildConfig();
  },

  async saveConfig(input: JiraConfigInput): Promise<JiraConfig> {
    configState.baseUrl = input.baseUrl;
    configState.email = input.email;
    configState.enabled = input.enabled;
    // Preserve the existing token presence when an empty token is submitted.
    if (input.apiToken && input.apiToken.length > 0) {
      configState.hasApiToken = true;
    }
    return buildConfig();
  },

  async testConnection(): Promise<JiraConnectionTest> {
    const checkedAt = new Date().toISOString();
    const message = "Mock mode — sample connection is always reported healthy.";
    configState.lastTestAt = checkedAt;
    configState.lastTestOk = true;
    configState.lastTestMessage = message;
    configState.serverTitle = "Matrix Sample Jira";
    configState.authenticatedUser = configState.email ?? "sample.user@matrix.test";
    return {
      ok: true,
      configured: false,
      usingSampleData: true,
      message,
      authenticatedUser: configState.authenticatedUser,
      serverTitle: configState.serverTitle,
      baseUrl: configState.baseUrl,
      checkedAt,
    };
  },

  async discoverProjects(): Promise<JiraDiscoveredProject[]> {
    discoveredProjects = SAMPLE_JIRA_DISCOVERED_PROJECTS.map((p) => ({ ...p }));
    return discoveredProjects;
  },

  async listDiscoveredProjects(): Promise<JiraDiscoveredProject[]> {
    return discoveredProjects;
  },

  async discoverFields(): Promise<JiraDiscoveredField[]> {
    discoveredFields = SAMPLE_JIRA_DISCOVERED_FIELDS.map((f) => ({ ...f }));
    return discoveredFields;
  },

  async listDiscoveredFields(): Promise<JiraDiscoveredField[]> {
    return discoveredFields;
  },

  async getProjectMappings(): Promise<JiraProjectMapping[]> {
    return projectMappings;
  },

  async saveProjectMappings(input: JiraProjectMappingInput[]): Promise<JiraProjectMapping[]> {
    projectMappings = input.map((m) => ({
      id: m.jiraProjectKey,
      jiraProjectKey: m.jiraProjectKey,
      selected: m.selected,
      matrixProgramId: m.matrixProgramId ?? null,
      matrixPortfolioCategory: m.matrixPortfolioCategory ?? null,
    }));
    return projectMappings;
  },

  async getFieldMappings(): Promise<JiraFieldMapping[]> {
    return fieldMappings;
  },

  async saveFieldMappings(input: JiraFieldMappingInput[]): Promise<JiraFieldMapping[]> {
    fieldMappings = input.map((m) => ({
      id: m.matrixConcept,
      matrixConcept: m.matrixConcept,
      jiraFieldId: m.jiraFieldId ?? null,
      jiraFieldName: m.jiraFieldName ?? null,
    }));
    return fieldMappings;
  },

  async getStatusMappings(): Promise<JiraStatusMapping[]> {
    return statusMappings;
  },

  async saveStatusMappings(input: JiraStatusMappingInput[]): Promise<JiraStatusMapping[]> {
    statusMappings = input.map((m) => ({
      id: `JIRA-STATUS-${m.jiraStatus.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
      jiraStatus: m.jiraStatus,
      matrixStatus: m.matrixStatus,
    }));
    return statusMappings;
  },

  async getSyncSettings(): Promise<JiraSyncSettings> {
    return syncSettings;
  },

  async saveSyncSettings(input: JiraSyncSettingsInput): Promise<JiraSyncSettings> {
    syncSettings = { ...input };
    return syncSettings;
  },

  async listSyncRuns(limit = 10): Promise<JiraSyncRun[]> {
    return syncRuns.slice(0, limit);
  },

  async getDiagnostics(): Promise<JiraDiagnostics> {
    const metrics = computeMetrics(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES);
    return {
      lastSync: SAMPLE_JIRA_LAST_SYNC,
      lastSuccessfulSync: SAMPLE_JIRA_LAST_SYNC,
      lastFailedSync: null,
      totalRuns: syncRuns.length,
      projectsImported: SAMPLE_JIRA_PROJECTS.length,
      issuesImported: SAMPLE_JIRA_ISSUES.length,
      openIssues: metrics.summary.openIssues,
      completedIssues: metrics.summary.completedIssues,
      blockedIssues: metrics.summary.blockedIssues,
      overdueIssues: metrics.summary.overdueIssues,
      criticalIssues: metrics.summary.criticalIssues,
      healthScore: metrics.healthScore,
      lastSyncDurationMs: syncRunDurationMs(SAMPLE_JIRA_LAST_SYNC),
      recentRuns: syncRuns.slice(0, 10),
    };
  },

  // --- T022.7: executive intelligence ----------------------------------------

  async getExecutiveMetrics(): Promise<ExecutiveMetrics> {
    return computeMetrics(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES);
  },

  async getProjectMetrics(): Promise<ProjectMetric[]> {
    return computeMetrics(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES).projects;
  },

  async getProgramRollups(): Promise<ProgramRollup[]> {
    const metrics = computeMetrics(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES);
    return computeProgramRollups(metrics, projectMappings);
  },

  async getPortfolioRollups(): Promise<PortfolioRollup> {
    const metrics = computeMetrics(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES);
    return computePortfolioRollup(computeProgramRollups(metrics, projectMappings));
  },

  async getPortfolioSummary(): Promise<JiraPortfolioSummary> {
    const metrics = computeMetrics(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES);
    const programs = computeProgramRollups(metrics, projectMappings);
    return { metrics, programs, portfolio: computePortfolioRollup(programs) };
  },

  async listSnapshots(limit = 30): Promise<JiraSyncSnapshot[]> {
    // Mock mode has no persistence; synthesize a single point-in-time snapshot
    // from the current sample data so the trend UI has something to render.
    const snap = computeSnapshot(SAMPLE_JIRA_PROJECTS, SAMPLE_JIRA_ISSUES);
    const wire: JiraSyncSnapshot = {
      id: "JIRA-SNAP-MOCK",
      capturedAt: snap.capturedAt,
      syncRunId: SAMPLE_JIRA_LAST_SYNC.id,
      projectCount: snap.projectCount,
      issueCount: snap.issueCount,
      openCount: snap.openCount,
      completedCount: snap.completedCount,
      blockedCount: snap.blockedCount,
      criticalCount: snap.criticalCount,
      overdueCount: snap.overdueCount,
      highestPriorityCount: snap.priority.highest,
      highPriorityCount: snap.priority.high,
      mediumPriorityCount: snap.priority.medium,
      lowPriorityCount: snap.priority.low,
      healthScore: snap.healthScore,
    };
    return [wire].slice(0, limit);
  },
};
