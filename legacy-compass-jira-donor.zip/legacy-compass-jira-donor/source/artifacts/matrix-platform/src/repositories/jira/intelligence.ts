// Shared client-side executive-intelligence compute for the Jira repository.
// Both the mock and postgres adapters map their wire data into the pure
// @workspace/jira-intelligence inputs and compute here, so the numbers are
// identical regardless of data source. Program/portfolio rollups live here too
// because only the frontend has BOTH Jira project metrics AND Matrix domain data
// (programs from data.ts + the project→program mappings).
import {
  computeExecutiveMetrics,
  buildSnapshot,
  rollupByProgram,
  rollupPortfolio,
  type ExecutiveMetrics,
  type IntelIssue,
  type IntelProject,
  type IntelSnapshot,
  type ProgramMappingEntry,
  type ProgramRollup,
  type PortfolioRollup,
} from "@workspace/jira-intelligence";
import { getProgram } from "@/lib/data";
import type { JiraProject, JiraIssue, JiraProjectMapping } from "./types";

function projectToIntel(p: JiraProject): IntelProject {
  return { key: p.jiraProjectKey, name: p.jiraProjectName };
}

function issueToIntel(i: JiraIssue): IntelIssue {
  return {
    key: i.jiraIssueKey,
    projectKey: i.jiraProjectKey,
    issueType: i.issueType,
    status: i.status,
    priority: i.priority,
    assigneeName: i.assigneeName,
    storyPoints: i.storyPoints,
    createdDate: i.createdDate,
    updatedDate: i.updatedDate,
    dueDate: i.dueDate,
    resolutionDate: i.resolutionDate,
  };
}

export function computeMetrics(
  projects: JiraProject[],
  issues: JiraIssue[],
): ExecutiveMetrics {
  return computeExecutiveMetrics(projects.map(projectToIntel), issues.map(issueToIntel));
}

export function computeSnapshot(
  projects: JiraProject[],
  issues: JiraIssue[],
): IntelSnapshot {
  return buildSnapshot(
    projects.map(projectToIntel),
    issues.map(issueToIntel),
    new Date().toISOString(),
  );
}

// Resolve project→program mapping entries from the saved Jira project mappings,
// pulling program display names from the Matrix domain (data.ts). Mappings with
// no matrixProgramId are skipped (unmapped projects don't roll up).
export function buildProgramMapping(mappings: JiraProjectMapping[]): ProgramMappingEntry[] {
  const entries: ProgramMappingEntry[] = [];
  for (const m of mappings) {
    if (!m.matrixProgramId) continue;
    const program = getProgram(m.matrixProgramId);
    entries.push({
      projectKey: m.jiraProjectKey,
      programId: m.matrixProgramId,
      programName: program?.name ?? m.matrixProgramId,
    });
  }
  return entries;
}

export function computeProgramRollups(
  metrics: ExecutiveMetrics,
  mappings: JiraProjectMapping[],
): ProgramRollup[] {
  return rollupByProgram(metrics.projects, buildProgramMapping(mappings));
}

export function computePortfolioRollup(programs: ProgramRollup[]): PortfolioRollup {
  return rollupPortfolio(programs);
}
