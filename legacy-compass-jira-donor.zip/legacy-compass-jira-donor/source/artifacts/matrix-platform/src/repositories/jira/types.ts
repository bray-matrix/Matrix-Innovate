// Frontend Jira repository contract. Mirrors the existing repository pattern:
// a mock adapter (sample data) and a postgres adapter (api-server fetchers),
// selected by VITE_DATA_SOURCE. The UI talks ONLY to this layer — never to Jira
// or the database directly.
//
// Wire types come straight from the generated API client so the UI and server
// stay in lockstep with the OpenAPI contract.
import type {
  JiraStatus,
  JiraProject,
  JiraIssue,
  JiraSyncRun,
  JiraSyncResult,
  JiraConfig,
  JiraConfigInput,
  JiraConnectionTest,
  JiraDiscoveredProject,
  JiraDiscoveredField,
  JiraProjectMapping,
  JiraProjectMappingInput,
  JiraFieldMapping,
  JiraFieldMappingInput,
  JiraStatusMapping,
  JiraStatusMappingInput,
  JiraSyncSettings,
  JiraSyncSettingsInput,
  JiraDiagnostics,
  JiraSyncSnapshot,
  JiraProjectMetric,
} from "@workspace/api-client-react";

export type {
  JiraStatus,
  JiraProject,
  JiraIssue,
  JiraSyncRun,
  JiraSyncResult,
  JiraConfig,
  JiraConfigInput,
  JiraConnectionTest,
  JiraDiscoveredProject,
  JiraDiscoveredField,
  JiraProjectMapping,
  JiraProjectMappingInput,
  JiraFieldMapping,
  JiraFieldMappingInput,
  JiraStatusMapping,
  JiraStatusMappingInput,
  JiraSyncSettings,
  JiraSyncSettingsInput,
  JiraDiagnostics,
  JiraSyncSnapshot,
  JiraProjectMetric,
};

// Computed executive-intelligence types come from the shared pure lib. The
// repository computes them client-side from issues/projects via the lib so mock
// and postgres modes are identical by construction.
export type {
  ExecutiveMetrics,
  ProjectMetric,
  PortfolioHealth,
  StatusCounts,
  PriorityCounts,
  AgingCounts,
  RiskIndicators,
  ExecutiveAlert,
  HealthClass,
  IntelSnapshot,
  ProgramRollup,
  PortfolioRollup,
} from "@workspace/jira-intelligence";

import type {
  ExecutiveMetrics,
  ProjectMetric,
  ProgramRollup,
  PortfolioRollup,
} from "@workspace/jira-intelligence";

// Composite view consumed by the Jira Portfolio Summary page: portfolio-wide
// executive metrics plus program rollups (using Matrix project→program mappings)
// and the aggregate portfolio rollup.
export interface JiraPortfolioSummary {
  metrics: ExecutiveMetrics;
  programs: ProgramRollup[];
  portfolio: PortfolioRollup;
}

export interface JiraIssueFilters {
  projectKey?: string;
  status?: string;
}

export interface JiraRepository {
  getStatus(): Promise<JiraStatus>;
  listProjects(): Promise<JiraProject[]>;
  getProject(id: string): Promise<JiraProject | undefined>;
  listIssues(filters?: JiraIssueFilters): Promise<JiraIssue[]>;
  getIssue(id: string): Promise<JiraIssue | undefined>;
  runSync(): Promise<JiraSyncResult>;

  // --- T022.5: configuration, discovery, mappings, settings, diagnostics -----
  getConfig(): Promise<JiraConfig>;
  saveConfig(input: JiraConfigInput): Promise<JiraConfig>;
  testConnection(): Promise<JiraConnectionTest>;

  discoverProjects(): Promise<JiraDiscoveredProject[]>;
  listDiscoveredProjects(): Promise<JiraDiscoveredProject[]>;
  discoverFields(): Promise<JiraDiscoveredField[]>;
  listDiscoveredFields(): Promise<JiraDiscoveredField[]>;

  getProjectMappings(): Promise<JiraProjectMapping[]>;
  saveProjectMappings(input: JiraProjectMappingInput[]): Promise<JiraProjectMapping[]>;
  getFieldMappings(): Promise<JiraFieldMapping[]>;
  saveFieldMappings(input: JiraFieldMappingInput[]): Promise<JiraFieldMapping[]>;
  getStatusMappings(): Promise<JiraStatusMapping[]>;
  saveStatusMappings(input: JiraStatusMappingInput[]): Promise<JiraStatusMapping[]>;

  getSyncSettings(): Promise<JiraSyncSettings>;
  saveSyncSettings(input: JiraSyncSettingsInput): Promise<JiraSyncSettings>;

  listSyncRuns(limit?: number): Promise<JiraSyncRun[]>;
  getDiagnostics(): Promise<JiraDiagnostics>;

  // --- T022.7: executive intelligence ----------------------------------------
  // Live executive metrics computed from issues/projects via the shared lib.
  getExecutiveMetrics(): Promise<ExecutiveMetrics>;
  // Per-project metrics (subset of getExecutiveMetrics, convenience accessor).
  getProjectMetrics(): Promise<ProjectMetric[]>;
  // Program rollups using the Matrix project→program mappings.
  getProgramRollups(): Promise<ProgramRollup[]>;
  // Aggregate portfolio rollup across all mapped programs.
  getPortfolioRollups(): Promise<PortfolioRollup>;
  // Composite portfolio summary (metrics + program rollups + portfolio rollup).
  getPortfolioSummary(): Promise<JiraPortfolioSummary>;
  // Persisted point-in-time snapshots (trend framework).
  listSnapshots(limit?: number): Promise<JiraSyncSnapshot[]>;
}
