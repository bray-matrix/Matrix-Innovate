// PostgreSQL Jira adapter (VITE_DATA_SOURCE=postgres). Talks ONLY to the
// api-server via generated fetchers; the browser never reaches Jira or the
// database directly. Reads are honest — get-by-id 404s surface as `undefined`.
import {
  getJiraStatus,
  listJiraProjects,
  getJiraProject,
  listJiraIssues,
  getJiraIssue,
  runJiraSync,
  getJiraConfig,
  updateJiraConfig,
  testJiraConnection,
  discoverJiraProjects,
  listJiraDiscoveredProjects,
  discoverJiraFields,
  listJiraDiscoveredFields,
  getJiraProjectMappings,
  updateJiraProjectMappings,
  getJiraFieldMappings,
  updateJiraFieldMappings,
  getJiraStatusMappings,
  updateJiraStatusMappings,
  getJiraSyncSettings,
  updateJiraSyncSettings,
  listJiraSyncRuns,
  getJiraDiagnostics,
  listJiraSnapshots,
} from "@workspace/api-client-react";
import {
  computeMetrics,
  computeProgramRollups,
  computePortfolioRollup,
} from "./intelligence";
import type {
  JiraRepository,
  JiraIssueFilters,
  JiraStatus,
  JiraProject,
  JiraIssue,
  JiraSyncResult,
  JiraConfig,
  JiraConfigInput,
  JiraConnectionTest,
  JiraDiscoveredProject,
  JiraDiscoveredField,
  JiraProjectMapping,
  JiraProjectMappingInput,
  JiraFieldMapping,
  JiraFieldMappingInput,
  JiraStatusMapping,
  JiraStatusMappingInput,
  JiraSyncSettings,
  JiraSyncSettingsInput,
  JiraDiagnostics,
  JiraSyncRun,
  JiraSyncSnapshot,
  ExecutiveMetrics,
  ProjectMetric,
  ProgramRollup,
  PortfolioRollup,
  JiraPortfolioSummary,
} from "./types";

// get-by-id fetchers throw an ApiError (status 404) when nothing matches; treat
// that as "no record" and surface `undefined`. Other errors propagate so real
// outages are not silently masked.
function isNotFound(err: unknown): boolean {
  return typeof err === "object" && err !== null && (err as { status?: number }).status === 404;
}

export const postgresJiraRepository: JiraRepository = {
  async getStatus(): Promise<JiraStatus> {
    return getJiraStatus();
  },

  async listProjects(): Promise<JiraProject[]> {
    return listJiraProjects();
  },

  async getProject(id: string): Promise<JiraProject | undefined> {
    try {
      return await getJiraProject(id);
    } catch (err) {
      if (isNotFound(err)) return undefined;
      throw err;
    }
  },

  async listIssues(filters: JiraIssueFilters = {}): Promise<JiraIssue[]> {
    return listJiraIssues({
      projectKey: filters.projectKey,
      status: filters.status,
    });
  },

  async getIssue(id: string): Promise<JiraIssue | undefined> {
    try {
      return await getJiraIssue(id);
    } catch (err) {
      if (isNotFound(err)) return undefined;
      throw err;
    }
  },

  async runSync(): Promise<JiraSyncResult> {
    return runJiraSync();
  },

  // --- T022.5 ---------------------------------------------------------------

  async getConfig(): Promise<JiraConfig> {
    return getJiraConfig();
  },

  async saveConfig(input: JiraConfigInput): Promise<JiraConfig> {
    return updateJiraConfig(input);
  },

  async testConnection(): Promise<JiraConnectionTest> {
    return testJiraConnection();
  },

  async discoverProjects(): Promise<JiraDiscoveredProject[]> {
    return discoverJiraProjects();
  },

  async listDiscoveredProjects(): Promise<JiraDiscoveredProject[]> {
    return listJiraDiscoveredProjects();
  },

  async discoverFields(): Promise<JiraDiscoveredField[]> {
    return discoverJiraFields();
  },

  async listDiscoveredFields(): Promise<JiraDiscoveredField[]> {
    return listJiraDiscoveredFields();
  },

  async getProjectMappings(): Promise<JiraProjectMapping[]> {
    return getJiraProjectMappings();
  },

  async saveProjectMappings(input: JiraProjectMappingInput[]): Promise<JiraProjectMapping[]> {
    return updateJiraProjectMappings(input);
  },

  async getFieldMappings(): Promise<JiraFieldMapping[]> {
    return getJiraFieldMappings();
  },

  async saveFieldMappings(input: JiraFieldMappingInput[]): Promise<JiraFieldMapping[]> {
    return updateJiraFieldMappings(input);
  },

  async getStatusMappings(): Promise<JiraStatusMapping[]> {
    return getJiraStatusMappings();
  },

  async saveStatusMappings(input: JiraStatusMappingInput[]): Promise<JiraStatusMapping[]> {
    return updateJiraStatusMappings(input);
  },

  async getSyncSettings(): Promise<JiraSyncSettings> {
    return getJiraSyncSettings();
  },

  async saveSyncSettings(input: JiraSyncSettingsInput): Promise<JiraSyncSettings> {
    return updateJiraSyncSettings(input);
  },

  async listSyncRuns(limit = 10): Promise<JiraSyncRun[]> {
    return listJiraSyncRuns({ limit });
  },

  async getDiagnostics(): Promise<JiraDiagnostics> {
    return getJiraDiagnostics();
  },

  // --- T022.7: executive intelligence ----------------------------------------
  // Executive metrics + rollups are computed client-side from the persisted
  // issues/projects via the shared lib, so they are identical to mock mode by
  // construction. Snapshots are read from the real server endpoint (server-side
  // persisted aggregates) so the trend framework reflects history.

  async getExecutiveMetrics(): Promise<ExecutiveMetrics> {
    const [projects, issues] = await Promise.all([listJiraProjects(), listJiraIssues({})]);
    return computeMetrics(projects, issues);
  },

  async getProjectMetrics(): Promise<ProjectMetric[]> {
    const [projects, issues] = await Promise.all([listJiraProjects(), listJiraIssues({})]);
    return computeMetrics(projects, issues).projects;
  },

  async getProgramRollups(): Promise<ProgramRollup[]> {
    const [projects, issues, mappings] = await Promise.all([
      listJiraProjects(),
      listJiraIssues({}),
      getJiraProjectMappings(),
    ]);
    return computeProgramRollups(computeMetrics(projects, issues), mappings);
  },

  async getPortfolioRollups(): Promise<PortfolioRollup> {
    const programs = await this.getProgramRollups();
    return computePortfolioRollup(programs);
  },

  async getPortfolioSummary(): Promise<JiraPortfolioSummary> {
    const [projects, issues, mappings] = await Promise.all([
      listJiraProjects(),
      listJiraIssues({}),
      getJiraProjectMappings(),
    ]);
    const metrics = computeMetrics(projects, issues);
    const programs = computeProgramRollups(metrics, mappings);
    return { metrics, programs, portfolio: computePortfolioRollup(programs) };
  },

  async listSnapshots(limit = 30): Promise<JiraSyncSnapshot[]> {
    return listJiraSnapshots({ limit });
  },
};
