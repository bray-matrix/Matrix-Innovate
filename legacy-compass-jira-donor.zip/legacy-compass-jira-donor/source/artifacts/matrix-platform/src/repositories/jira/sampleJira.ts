// Sample Jira data for the mock adapter (VITE_DATA_SOURCE=mock). Lets the
// Administration → Jira screen function fully without a database or Jira
// credentials. Shapes match the generated wire types. Mirrors the api-server's
// sample connector data; artifacts cannot import each other, so a small,
// deliberate duplication is acceptable.
import type {
  JiraProject,
  JiraIssue,
  JiraSyncRun,
  JiraDiscoveredProject,
  JiraDiscoveredField,
  JiraStatusMapping,
} from "./types";

export const SAMPLE_JIRA_PROJECTS: JiraProject[] = [
  {
    id: "JIRA-PROJ-10001",
    jiraProjectId: "10001",
    jiraProjectKey: "MIG",
    jiraProjectName: "Client Migration Program",
    projectType: "software",
    leadName: "Dana Whitfield",
    leadAccountId: "acc-100",
    isActive: true,
  },
  {
    id: "JIRA-PROJ-10002",
    jiraProjectId: "10002",
    jiraProjectKey: "ONB",
    jiraProjectName: "Onboarding & Implementation",
    projectType: "software",
    leadName: "Marcus Lee",
    leadAccountId: "acc-101",
    isActive: true,
  },
  {
    id: "JIRA-PROJ-10003",
    jiraProjectId: "10003",
    jiraProjectKey: "SUP",
    jiraProjectName: "Production Support",
    projectType: "service_desk",
    leadName: "Priya Nair",
    leadAccountId: "acc-102",
    isActive: true,
  },
];

export const SAMPLE_JIRA_ISSUES: JiraIssue[] = [
  {
    id: "JIRA-ISSUE-20001",
    jiraIssueId: "20001",
    jiraIssueKey: "MIG-101",
    jiraProjectKey: "MIG",
    summary: "Data mapping for legacy account import",
    description: "Map legacy CRM fields to the new schema before the cutover.",
    issueType: "Story",
    status: "In Progress",
    priority: "High",
    assigneeName: "Dana Whitfield",
    assigneeAccountId: "acc-100",
    reporterName: "Marcus Lee",
    storyPoints: 8,
    createdDate: "2026-05-02T09:15:00.000Z",
    updatedDate: "2026-06-18T14:30:00.000Z",
    dueDate: "2026-07-01",
    resolutionDate: null,
  },
  {
    id: "JIRA-ISSUE-20002",
    jiraIssueId: "20002",
    jiraIssueKey: "MIG-102",
    jiraProjectKey: "MIG",
    summary: "Cutover runbook review",
    description: "Review and sign off the production cutover runbook.",
    issueType: "Task",
    status: "To Do",
    priority: "Medium",
    assigneeName: "Priya Nair",
    assigneeAccountId: "acc-102",
    reporterName: "Dana Whitfield",
    storyPoints: 3,
    createdDate: "2026-05-10T11:00:00.000Z",
    updatedDate: "2026-06-12T08:45:00.000Z",
    dueDate: "2026-07-05",
    resolutionDate: null,
  },
  {
    id: "JIRA-ISSUE-20003",
    jiraIssueId: "20003",
    jiraIssueKey: "ONB-210",
    jiraProjectKey: "ONB",
    summary: "Configure tenant SSO",
    description: "Set up SAML SSO for the new client tenant.",
    issueType: "Story",
    status: "Done",
    priority: "High",
    assigneeName: "Marcus Lee",
    assigneeAccountId: "acc-101",
    reporterName: "Priya Nair",
    storyPoints: 5,
    createdDate: "2026-04-20T13:20:00.000Z",
    updatedDate: "2026-05-28T16:10:00.000Z",
    dueDate: "2026-05-25",
    resolutionDate: "2026-05-28T16:10:00.000Z",
  },
  {
    id: "JIRA-ISSUE-20004",
    jiraIssueId: "20004",
    jiraIssueKey: "ONB-211",
    jiraProjectKey: "ONB",
    summary: "Welcome kit content review",
    description: "Review onboarding welcome kit copy with the client success team.",
    issueType: "Task",
    status: "In Progress",
    priority: "Low",
    assigneeName: "Dana Whitfield",
    assigneeAccountId: "acc-100",
    reporterName: "Marcus Lee",
    storyPoints: 2,
    createdDate: "2026-06-01T10:05:00.000Z",
    updatedDate: "2026-06-20T09:00:00.000Z",
    dueDate: "2026-07-10",
    resolutionDate: null,
  },
  {
    id: "JIRA-ISSUE-20005",
    jiraIssueId: "20005",
    jiraIssueKey: "SUP-330",
    jiraProjectKey: "SUP",
    summary: "Investigate elevated API latency",
    description: "P2 incident: API latency spiked after the latest release.",
    issueType: "Bug",
    status: "In Progress",
    priority: "Highest",
    assigneeName: "Priya Nair",
    assigneeAccountId: "acc-102",
    reporterName: "Dana Whitfield",
    storyPoints: null,
    createdDate: "2026-06-19T07:40:00.000Z",
    updatedDate: "2026-06-23T18:25:00.000Z",
    dueDate: null,
    resolutionDate: null,
  },
];

export const SAMPLE_JIRA_LAST_SYNC: JiraSyncRun = {
  id: "sample-sync-001",
  syncStartedAt: "2026-06-23T18:30:00.000Z",
  syncCompletedAt: "2026-06-23T18:30:02.000Z",
  status: "completed",
  recordsProcessed: SAMPLE_JIRA_PROJECTS.length + SAMPLE_JIRA_ISSUES.length,
  recordsCreated: SAMPLE_JIRA_PROJECTS.length + SAMPLE_JIRA_ISSUES.length,
  recordsUpdated: 0,
  errorMessage: null,
};

const SAMPLE_DISCOVERED_AT = "2026-06-23T18:30:00.000Z";

export const SAMPLE_JIRA_DISCOVERED_PROJECTS: JiraDiscoveredProject[] =
  SAMPLE_JIRA_PROJECTS.map((p) => ({
    id: `JIRA-DPROJ-${p.jiraProjectId}`,
    jiraProjectId: p.jiraProjectId,
    jiraProjectKey: p.jiraProjectKey,
    jiraProjectName: p.jiraProjectName,
    projectType: p.projectType,
    leadName: p.leadName,
    status: p.isActive ? "active" : "archived",
    discoveredAt: SAMPLE_DISCOVERED_AT,
  }));

// Sample field catalog. Includes a custom "Story Points" field so the field
// mapping demo works without hardcoding a Jira field id anywhere.
export const SAMPLE_JIRA_DISCOVERED_FIELDS: JiraDiscoveredField[] = [
  {
    id: "JIRA-FIELD-summary",
    fieldId: "summary",
    name: "Summary",
    fieldType: "string",
    custom: false,
    discoveredAt: SAMPLE_DISCOVERED_AT,
  },
  {
    id: "JIRA-FIELD-status",
    fieldId: "status",
    name: "Status",
    fieldType: "status",
    custom: false,
    discoveredAt: SAMPLE_DISCOVERED_AT,
  },
  {
    id: "JIRA-FIELD-priority",
    fieldId: "priority",
    name: "Priority",
    fieldType: "priority",
    custom: false,
    discoveredAt: SAMPLE_DISCOVERED_AT,
  },
  {
    id: "JIRA-FIELD-assignee",
    fieldId: "assignee",
    name: "Assignee",
    fieldType: "user",
    custom: false,
    discoveredAt: SAMPLE_DISCOVERED_AT,
  },
  {
    id: "JIRA-FIELD-duedate",
    fieldId: "duedate",
    name: "Due Date",
    fieldType: "date",
    custom: false,
    discoveredAt: SAMPLE_DISCOVERED_AT,
  },
  {
    id: "JIRA-FIELD-customfield_10016",
    fieldId: "customfield_10016",
    name: "Story Points",
    fieldType: "number",
    custom: true,
    discoveredAt: SAMPLE_DISCOVERED_AT,
  },
];

// Default status mapping seeded into mock mode so the demo has something to show.
export const SAMPLE_JIRA_STATUS_MAPPINGS: JiraStatusMapping[] = [
  { id: "JIRA-STATUS-to-do", jiraStatus: "To Do", matrixStatus: "Not Started" },
  { id: "JIRA-STATUS-in-progress", jiraStatus: "In Progress", matrixStatus: "In Progress" },
  { id: "JIRA-STATUS-done", jiraStatus: "Done", matrixStatus: "Complete" },
];

// The Matrix concepts a Jira field can be mapped to (drives the field-mapping UI).
export const MATRIX_FIELD_CONCEPTS: { concept: string; label: string }[] = [
  { concept: "storyPoints", label: "Story Points" },
  { concept: "dueDate", label: "Due Date" },
  { concept: "priority", label: "Priority" },
  { concept: "assignee", label: "Assignee" },
];

// The Matrix statuses a Jira status can map onto (drives the status-mapping UI).
export const MATRIX_STATUS_OPTIONS: string[] = [
  "Not Started",
  "In Progress",
  "Blocked",
  "Complete",
  "Cancelled",
];
