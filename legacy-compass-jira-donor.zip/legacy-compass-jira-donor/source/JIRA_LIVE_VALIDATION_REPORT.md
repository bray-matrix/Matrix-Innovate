# Jira Live Validation Report

**Date:** June 24, 2026
**Tenant:** `dataprose.atlassian.net` (real Jira Cloud)
**Authenticated as:** Brian Ray
**Scope:** End-to-end validation of the read-only Jira integration (Connector → API Server → Repository → PostgreSQL → UI) against a live tenant.
**Hard rule honored:** No Jira credentials were ever exposed to the browser or written to logs. Config reads return only `hasApiToken` + a masked hint.

---

## 1. Result Summary

| Stage | Result |
| --- | --- |
| Connection / auth | ✅ Pass — authenticated as Brian Ray (`myself` + `serverInfo`) |
| Project discovery | ✅ Pass — 19 projects discovered |
| Field discovery | ✅ Pass — 271 fields discovered (227 custom) |
| Field mapping persistence | ✅ Pass — 4 mappings saved and re-read from PostgreSQL |
| Project selection + mapping | ✅ Pass — 3 projects selected, mapped to Matrix programs |
| Sync (clean) | ✅ Pass — 3 projects / 98 issues / 101 records |
| Sync (idempotent re-run) | ✅ Pass — created=0, updated=101 |
| PostgreSQL persistence | ✅ Pass — counts match exactly (3 / 98) |
| Admin diagnostics UI | ✅ Pass — Connected, live counts render from PostgreSQL |
| Credential safety | ✅ Pass — token never returned to browser or logged |

**Overall: PASS.** Three critical, live-only bugs were found and fixed (Section 5). Architect review = PASS, full `pnpm run typecheck` passes.

---

## 2. PostgreSQL Row Counts (post-validation)

| Table | Rows |
| --- | --- |
| `jira_projects` | 3 |
| `jira_issues` | 98 |
| `jira_sync_runs` | 2 |

**Issues by project:** DEVWEB 38 · THROT 37 · OPS 23
**Issues by type:** Task 42 · Story 38 · Sub-task 14 · Bug 4
**Field coverage across imported issues:** priority 98 · assignee 86 · dueDate 22 · storyPoints 5

---

## 3. Discovery Report

### Projects discovered (19 total)
The tenant exposed 19 Jira projects. Three were selected for import and mapped onto Matrix programs:

| Jira key | Matrix mapping |
| --- | --- |
| THROT | PRG-24-004 |
| OPS | PRG-24-002 |
| DEVWEB | (selected, portfolio-level — no program mapping) |

The remaining 16 projects were discovered but intentionally left unselected, demonstrating the presence-based selection scope (a saved selection is authoritative; unselected projects import zero rows).

### Fields discovered (271 total, 227 custom)
Field discovery returned the full tenant field catalog including 227 custom fields. Four Matrix concepts were mapped to live Jira fields (no field IDs are hardcoded — story points resolve through this mapping at normalize time):

| Matrix concept | Jira field |
| --- | --- |
| Story Points | `customfield_10136` (custom) |
| Due Date | `duedate` |
| Priority | `priority` |
| Assignee | `assignee` |

### Sync configuration used
- Max issues: 100
- Issue types: Story, Task, Bug, Epic, Sub-task
- Bounded JQL: `project in ("THROT","OPS","DEVWEB")`

### Mapping gaps / observations
- **Story Points coverage is low (5 of 98 issues).** Only 5 imported issues carry a story-points value; the field is mapped correctly but is sparsely populated in the source tenant. Expected for a tenant that doesn't estimate every issue.
- **Due dates are sparse (22 of 98).** Again a source-data characteristic, not a mapping defect.
- **No status mappings were exercised in this run.** Jira statuses passed through to the normalized status field; configure status mappings if Matrix needs canonical status buckets.
- **Epics:** the issue-type filter includes Epic, but the selected projects returned none within the 100-issue cap per project.

---

## 4. Production Recommendations

1. **Move Claude/Jira secrets server-side for production.** Jira credentials are already server-only (good). Keep it that way — never surface the token to the browser.
2. **Add status mappings before going live** if downstream Matrix screens depend on canonical status buckets; the seam exists (`jira_status_mappings`) but was not needed for this validation.
3. **Raise or paginate `maxIssues` deliberately.** This run capped at 100/project. For full-portfolio sync, raise the cap and rely on the `nextPageToken`/`isLast` pagination already implemented.
4. **Schedule sync** rather than manual runs once cutover begins; the sync is idempotent (full upsert keyed on unique Jira ID), so re-runs are safe.
5. **Consider delta/incremental sync** for large tenants (currently full upsert each run, no pruning of de-selected rows — both deliberate out-of-scope items).
6. **Environment state:** validation left `VITE_DATA_SOURCE=postgres` and `JIRA_ENABLED=true` so the live integration remains active. Revert `VITE_DATA_SOURCE` to `mock` if you want screens to read the in-memory prototype data again.

---

## 5. Critical Fixes Applied During Validation

These were live-only failures invisible to the sample-data path:

1. **Base URL normalization** (`services/jira/config.ts`): the configured base URL was a bare host (`dataprose.atlassian.net`) with no scheme, so `fetch` built a broken URL and the connection failed confusingly. Added `normalizeBaseUrl()` to prepend `https://` when no scheme is present — applied to env config, env base URL, and DB config.

2. **Deprecated search endpoint** (`services/jira/connector.ts`): Jira Cloud removed `/rest/api/3/search` (returned **410 Gone**). Migrated `fetchLiveIssues` to the enhanced `/rest/api/3/search/jql` endpoint with opaque `nextPageToken`/`isLast` pagination and an explicit `fields` list (including the dynamically-mapped story-points id, since the new endpoint returns only ids without explicit fields).

3. **Bounded JQL** (`connector.ts` + `sync.ts`): the new endpoint rejects unbounded JQL. Added `project in (...)` when a selection exists, a `created >= "1970-01-01"` floor for the legacy no-selection "import all" case, and a zero-result short-circuit when a selection is saved but empty. `projectKeys` is threaded from sync through `ConnectorOptions`.

Additionally, `jiraGet` now includes a truncated Jira error body in thrown errors for **server-side logs only** — browser responses remain generic and credential-free.

---

## 6. Screenshots

Captured from the live admin UI (reading from PostgreSQL via `VITE_DATA_SOURCE=postgres`):

1. `screenshots/jira-1-connection.jpg` — Connection (Source: PostgreSQL, token masked, last test passed)
2. `screenshots/jira-2-projects.jpg` — Project Selection (discovered projects + Matrix program mapping)
3. `screenshots/jira-3-fields.jpg` — Field Mapping (Story Points → `customfield_10136`)
4. `screenshots/jira-4-history.jpg` — Sync History (completed runs, processed/created/updated)
5. `screenshots/jira-5-diagnostics.jpg` — Status & Diagnostics (Connected · 3 projects · 98 issues · 2 runs · 101 records)
