# CM (Change Management) — Large Project Import Readiness Report

**Task:** T022.8 — validate whether Matrix can safely import and analyze the live Jira
project key **`CM` (Change Management)** using the existing Jira connector → API →
PostgreSQL → Repository → Jira Executive Intelligence stack, **without** touching Matrix
mock portfolio data, existing Matrix projects/programs/resources/risks/approvals, or any
deterministic calculations.

**Date:** 2026-06-24 · **Tenant:** `dataprose.atlassian.net` (authenticated as Brian Ray)
· **Data source mode at validation:** `postgres`

---

## 1. Verdict

**CM can be imported and analyzed safely — but only a recency-biased 5,000-issue slice
today.** A *full* import is blocked by a hard pagination ceiling in the connector. The
import is non-destructive (Jira data lives in dedicated `jira_*` tables, entirely separate
from the Matrix domain), additive, and idempotent. Executive Intelligence computes
correctly and at speed over the CM dataset.

| Question | Answer |
|---|---|
| Does CM exist? | **Yes** — id `10020`, type `software`, name "Change Management". |
| Approximate size? | **~30,000 issues created lifetime** (keys `CM-221` … `CM-29853`, created Oct 2023 → Jun 2026). Current live count is **> 5,000** (ceiling hit). |
| Safe to import? | **Yes** — isolated tables, additive, idempotent. No Matrix domain data touched. |
| Full import possible now? | **No** — connector caps at 5,000 issues/run (see §5). |
| Exec metrics compute over CM? | **Yes** — health, alerts, aging, status/priority, per-project metrics all populate. |
| Mock + Postgres parity preserved? | **Yes** — both modes run the same `@workspace/jira-intelligence` pure-compute lib. |

---

## 2. Import result summary

A controlled, CM-only import was run via the existing pipeline (project selection scoped to
`CM`; the other 3 projects set unselected for isolation; `maxIssuesPerRun` raised to 5000;
issue-type allow-list cleared to capture all types).

| Metric | Value |
|---|---|
| Issues imported | **5,000** (capped — see §5) |
| Projects imported | 1 (CM) |
| `recordsProcessed` | 5,001 (5,000 issues + 1 project) |
| `recordsCreated` / `recordsUpdated` | 5,001 / 0 (first CM import) |
| Sync duration | **44.1 s** end-to-end (~113 issues/sec) |
| Slice captured | the **5,000 most-recently-updated** issues (`order by updated DESC`) |

The 5,000 imported issues were updated between **2026-02-13** and **2026-06-23** — i.e. the
most recently active subset, not a representative cross-section of the full ~30k history.

---

## 3. PostgreSQL row counts (after import)

| Jira project | Rows | Notes |
|---|---|---|
| **CM** | **5,000** | newly imported (capped) |
| DEVWEB | 38 | pre-existing, **untouched** |
| THROT | 37 | pre-existing, **untouched** |
| OPS | 23 | pre-existing, **untouched** |
| **Total `jira_issues`** | **5,098** | additive — no pruning, no replacement |

No Matrix domain tables (organizations, clients, programs, projects, milestones, risks,
approvals, activity) were read or written at any point.

---

## 4. CM data profile (of the 5,000 imported)

### Issue types
| Type | Count |
|---|---|
| Task | 4,872 |
| Sub-task | 88 |
| Epic | 40 |

(All three are within the default allow-list; no Story/Bug present in the slice.)

### Status (raw Jira; "Complete"/"Not Started" are the two currently mapped)
| Status | Count | Intelligence bucket |
|---|---|---|
| Complete | 3,749 | done |
| Not Started | 798 | todo |
| Information Needed | 142 | todo *(arguably blocked/waiting)* |
| In Progress | 85 | inProgress |
| In Production | 76 | **todo** *(likely should be done)* |
| Approvals | 43 | todo |
| Open | 27 | todo |
| Estimate | 26 | todo |
| Production Rollout | 18 | **todo** *(likely should be done)* |
| Estimate Approval | 14 | todo |
| Closed | 12 | done |
| In Code Review | 10 | inProgress |

### Priority
| Priority | Count | Intelligence bucket |
|---|---|---|
| Medium | 3,243 | medium |
| High | 768 | high |
| **PRODDOWN** | **597** | **medium** *(custom — should be critical)* |
| Highest | 376 | highest (critical) |
| Low | 10 | low |
| Lowest | 6 | low |

### Field availability (of 5,000)
| Field | Populated | % |
|---|---|---|
| description | 4,939 | 99% |
| assignee | 4,163 | 83% (63 distinct assignees) |
| due date | 2,263 | 45% |
| story points | 1,079 | 22% |
| **resolution date** | **12** | **0.2%** |

**Key insight:** the intelligence engine treats `resolutiondate` as the *strongest* done
signal **when present**, then falls back to status keywords. CM populates `resolutiondate`
on only 0.2% of issues, so in practice **status** is the operative completion signal for CM.
This works correctly — but any logic that *relies* on resolution date would be wrong for CM.

---

## 5. Performance, pagination & rate-limit concerns

These are the readiness blockers/risks for a full ~30k import. The current behavior is
correct and safe at ≤5,000; the items below are what a full import requires.

1. **Hard 5,000-issue ceiling (blocker for full import).** The connector pages with
   `maxResults=100` inside a `for (page < 50)` loop → a hard cap of 5,000 issues per run,
   regardless of `maxIssuesPerRun`. CM (>5,000) is truncated to its 5,000 most-recently-
   updated issues. **A full CM import requires raising/removing this page cap.**
2. **No rate-limit (HTTP 429) handling.** A full ~30k pull is ~300 sequential Jira calls.
   Jira Cloud rate limits are cost-based; there is currently no `Retry-After` honoring or
   backoff, so a throttled large pull would fail outright. **Add 429 retry/backoff before
   attempting a full import.**
3. **Single bulk upsert, per-row (2 queries/row).** Each issue does a `SELECT` (exists?)
   then an `INSERT … ON CONFLICT`. 5,000 issues = ~10,000 sequential statements (~44 s).
   Extrapolated to ~30k that is ~4–5 min of DB work alone. **Batch the upsert** (chunked
   multi-row `ON CONFLICT`) for an order-of-magnitude speedup at scale.
4. **No partial-progress persistence.** The upsert happens only after the full fetch
   completes, and the failure path records `recordsProcessed: 0`. A failure mid-pull on a
   30k import discards everything. **Persist in batches** so a large run is resumable/partial.
5. **No per-request timeout or progress logging.** Long pulls run blind with no timeout
   guard. Add a per-request `AbortController` timeout and per-page progress logging.

**Storage:** 5,000 rows imported with no concern; ~30k rows is still trivial for
PostgreSQL. Storage is **not** a constraint — fetch throughput and rate limits are.

---

## 6. Executive Intelligence over CM (confirmed working)

Computed live via `@workspace/jira-intelligence` (identical math in mock and postgres).

**Portfolio (4 projects, 5,098 issues):** healthScore **52/100**, open **1,312**,
completed **3,786**, blocked **2**, overdue **335**, critical **380**, avg issue age **82d**,
last-sync duration **44,110 ms**. Auto-derived executive alert fired: *"CM needs attention —
Project CM contains 376 critical-priority issues."*

**CM per-project metrics:** issues 5,000 · open 1,239 · completed 3,761 · blocked 0 ·
critical 376 · overdue 326 · high-priority-open 236 · open story points 463 · todo 1,144 ·
in-progress 95 · done 3,761 · healthClass `healthy` · healthScore `30`.

> Note the `healthClass: "healthy"` vs `healthScore: 30` divergence: health **class** is
> driven by staleness/recent activity (CM is very active, `staleDays: 0`), while the
> **score** reflects the overdue/critical load. Worth aligning if class is surfaced to execs.

The classification buckets reconcile exactly with the raw distribution (e.g. open 1,239 =
todo 1,144 + inProgress 95; completed 3,761 = Complete 3,749 + Closed 12), confirming the
engine handles CM's custom workflow without error.

---

## 7. Matrix mapping recommendation

CM is a **long-running (2.5-year), high-volume (~30k) change-management work queue** with a
deep custom workflow (12+ statuses) and a flat Task-dominated shape (97% Tasks, 40 Epics).
It is **not** a single Matrix project.

**Recommended model — Portfolio category + Epic-level program rollup (hybrid):**

| Option | Fit | Rationale |
|---|---|---|
| Single Matrix project | ✗ | 30k issues / 12+ statuses / 40 Epics is far too coarse for one project. |
| Many Matrix projects (Task-level) | ✗ | Mapping thousands of Tasks into the domain model is unmanageable and pollutes Matrix data. |
| Matrix **program** (Epics → projects) | ◑ | Reasonable drilldown: model CM as a program, its **40 Epics** as the program's projects, Tasks/Sub-tasks as work items rolling up to Epics. |
| Matrix **portfolio category** | ✓ | Best for executive reporting — CM rolls up as its own category in the Jira Portfolio Summary without forcing it into the domain project model. |

**Recommendation:** treat **CM as its own portfolio category ("Change Management")** for
executive rollup and reporting (already set on the CM project mapping). If operational
drilldown is needed, additionally map CM's **40 Epics** to a CM program's projects — never
map the 5,000+ Tasks into Matrix domain entities. This keeps exec reporting clean while
preserving an optional drill path, and keeps the Matrix domain model uncontaminated.

### Rollup & executive reporting strategy
- CM feeds the **Jira Portfolio Summary** (health, alerts, aging, status/priority, per-
  project metrics) — already working.
- Program rollups (`buildProgramMapping`) can attribute CM (or its Epics) to a program for
  the portfolio/program pages; portfolio category drives the executive grouping.

### Which Jira fields should drive Matrix health
- **Status → completion / open / in-progress** (operative signal for CM; the engine prefers
  `resolutiondate` when present, but it is only 0.2% populated here so status governs).
- **Priority → critical/risk signal** (drives `criticalCount` and executive alerts).
- **Due date → overdue** (45% populated — usable but partial).
- **Story points → open workload** (22% populated — treat as a partial signal only).
- **Assignee → ownership** (83% populated).

### Required status mappings (add via Administration → Jira → Field/Status mapping)
| Jira status | Map to Matrix status | Why |
|---|---|---|
| In Production | Complete | Deployed work currently counts as open (todo). |
| Production Rollout | Complete (or In Progress) | Currently counts as open. |
| Information Needed | On Hold / Waiting | Surface as blocked/waiting rather than todo (142 issues). |
| In Code Review | In Progress | (Already classifies as inProgress via "review" — confirm.) |

### Required priority handling — **the single most important fix**
**"PRODDOWN" (597 issues, production-down) is classified as *Medium*, not critical.** This
materially understates urgent work in every executive view. There is **no priority-value
mapping table today** (only a status mapping exists), so this cannot be fixed via config —
it needs either:
- adding `proddown` to the "highest" keyword set in `lib/jira-intelligence/src/classify.ts`,
  **or**
- introducing a priority-mapping table (parallel to status mappings) so custom priorities
  can be remapped without code.

---

## 8. Safety & scope confirmation

- ✅ Matrix mock portfolio data unchanged (no domain tables read/written).
- ✅ Existing Matrix projects/programs/resources/risks/approvals/calculations untouched.
- ✅ Existing 3 synced Jira projects (DEVWEB/OPS/THROT) untouched (additive, no pruning).
- ✅ Only CM imported (project selection scoped to CM for the validation run).
- ✅ Idempotent (upsert by Jira id) — re-syncs update in place, no duplication.
- ✅ Mock + Postgres parity preserved (shared pure-compute lib).
- ✅ No application code changed during validation — existing Jira functionality intact.

### End state left in place
- CM imported (5,000-issue slice) and **selected**, mapped to portfolio category
  "Change Management".
- Original 3 projects restored to selected with their program associations.
- `sync-settings`: `maxIssuesPerRun=5000` (kept at the validated working value),
  issue-type allow-list restored, manual/full, auto-sync off.

---

## 9. Recommended next steps (for a production-grade full CM import)

1. Raise/remove the connector's 50-page ceiling (drive purely by `maxIssuesPerRun` + `isLast`).
2. Add HTTP 429 `Retry-After` handling + bounded backoff.
3. Batch the upsert (chunked multi-row `ON CONFLICT`) and persist partial progress per batch.
4. Add a per-request timeout + per-page progress logging.
5. Add a priority-value mapping (or extend the classifier) so **PRODDOWN → critical**.
6. Add status mappings for CM's deployment/waiting statuses (§7).
7. (Optional) approximate-count endpoint to size a project before import.
