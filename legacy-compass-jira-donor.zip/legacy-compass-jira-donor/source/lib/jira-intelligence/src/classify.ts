// Heuristic classification of free-form Jira status/priority strings into canonical
// buckets. Jira tenants name statuses/priorities arbitrarily, so we classify by
// keyword. Issues whose status was remapped via Matrix status mappings still
// classify correctly because the canonical Matrix names use the same keywords.
import type { IntelIssue } from "./types.js";

export type StatusBucket = "todo" | "inProgress" | "blocked" | "done";
export type PriorityBucket = "highest" | "high" | "medium" | "low";

export function statusBucket(issue: Pick<IntelIssue, "status" | "resolutionDate">): StatusBucket {
  const s = (issue.status ?? "").toLowerCase().trim();
  // A resolution date is the strongest signal an issue is finished.
  if (issue.resolutionDate) return "done";
  if (!s) return "todo";
  if (/block|impediment|on hold|on-hold|waiting|stuck/.test(s)) return "blocked";
  if (/done|closed|resolved|complete|completed|shipped|live|deployed|cancel/.test(s)) {
    return "done";
  }
  if (/progress|review|doing|developing|development|qa|testing|in test|verify/.test(s)) {
    return "inProgress";
  }
  return "todo";
}

export function isDone(issue: Pick<IntelIssue, "status" | "resolutionDate">): boolean {
  return statusBucket(issue) === "done";
}

export function isBlocked(issue: Pick<IntelIssue, "status" | "resolutionDate">): boolean {
  return statusBucket(issue) === "blocked";
}

export function priorityBucket(priority: string | null): PriorityBucket {
  const p = (priority ?? "").toLowerCase().trim();
  if (!p) return "medium";
  if (/highest|critical|blocker|p0|urgent/.test(p)) return "highest";
  if (/high|major|p1/.test(p)) return "high";
  if (/low|minor|trivial|p3|p4|lowest/.test(p)) return "low";
  return "medium"; // medium / normal / p2 / unknown
}

// "Critical" for executive purposes = the most severe priority band.
export function isCriticalPriority(priority: string | null): boolean {
  return priorityBucket(priority) === "highest";
}

export function isHighPriority(priority: string | null): boolean {
  const b = priorityBucket(priority);
  return b === "highest" || b === "high";
}

// Whole days between two instants (a before b => positive). Returns 0 for invalid.
export function daysBetween(from: string | null | undefined, to: Date): number {
  if (!from) return 0;
  const t = Date.parse(from);
  if (Number.isNaN(t)) return 0;
  return Math.floor((to.getTime() - t) / 86_400_000);
}
