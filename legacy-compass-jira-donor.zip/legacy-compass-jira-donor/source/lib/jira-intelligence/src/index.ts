// @workspace/jira-intelligence — pure executive-intelligence compute over Jira
// data. Shared by the api-server (snapshots / diagnostics / project metrics) and
// the matrix-platform frontend (live executive metrics + program/portfolio
// rollups) so both produce identical numbers.
export * from "./types.js";
export * from "./classify.js";
export * from "./metrics.js";
