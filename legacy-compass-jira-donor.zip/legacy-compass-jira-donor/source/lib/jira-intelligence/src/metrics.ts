// The executive intelligence compute engine. All functions are pure and
// deterministic given an explicit `now`. Inputs are plain IntelIssue/IntelProject
// arrays; outputs are the metric shapes in types.ts.
import {
  daysBetween,
  isBlocked,
  isCriticalPriority,
  isDone,
  isHighPriority,
  priorityBucket,
  statusBucket,
} from "./classify.js";
import {
  DEFAULT_THRESHOLDS,
  type AgingCounts,
  type ExecutiveAlert,
  type ExecutiveMetrics,
  type ExecutiveSummary,
  type HealthClass,
  type IntelIssue,
  type IntelOptions,
  type IntelProject,
  type IntelSnapshot,
  type IntelThresholds,
  type PortfolioHealth,
  type PortfolioRollup,
  type PriorityCounts,
  type ProgramMappingEntry,
  type ProgramRollup,
  type ProjectMetric,
  type RiskIndicators,
  type StatusCounts,
} from "./types.js";

function resolveOptions(opts?: IntelOptions): { thresholds: IntelThresholds; now: Date } {
  return {
    thresholds: { ...DEFAULT_THRESHOLDS, ...(opts?.thresholds ?? {}) },
    now: opts?.now ?? new Date(),
  };
}

function emptyStatus(): StatusCounts {
  return { todo: 0, inProgress: 0, blocked: 0, done: 0 };
}
function emptyPriority(): PriorityCounts {
  return { highest: 0, high: 0, medium: 0, low: 0 };
}
function emptyAging(): AgingCounts {
  return { d0_7: 0, d8_30: 0, d31_60: 0, d61_90: 0, d90plus: 0 };
}

function isOverdue(issue: IntelIssue, now: Date): boolean {
  if (isDone(issue)) return false;
  if (!issue.dueDate) return false;
  const due = Date.parse(issue.dueDate);
  return !Number.isNaN(due) && due < now.getTime();
}

function addAging(buckets: AgingCounts, ageDays: number): void {
  if (ageDays <= 7) buckets.d0_7 += 1;
  else if (ageDays <= 30) buckets.d8_30 += 1;
  else if (ageDays <= 60) buckets.d31_60 += 1;
  else if (ageDays <= 90) buckets.d61_90 += 1;
  else buckets.d90plus += 1;
}

// Portfolio-health classification from a project's blocked-issue count.
export function classifyHealth(blockedCount: number, t: IntelThresholds): HealthClass {
  if (blockedCount <= t.healthyMaxBlockers) return "healthy";
  if (blockedCount <= t.watchMaxBlockers) return "watch";
  if (blockedCount <= t.atRiskMaxBlockers) return "atRisk";
  return "critical";
}

// 0-100 deterministic health score (display metric, distinct from the blocker-band
// classification). Penalties are capped so one noisy project can't dominate.
function healthScore(args: {
  blockedCount: number;
  overdueCount: number;
  highPriorityOpenCount: number;
  agingOpenCount: number;
}): number {
  let score = 100;
  score -= Math.min(args.blockedCount * 8, 40);
  score -= Math.min(args.overdueCount * 5, 30);
  score -= Math.min(args.highPriorityOpenCount * 3, 20);
  score -= Math.min(args.agingOpenCount * 2, 20);
  return Math.max(0, Math.min(100, Math.round(score)));
}

const HEALTH_RANK: Record<HealthClass, number> = {
  healthy: 0,
  watch: 1,
  atRisk: 2,
  critical: 3,
};

function worstHealth(classes: HealthClass[]): HealthClass {
  let worst: HealthClass = "healthy";
  for (const c of classes) if (HEALTH_RANK[c] > HEALTH_RANK[worst]) worst = c;
  return worst;
}

// Per-project metrics — the backbone reused by executive metrics, the portfolio
// summary, snapshots, and rollups.
export function computeProjectMetrics(
  projects: IntelProject[],
  issues: IntelIssue[],
  opts?: IntelOptions,
): ProjectMetric[] {
  const { thresholds, now } = resolveOptions(opts);
  const byKey = new Map<string, IntelIssue[]>();
  for (const i of issues) {
    const arr = byKey.get(i.projectKey);
    if (arr) arr.push(i);
    else byKey.set(i.projectKey, [i]);
  }

  // Include every known project plus any project key seen only on issues.
  const keys = new Map<string, string>();
  for (const p of projects) keys.set(p.key, p.name);
  for (const k of byKey.keys()) if (!keys.has(k)) keys.set(k, k);

  const result: ProjectMetric[] = [];
  for (const [key, name] of keys) {
    const list = byKey.get(key) ?? [];
    const status = emptyStatus();
    const priority = emptyPriority();
    const aging = emptyAging();
    let openCount = 0;
    let completedCount = 0;
    let blockedCount = 0;
    let criticalCount = 0;
    let overdueCount = 0;
    let highPriorityOpenCount = 0;
    let agingOpenCount = 0;
    let openStoryPoints = 0;
    let lastActivity: string | null = null;

    for (const i of list) {
      status[statusBucket(i)] += 1;
      priority[priorityBucket(i.priority)] += 1;
      const done = isDone(i);
      if (done) completedCount += 1;
      else openCount += 1;
      if (isBlocked(i)) blockedCount += 1;
      if (isCriticalPriority(i.priority)) criticalCount += 1;
      if (isOverdue(i, now)) overdueCount += 1;
      if (!done && isHighPriority(i.priority)) highPriorityOpenCount += 1;
      if (!done) {
        const age = daysBetween(i.createdDate, now);
        addAging(aging, age);
        if (age > thresholds.agingIssueDays) agingOpenCount += 1;
        if (typeof i.storyPoints === "number") openStoryPoints += i.storyPoints;
      }
      if (i.updatedDate) {
        if (!lastActivity || Date.parse(i.updatedDate) > Date.parse(lastActivity)) {
          lastActivity = i.updatedDate;
        }
      }
    }

    const staleDays = lastActivity ? daysBetween(lastActivity, now) : null;
    const isStale =
      list.length > 0 && staleDays !== null && staleDays > thresholds.staleProjectDays;

    result.push({
      key,
      name,
      issueCount: list.length,
      openCount,
      completedCount,
      blockedCount,
      criticalCount,
      overdueCount,
      highPriorityOpenCount,
      openStoryPoints,
      status,
      priority,
      aging,
      healthClass: classifyHealth(blockedCount, thresholds),
      healthScore: healthScore({
        blockedCount,
        overdueCount,
        highPriorityOpenCount,
        agingOpenCount,
      }),
      lastActivity,
      staleDays,
      isStale,
    });
  }

  result.sort((a, b) => HEALTH_RANK[b.healthClass] - HEALTH_RANK[a.healthClass] || b.issueCount - a.issueCount);
  return result;
}

function sumStatus(metrics: ProjectMetric[]): StatusCounts {
  const acc = emptyStatus();
  for (const m of metrics) {
    acc.todo += m.status.todo;
    acc.inProgress += m.status.inProgress;
    acc.blocked += m.status.blocked;
    acc.done += m.status.done;
  }
  return acc;
}

function sumPriority(metrics: ProjectMetric[]): PriorityCounts {
  const acc = emptyPriority();
  for (const m of metrics) {
    acc.highest += m.priority.highest;
    acc.high += m.priority.high;
    acc.medium += m.priority.medium;
    acc.low += m.priority.low;
  }
  return acc;
}

function sumAging(metrics: ProjectMetric[]): AgingCounts {
  const acc = emptyAging();
  for (const m of metrics) {
    acc.d0_7 += m.aging.d0_7;
    acc.d8_30 += m.aging.d8_30;
    acc.d31_60 += m.aging.d31_60;
    acc.d61_90 += m.aging.d61_90;
    acc.d90plus += m.aging.d90plus;
  }
  return acc;
}

function averageScore(metrics: ProjectMetric[]): number {
  if (metrics.length === 0) return 100;
  const total = metrics.reduce((s, m) => s + m.healthScore, 0);
  return Math.round(total / metrics.length);
}

function buildAlerts(metrics: ProjectMetric[], t: IntelThresholds): ExecutiveAlert[] {
  const alerts: ExecutiveAlert[] = [];
  for (const m of metrics) {
    if (m.criticalCount > 0 || m.healthClass === "critical") {
      const n = Math.max(m.criticalCount, m.blockedCount);
      alerts.push({
        id: `alert-critical-${m.key}`,
        severity: "critical",
        projectKey: m.key,
        title: `${m.key} needs attention`,
        message:
          m.criticalCount > 0
            ? `Project ${m.key} contains ${m.criticalCount} critical-priority issue${m.criticalCount === 1 ? "" : "s"}.`
            : `Project ${m.key} has ${n} blocked issue${n === 1 ? "" : "s"} (critical health).`,
      });
    }
    if (m.highPriorityOpenCount >= 5) {
      alerts.push({
        id: `alert-highpri-${m.key}`,
        severity: "warning",
        projectKey: m.key,
        title: `${m.key} high-priority backlog`,
        message: `Project ${m.key} contains ${m.highPriorityOpenCount} high-priority open issues.`,
      });
    }
    if (m.overdueCount > 0) {
      alerts.push({
        id: `alert-overdue-${m.key}`,
        severity: m.overdueCount >= 5 ? "warning" : "info",
        projectKey: m.key,
        title: `${m.key} overdue work`,
        message: `Project ${m.key} has ${m.overdueCount} overdue issue${m.overdueCount === 1 ? "" : "s"}.`,
      });
    }
    if (m.isStale && m.staleDays !== null) {
      alerts.push({
        id: `alert-stale-${m.key}`,
        severity: "info",
        projectKey: m.key,
        title: `${m.key} is stale`,
        message: `Project ${m.key} has not been updated in ${m.staleDays} days.`,
      });
    }
  }
  const order = { critical: 0, warning: 1, info: 2 } as const;
  alerts.sort((a, b) => order[a.severity] - order[b.severity]);
  return alerts;
}

export function computeExecutiveMetrics(
  projects: IntelProject[],
  issues: IntelIssue[],
  opts?: IntelOptions,
): ExecutiveMetrics {
  const { thresholds, now } = resolveOptions(opts);
  const metrics = computeProjectMetrics(projects, issues, opts);

  const status = sumStatus(metrics);
  const priority = sumPriority(metrics);
  const aging = sumAging(metrics);

  let openIssues = 0;
  let completedIssues = 0;
  let blockedIssues = 0;
  let criticalIssues = 0;
  let overdueIssues = 0;
  let highPriorityOpen = 0;
  let agingIssues = 0;
  let ageSum = 0;
  let ageCount = 0;
  for (const m of metrics) {
    openIssues += m.openCount;
    completedIssues += m.completedCount;
    blockedIssues += m.blockedCount;
    criticalIssues += m.criticalCount;
    overdueIssues += m.overdueCount;
    highPriorityOpen += m.highPriorityOpenCount;
  }
  for (const i of issues) {
    if (!isDone(i)) {
      const age = daysBetween(i.createdDate, now);
      ageSum += age;
      ageCount += 1;
      if (age > thresholds.agingIssueDays) agingIssues += 1;
    }
  }

  const portfolioHealth: PortfolioHealth = { healthy: 0, watch: 0, atRisk: 0, critical: 0 };
  for (const m of metrics) portfolioHealth[m.healthClass] += 1;

  const staleProjects = metrics.filter((m) => m.isStale).length;

  const summary: ExecutiveSummary = {
    importedProjects: metrics.length,
    importedIssues: issues.length,
    openIssues,
    completedIssues,
    blockedIssues,
    criticalIssues,
    overdueIssues,
    averageIssueAgeDays: ageCount > 0 ? Math.round(ageSum / ageCount) : 0,
  };

  const risk: RiskIndicators = {
    blockedIssues,
    agingIssues,
    overdueIssues,
    highPriorityOpen,
    staleProjects,
  };

  return {
    summary,
    portfolioHealth,
    status,
    priority,
    aging,
    risk,
    alerts: buildAlerts(metrics, thresholds),
    projects: metrics,
    healthScore: averageScore(metrics),
  };
}

// Jira-only snapshot (no Matrix domain) — safe to compute server-side per sync.
export function buildSnapshot(
  projects: IntelProject[],
  issues: IntelIssue[],
  capturedAt: string,
  opts?: IntelOptions,
): IntelSnapshot {
  const m = computeExecutiveMetrics(projects, issues, opts);
  return {
    capturedAt,
    projectCount: m.summary.importedProjects,
    issueCount: m.summary.importedIssues,
    openCount: m.summary.openIssues,
    completedCount: m.summary.completedIssues,
    blockedCount: m.summary.blockedIssues,
    criticalCount: m.summary.criticalIssues,
    overdueCount: m.summary.overdueIssues,
    priority: m.priority,
    healthScore: m.healthScore,
  };
}

// --- Rollups (frontend: Jira project metrics + Matrix program mappings) ------

export function rollupByProgram(
  projectMetrics: ProjectMetric[],
  mappings: ProgramMappingEntry[],
): ProgramRollup[] {
  const byKey = new Map(projectMetrics.map((m) => [m.key, m]));
  const groups = new Map<string, { name: string; metrics: ProjectMetric[]; keys: string[] }>();
  for (const map of mappings) {
    const metric = byKey.get(map.projectKey);
    if (!metric) continue;
    const g = groups.get(map.programId);
    if (g) {
      g.metrics.push(metric);
      g.keys.push(map.projectKey);
    } else {
      groups.set(map.programId, {
        name: map.programName,
        metrics: [metric],
        keys: [map.projectKey],
      });
    }
  }

  const rollups: ProgramRollup[] = [];
  for (const [programId, g] of groups) {
    rollups.push({
      programId,
      programName: g.name,
      projectKeys: g.keys,
      issueCount: g.metrics.reduce((s, m) => s + m.issueCount, 0),
      openCount: g.metrics.reduce((s, m) => s + m.openCount, 0),
      blockedCount: g.metrics.reduce((s, m) => s + m.blockedCount, 0),
      highPriorityOpenCount: g.metrics.reduce((s, m) => s + m.highPriorityOpenCount, 0),
      overdueCount: g.metrics.reduce((s, m) => s + m.overdueCount, 0),
      openStoryPoints: g.metrics.reduce((s, m) => s + m.openStoryPoints, 0),
      healthClass: worstHealth(g.metrics.map((m) => m.healthClass)),
      healthScore: averageScore(g.metrics),
    });
  }
  rollups.sort((a, b) => HEALTH_RANK[b.healthClass] - HEALTH_RANK[a.healthClass] || b.openCount - a.openCount);
  return rollups;
}

export function rollupPortfolio(programs: ProgramRollup[]): PortfolioRollup {
  const projectKeys = new Set<string>();
  for (const p of programs) for (const k of p.projectKeys) projectKeys.add(k);
  return {
    programCount: programs.length,
    projectCount: projectKeys.size,
    totalOpen: programs.reduce((s, p) => s + p.openCount, 0),
    totalBlocked: programs.reduce((s, p) => s + p.blockedCount, 0),
    totalHighPriorityOpen: programs.reduce((s, p) => s + p.highPriorityOpenCount, 0),
    totalOverdue: programs.reduce((s, p) => s + p.overdueCount, 0),
    overallHealthClass: worstHealth(programs.map((p) => p.healthClass)),
    overallHealthScore:
      programs.length === 0
        ? 100
        : Math.round(programs.reduce((s, p) => s + p.healthScore, 0) / programs.length),
  };
}
