// Pure input/output types for Jira executive intelligence. The lib never imports
// Drizzle rows or API client types — both the api-server (for snapshots /
// diagnostics / project metrics) and the matrix-platform frontend (for live
// executive metrics and rollups) map their own data into these shapes so the
// numbers are identical by construction.

// --- Inputs ------------------------------------------------------------------

export interface IntelIssue {
  key: string;
  projectKey: string;
  issueType: string | null;
  status: string | null;
  priority: string | null;
  assigneeName: string | null;
  storyPoints: number | null;
  createdDate: string | null;
  updatedDate: string | null;
  dueDate: string | null;
  resolutionDate: string | null;
}

export interface IntelProject {
  key: string;
  name: string;
}

// Tunable classification thresholds. Defaults match the T022.7 spec; callers may
// override to support future per-tenant configuration.
export interface IntelThresholds {
  // Portfolio-health classification by blocked-issue count per project.
  // healthy: <= healthyMaxBlockers; watch: up to watchMaxBlockers;
  // atRisk: up to atRiskMaxBlockers; critical: above atRiskMaxBlockers.
  healthyMaxBlockers: number; // default 0
  watchMaxBlockers: number; // default 5
  atRiskMaxBlockers: number; // default 10
  // A project is "stale" when its most recent issue activity is older than this.
  staleProjectDays: number; // default 14
  // An open issue counts as "aging" (risk indicator) past this age.
  agingIssueDays: number; // default 30
}

export const DEFAULT_THRESHOLDS: IntelThresholds = {
  healthyMaxBlockers: 0,
  watchMaxBlockers: 5,
  atRiskMaxBlockers: 10,
  staleProjectDays: 14,
  agingIssueDays: 30,
};

export interface IntelOptions {
  thresholds?: Partial<IntelThresholds>;
  // Reference "now" so results are deterministic/testable. Defaults to Date.now().
  now?: Date;
}

// --- Outputs -----------------------------------------------------------------

export interface StatusCounts {
  todo: number;
  inProgress: number;
  blocked: number;
  done: number;
}

export interface PriorityCounts {
  highest: number;
  high: number;
  medium: number;
  low: number;
}

export interface AgingCounts {
  d0_7: number;
  d8_30: number;
  d31_60: number;
  d61_90: number;
  d90plus: number;
}

export type HealthClass = "healthy" | "watch" | "atRisk" | "critical";

export interface ExecutiveSummary {
  importedProjects: number;
  importedIssues: number;
  openIssues: number;
  completedIssues: number;
  blockedIssues: number;
  criticalIssues: number;
  overdueIssues: number;
  averageIssueAgeDays: number;
}

export interface RiskIndicators {
  blockedIssues: number;
  agingIssues: number;
  overdueIssues: number;
  highPriorityOpen: number;
  staleProjects: number;
}

export interface ExecutiveAlert {
  id: string;
  severity: "critical" | "warning" | "info";
  projectKey: string | null;
  title: string;
  message: string;
}

export interface PortfolioHealth {
  healthy: number;
  watch: number;
  atRisk: number;
  critical: number;
}

export interface ProjectMetric {
  key: string;
  name: string;
  issueCount: number;
  openCount: number;
  completedCount: number;
  blockedCount: number;
  criticalCount: number;
  overdueCount: number;
  highPriorityOpenCount: number;
  openStoryPoints: number;
  status: StatusCounts;
  priority: PriorityCounts;
  aging: AgingCounts;
  healthClass: HealthClass;
  healthScore: number;
  lastActivity: string | null;
  staleDays: number | null;
  isStale: boolean;
}

export interface ExecutiveMetrics {
  summary: ExecutiveSummary;
  portfolioHealth: PortfolioHealth;
  status: StatusCounts;
  priority: PriorityCounts;
  aging: AgingCounts;
  risk: RiskIndicators;
  alerts: ExecutiveAlert[];
  projects: ProjectMetric[];
  healthScore: number;
}

// A point-in-time snapshot persisted per sync (the trend framework). Jira-only
// aggregates — no Matrix domain data — so it can be computed server-side.
export interface IntelSnapshot {
  capturedAt: string;
  projectCount: number;
  issueCount: number;
  openCount: number;
  completedCount: number;
  blockedCount: number;
  criticalCount: number;
  overdueCount: number;
  priority: PriorityCounts;
  healthScore: number;
}

// --- Rollups (frontend-only context: Jira metrics + Matrix mappings) ---------

export interface ProgramMappingEntry {
  projectKey: string;
  programId: string;
  programName: string;
}

export interface ProgramRollup {
  programId: string;
  programName: string;
  projectKeys: string[];
  issueCount: number;
  openCount: number;
  blockedCount: number;
  highPriorityOpenCount: number;
  overdueCount: number;
  openStoryPoints: number;
  healthClass: HealthClass;
  healthScore: number;
}

export interface PortfolioRollup {
  programCount: number;
  projectCount: number;
  totalOpen: number;
  totalBlocked: number;
  totalHighPriorityOpen: number;
  totalOverdue: number;
  overallHealthClass: HealthClass;
  overallHealthScore: number;
}
