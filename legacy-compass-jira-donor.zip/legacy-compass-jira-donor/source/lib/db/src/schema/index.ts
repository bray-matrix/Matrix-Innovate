// Matrix Compass — persistent schema.
//
// Domain entities mirror `artifacts/matrix-platform/src/lib/data.ts` (text IDs
// like ORG-/CL-/PRG-/PROJ-/MS-…). AI/governance tables mirror the AI services.
// Each table also carries `created_at` / `updated_at` metadata columns.

export * from "./organizations";
export * from "./clients";
export * from "./programs";
export * from "./projects";
export * from "./resources";
export * from "./risks";
export * from "./approvals";
export * from "./documents";
export * from "./activities";
export * from "./dependencies";
export * from "./ai";
export * from "./jira";
