// Jira connector persistence (T022). Read-only ingestion target: the connector
// (api-server) pulls projects/issues from Jira Cloud and upserts normalized rows
// here. PostgreSQL is the system of record for imported Jira data; the UI reads
// it back through the API server, never from Jira directly.
//
// Tables are runtime-populated by sync (like the AI ledger), so the seed only
// clears them — there are no seeded Jira rows. Upserts conflict on the unique
// jira id columns, which keeps repeated syncs idempotent.
import {
  pgTable,
  text,
  integer,
  boolean,
  doublePrecision,
  jsonb,
  timestamp,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// A normalized Jira project. `id` is a stable surrogate derived from the Jira
// project id so re-syncs keep the same primary key; `jiraProjectId` carries the
// real Jira identifier and is the upsert conflict target.
export const jiraProjectsTable = pgTable(
  "jira_projects",
  {
    id: text("id").primaryKey(),
    jiraProjectId: text("jira_project_id").notNull(),
    jiraProjectKey: text("jira_project_key").notNull(),
    jiraProjectName: text("jira_project_name").notNull(),
    projectType: text("project_type"),
    leadName: text("lead_name"),
    leadAccountId: text("lead_account_id"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    // Upsert conflict target — one row per Jira project.
    jiraProjectIdIdx: uniqueIndex("jira_projects_jira_project_id_idx").on(t.jiraProjectId),
    // Key lookups (getProjectByKey) and issue→project joins.
    keyIdx: index("jira_projects_key_idx").on(t.jiraProjectKey),
  }),
);

// A normalized Jira issue. `jiraIssueId` is the upsert conflict target.
export const jiraIssuesTable = pgTable(
  "jira_issues",
  {
    id: text("id").primaryKey(),
    jiraIssueId: text("jira_issue_id").notNull(),
    jiraIssueKey: text("jira_issue_key").notNull(),
    jiraProjectKey: text("jira_project_key").notNull(),
    summary: text("summary").notNull(),
    description: text("description"),
    issueType: text("issue_type"),
    status: text("status"),
    priority: text("priority"),
    assigneeName: text("assignee_name"),
    assigneeAccountId: text("assignee_account_id"),
    reporterName: text("reporter_name"),
    storyPoints: doublePrecision("story_points"),
    createdDate: text("created_date"),
    updatedDate: text("updated_date"),
    dueDate: text("due_date"),
    resolutionDate: text("resolution_date"),
    metadataJson: jsonb("metadata_json").$type<Record<string, unknown>>(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    // Upsert conflict target — one row per Jira issue.
    jiraIssueIdIdx: uniqueIndex("jira_issues_jira_issue_id_idx").on(t.jiraIssueId),
    // Filtered list reads (listIssues by project / status) and key lookups.
    projectKeyIdx: index("jira_issues_project_key_idx").on(t.jiraProjectKey),
    statusIdx: index("jira_issues_status_idx").on(t.status),
    keyIdx: index("jira_issues_key_idx").on(t.jiraIssueKey),
  }),
);

// One row per sync attempt — the audit/history trail surfaced in Administration.
export const jiraSyncRunsTable = pgTable(
  "jira_sync_runs",
  {
    id: text("id").primaryKey(),
    syncStartedAt: text("sync_started_at").notNull(),
    syncCompletedAt: text("sync_completed_at"),
    status: text("status").notNull(),
    recordsProcessed: integer("records_processed").notNull().default(0),
    recordsCreated: integer("records_created").notNull().default(0),
    recordsUpdated: integer("records_updated").notNull().default(0),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    // Recency: getLastSync + sync history list order by newest first.
    createdAtIdx: index("jira_sync_runs_created_at_idx").on(t.createdAt),
  }),
);

export const insertJiraProjectSchema = createInsertSchema(jiraProjectsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraProject = z.infer<typeof insertJiraProjectSchema>;
export type JiraProjectRow = typeof jiraProjectsTable.$inferSelect;

export const insertJiraIssueSchema = createInsertSchema(jiraIssuesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraIssue = z.infer<typeof insertJiraIssueSchema>;
export type JiraIssueRow = typeof jiraIssuesTable.$inferSelect;

export const insertJiraSyncRunSchema = createInsertSchema(jiraSyncRunsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraSyncRun = z.infer<typeof insertJiraSyncRunSchema>;
export type JiraSyncRunRow = typeof jiraSyncRunsTable.$inferSelect;

// --- T022.5 configuration & mapping ------------------------------------------
//
// Connection config, discovery snapshots, mappings, and sync settings. All
// single-row tables use a fixed id ("default") so upserts stay idempotent. The
// api token is stored server-side only and is NEVER returned to the browser —
// the routes mask it (hasApiToken + a short hint) on read.

// Single-row connection configuration (id "default"). DB-backed config takes
// precedence over JIRA_* env; env stays as a fallback. lastTest* capture the
// most recent Test Connection outcome for diagnostics.
export const jiraConfigurationTable = pgTable("jira_configuration", {
  id: text("id").primaryKey(),
  baseUrl: text("base_url"),
  email: text("email"),
  apiToken: text("api_token"),
  enabled: boolean("enabled").notNull().default(false),
  serverTitle: text("server_title"),
  authenticatedUser: text("authenticated_user"),
  lastTestAt: text("last_test_at"),
  lastTestOk: boolean("last_test_ok"),
  lastTestMessage: text("last_test_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Single-row sync settings (id "default"). issueTypes is the allow-list of Jira
// issue types to import (empty = import all).
export const jiraSyncSettingsTable = pgTable("jira_sync_settings", {
  id: text("id").primaryKey(),
  autoSyncEnabled: boolean("auto_sync_enabled").notNull().default(false),
  syncFrequency: text("sync_frequency").notNull().default("manual"),
  maxIssuesPerRun: integer("max_issues_per_run").notNull().default(500),
  syncMode: text("sync_mode").notNull().default("full"),
  issueTypes: jsonb("issue_types").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Snapshot of projects discovered from Jira (Discover Projects). Upsert target
// is the unique jiraProjectId. Selection/mapping lives in jira_project_mappings.
export const jiraDiscoveredProjectsTable = pgTable(
  "jira_discovered_projects",
  {
    id: text("id").primaryKey(),
    jiraProjectId: text("jira_project_id").notNull(),
    jiraProjectKey: text("jira_project_key").notNull(),
    jiraProjectName: text("jira_project_name").notNull(),
    projectType: text("project_type"),
    leadName: text("lead_name"),
    status: text("status"),
    discoveredAt: text("discovered_at").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    jiraProjectIdIdx: uniqueIndex("jira_discovered_projects_jira_project_id_idx").on(t.jiraProjectId),
    keyIdx: index("jira_discovered_projects_key_idx").on(t.jiraProjectKey),
  }),
);

// Snapshot of fields discovered from Jira (Discover Fields). Upsert target is
// the unique fieldId.
export const jiraDiscoveredFieldsTable = pgTable(
  "jira_discovered_fields",
  {
    id: text("id").primaryKey(),
    fieldId: text("field_id").notNull(),
    name: text("name").notNull(),
    fieldType: text("field_type"),
    custom: boolean("custom").notNull().default(false),
    discoveredAt: text("discovered_at").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    fieldIdIdx: uniqueIndex("jira_discovered_fields_field_id_idx").on(t.fieldId),
  }),
);

// Per-project import selection + Matrix mapping. id == jiraProjectKey (one row
// per project), which is the upsert conflict target.
export const jiraProjectMappingsTable = pgTable(
  "jira_project_mappings",
  {
    id: text("id").primaryKey(),
    jiraProjectKey: text("jira_project_key").notNull(),
    selected: boolean("selected").notNull().default(false),
    matrixProgramId: text("matrix_program_id"),
    matrixPortfolioCategory: text("matrix_portfolio_category"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    keyIdx: uniqueIndex("jira_project_mappings_key_idx").on(t.jiraProjectKey),
  }),
);

// Maps a Matrix concept (e.g. "storyPoints") to a Jira field id. No Jira field
// id is hardcoded — story points etc. resolve through these rows. id ==
// matrixConcept (the upsert conflict target).
export const jiraFieldMappingsTable = pgTable(
  "jira_field_mappings",
  {
    id: text("id").primaryKey(),
    matrixConcept: text("matrix_concept").notNull(),
    jiraFieldId: text("jira_field_id"),
    jiraFieldName: text("jira_field_name"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    conceptIdx: uniqueIndex("jira_field_mappings_concept_idx").on(t.matrixConcept),
  }),
);

// Maps a Jira status name to a Matrix status. id == a slug of the Jira status
// (the upsert conflict target).
export const jiraStatusMappingsTable = pgTable(
  "jira_status_mappings",
  {
    id: text("id").primaryKey(),
    jiraStatus: text("jira_status").notNull(),
    matrixStatus: text("matrix_status").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    jiraStatusIdx: uniqueIndex("jira_status_mappings_jira_status_idx").on(t.jiraStatus),
  }),
);

// --- T022.7 executive intelligence persistence -------------------------------

// A point-in-time portfolio snapshot written once per sync run. Jira-only
// aggregates (no Matrix domain data) so they can be computed server-side via
// @workspace/jira-intelligence. This is the trend framework — rows accumulate to
// support future trend/delta views. Runtime-populated; seed only clears.
export const jiraSyncSnapshotsTable = pgTable(
  "jira_sync_snapshots",
  {
    id: text("id").primaryKey(),
    capturedAt: timestamp("captured_at").defaultNow().notNull(),
    syncRunId: text("sync_run_id"),
    projectCount: integer("project_count").notNull().default(0),
    issueCount: integer("issue_count").notNull().default(0),
    openCount: integer("open_count").notNull().default(0),
    completedCount: integer("completed_count").notNull().default(0),
    blockedCount: integer("blocked_count").notNull().default(0),
    criticalCount: integer("critical_count").notNull().default(0),
    overdueCount: integer("overdue_count").notNull().default(0),
    highestPriorityCount: integer("highest_priority_count").notNull().default(0),
    highPriorityCount: integer("high_priority_count").notNull().default(0),
    mediumPriorityCount: integer("medium_priority_count").notNull().default(0),
    lowPriorityCount: integer("low_priority_count").notNull().default(0),
    healthScore: integer("health_score").notNull().default(100),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    capturedAtIdx: index("jira_sync_snapshots_captured_at_idx").on(t.capturedAt),
  }),
);

// Per-project executive metrics, refreshed (full replace) each sync. `id` ==
// jira project key so re-syncs upsert in place. Counts mirror
// @workspace/jira-intelligence ProjectMetric.
export const jiraProjectMetricsTable = pgTable(
  "jira_project_metrics",
  {
    id: text("id").primaryKey(),
    jiraProjectKey: text("jira_project_key").notNull(),
    jiraProjectName: text("jira_project_name").notNull(),
    issueCount: integer("issue_count").notNull().default(0),
    openCount: integer("open_count").notNull().default(0),
    completedCount: integer("completed_count").notNull().default(0),
    blockedCount: integer("blocked_count").notNull().default(0),
    criticalCount: integer("critical_count").notNull().default(0),
    overdueCount: integer("overdue_count").notNull().default(0),
    highPriorityOpenCount: integer("high_priority_open_count").notNull().default(0),
    openStoryPoints: doublePrecision("open_story_points").notNull().default(0),
    todoCount: integer("todo_count").notNull().default(0),
    inProgressCount: integer("in_progress_count").notNull().default(0),
    doneCount: integer("done_count").notNull().default(0),
    healthClass: text("health_class").notNull().default("healthy"),
    healthScore: integer("health_score").notNull().default(100),
    lastActivity: text("last_activity"),
    staleDays: integer("stale_days"),
    isStale: boolean("is_stale").notNull().default(false),
    capturedAt: timestamp("captured_at").defaultNow().notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    projectKeyIdx: uniqueIndex("jira_project_metrics_project_key_idx").on(t.jiraProjectKey),
  }),
);

export const insertJiraConfigurationSchema = createInsertSchema(jiraConfigurationTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraConfiguration = z.infer<typeof insertJiraConfigurationSchema>;
export type JiraConfigurationRow = typeof jiraConfigurationTable.$inferSelect;

export const insertJiraSyncSettingsSchema = createInsertSchema(jiraSyncSettingsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraSyncSettings = z.infer<typeof insertJiraSyncSettingsSchema>;
export type JiraSyncSettingsRow = typeof jiraSyncSettingsTable.$inferSelect;

export const insertJiraDiscoveredProjectSchema = createInsertSchema(
  jiraDiscoveredProjectsTable,
).omit({ createdAt: true, updatedAt: true });
export type InsertJiraDiscoveredProject = z.infer<typeof insertJiraDiscoveredProjectSchema>;
export type JiraDiscoveredProjectRow = typeof jiraDiscoveredProjectsTable.$inferSelect;

export const insertJiraDiscoveredFieldSchema = createInsertSchema(jiraDiscoveredFieldsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraDiscoveredField = z.infer<typeof insertJiraDiscoveredFieldSchema>;
export type JiraDiscoveredFieldRow = typeof jiraDiscoveredFieldsTable.$inferSelect;

export const insertJiraProjectMappingSchema = createInsertSchema(jiraProjectMappingsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraProjectMapping = z.infer<typeof insertJiraProjectMappingSchema>;
export type JiraProjectMappingRow = typeof jiraProjectMappingsTable.$inferSelect;

export const insertJiraFieldMappingSchema = createInsertSchema(jiraFieldMappingsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraFieldMapping = z.infer<typeof insertJiraFieldMappingSchema>;
export type JiraFieldMappingRow = typeof jiraFieldMappingsTable.$inferSelect;

export const insertJiraStatusMappingSchema = createInsertSchema(jiraStatusMappingsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraStatusMapping = z.infer<typeof insertJiraStatusMappingSchema>;
export type JiraStatusMappingRow = typeof jiraStatusMappingsTable.$inferSelect;

export const insertJiraSyncSnapshotSchema = createInsertSchema(jiraSyncSnapshotsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraSyncSnapshot = z.infer<typeof insertJiraSyncSnapshotSchema>;
export type JiraSyncSnapshotRow = typeof jiraSyncSnapshotsTable.$inferSelect;

export const insertJiraProjectMetricSchema = createInsertSchema(jiraProjectMetricsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertJiraProjectMetric = z.infer<typeof insertJiraProjectMetricSchema>;
export type JiraProjectMetricRow = typeof jiraProjectMetricsTable.$inferSelect;
