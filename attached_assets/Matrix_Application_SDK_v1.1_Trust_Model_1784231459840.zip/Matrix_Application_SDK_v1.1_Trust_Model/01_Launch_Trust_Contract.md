# Launch Trust Contract

Official transport:
`https://<app-url>#matrix_token=<JWT>`

Frontend requirements:
- Read `window.location.hash`.
- Remove the token immediately with `history.replaceState`.
- Send it once to a server-side launch exchange endpoint.
- Never persist it in browser storage or logs.

Server requirements:
- Validate with Matrix Platform JWKS.
- Pin algorithm to RS256.
- Validate configured issuer.
- Validate the application's registered audience.
- Validate expiration.
- Reject contradictory application-id claims when present.
- Create an HttpOnly, Secure, SameSite application session cookie.

Do not accept a token merely because it is present or decodable.
