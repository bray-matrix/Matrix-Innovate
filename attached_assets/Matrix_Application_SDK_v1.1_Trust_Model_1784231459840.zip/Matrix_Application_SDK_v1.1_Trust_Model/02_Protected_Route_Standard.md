# Protected Route Standard

Direct access without an authenticated application session must not expose business functionality.

Show:
**Matrix Platform sign-in required**
This application is managed by Matrix Platform. Launch it from Matrix Platform to continue.

Require server-side authentication for:
- Business pages
- Internal read APIs
- Create/update/delete/approval/admin/import APIs
- Files and documents
- User-triggered background operations

The following may remain public only when they expose safe metadata:
- `GET /matrix/health`
- `GET /matrix/app-info`
- `GET /matrix/manifest`

Logout must destroy the local session and clear the cookie.
