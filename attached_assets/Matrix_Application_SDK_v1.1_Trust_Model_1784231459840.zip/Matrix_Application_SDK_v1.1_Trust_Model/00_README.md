# Matrix Application SDK v1.1 — Trust Model Update

Required flow:
1. User authenticates to Matrix Platform.
2. Platform authorizes launch.
3. Platform sends a short-lived RS256 token in `#matrix_token=<JWT>`.
4. The app removes the token from the URL and exchanges it server-side.
5. The app server validates signature, issuer, audience, algorithm, and expiration.
6. The app creates a secure local session cookie.
7. All business pages and APIs require that session.

Token presence alone is never authentication.
