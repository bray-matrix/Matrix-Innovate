# Configuration and Testing

Environment configuration:
- Platform issuer
- Platform JWKS URL
- Application audience
- Platform production URL
- Session secret
- Session lifetime

Required tests:
1. Incognito direct URL: business UI blocked; protected APIs return 401.
2. Platform launch: fragment token consumed and scrubbed; session created; user shown.
3. Invalid tokens rejected: garbage, expired, wrong issuer, wrong audience, wrong signature, wrong algorithm.
4. Logout destroys the session.
5. Replit Security Scan no longer reports unauthenticated read/write access.

Do not make the application public until these tests pass.
