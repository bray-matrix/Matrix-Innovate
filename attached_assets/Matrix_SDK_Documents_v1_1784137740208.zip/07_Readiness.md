# Readiness

Applications are evaluated for Branding, Authentication, Platform Integration, Security and Quality.
