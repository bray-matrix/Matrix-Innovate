# Authentication

Matrix Platform authenticates. Applications trust the launch token. No separate login.
