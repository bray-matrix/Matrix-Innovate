# Best Practices

Reuse the SDK. Expose standard endpoints. Separate business logic from platform infrastructure.
