# Manifest

Include name, slug, version, SDK version, owner, production URL, preview URL, health endpoint, version endpoint.
