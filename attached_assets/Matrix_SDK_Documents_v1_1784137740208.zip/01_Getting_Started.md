# Matrix Application SDK - Getting Started

- Launch from Matrix Platform
- Trust Matrix authentication
- Use Matrix branding
- Implement /matrix/app-info
- Implement /matrix/health
- Register with Platform
- Pass Readiness
