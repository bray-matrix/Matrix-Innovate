# Versioning

Use semantic versioning and update release history each release.
