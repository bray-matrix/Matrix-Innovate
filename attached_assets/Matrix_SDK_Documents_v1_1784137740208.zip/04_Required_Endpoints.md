# Required Endpoints

GET /matrix/app-info
GET /matrix/health
