import { z } from "zod/v4";
import { MATRIX_SDK_VERSION, isValidVersion, parseVersion } from "./version";

/**
 * Matrix Application Publishing (v1.0) — the standard contract an application
 * submits to Matrix Platform to be registered automatically.
 *
 * This module is ADDITIVE to the existing SDK standards: the runtime
 * application manifest (`createManifest`, served by GET /matrix/app-info) is
 * unchanged. The publish manifest is the richer registration document a team
 * submits (or automates) to publish a release into the platform registry.
 */

/** The publish-manifest contract version this SDK understands. */
export const PUBLISH_MANIFEST_VERSION = "1.0";

/** Publish-manifest contract versions the platform accepts. */
export const SUPPORTED_PUBLISH_MANIFEST_VERSIONS: readonly string[] = ["1.0"];

/** Matrix branding standard versions the platform accepts. */
export const SUPPORTED_BRANDING_VERSIONS: readonly string[] = ["1.0"];

/** A navigation entry the application contributes to the platform shell. */
export const PublishNavigationItemSchema = z.object({
  label: z.string().min(1),
  path: z.string().startsWith("/"),
  /** Lucide icon name rendered by the platform shell. */
  icon: z.string().min(1),
});

/** An application-declared permission string. */
export const PublishPermissionSchema = z.object({
  key: z.string().min(1),
  description: z.string().min(1),
});

export const MatrixPublishManifestSchema = z.object({
  /** Stable kebab-case application identifier, e.g. "matrix-operations-hub". */
  applicationId: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "must be kebab-case"),
  /** Human-readable application name. */
  name: z.string().min(1),
  /** Application semantic version being published. */
  version: z.string().refine(isValidVersion, "must be a semantic version"),
  /** Matrix SDK version the application was built with. */
  sdkVersion: z.string().refine(isValidVersion, "must be a semantic version"),
  /** Publish-manifest contract version this document was authored against. */
  manifestVersion: z.string().min(1),
  /** Where the application actually runs (http/https only). */
  launchUrl: z.url({ protocol: /^https?$/ }),
  /** Path of the health endpoint (standard: "/matrix/health"). */
  healthEndpoint: z.string().startsWith("/"),
  /** Path of the endpoint reporting the running version (standard: "/matrix/app-info"). */
  versionEndpoint: z.string().startsWith("/"),
  /** How the application authenticates users. */
  authenticationType: z.enum(["sso", "delegated", "none"]),
  /** Navigation entries contributed to the platform shell (may be empty). */
  navigation: z.array(PublishNavigationItemSchema),
  /** Application-declared permission catalog (may be empty). */
  permissions: z.array(PublishPermissionSchema),
  /** Matrix branding standard version the application implements. */
  brandingVersion: z.string().min(1),
  /** Owning team or person. */
  owner: z.string().min(1),
  /** Source repository URL (http/https only). */
  repositoryUrl: z.url({ protocol: /^https?$/ }),
  /** Optional short description shown in platform surfaces. */
  description: z.string().nullish(),
  /** Optional lucide icon name for the application tile. */
  icon: z.string().nullish(),
});

export type MatrixPublishManifest = z.infer<typeof MatrixPublishManifestSchema>;

/** Friendly labels used when turning validation issues into human messages. */
const FIELD_LABELS: Record<string, string> = {
  applicationId: "Application ID",
  name: "Application Name",
  version: "Semantic Version",
  sdkVersion: "SDK Version",
  manifestVersion: "Manifest Version",
  launchUrl: "Launch URL",
  healthEndpoint: "Health Endpoint",
  versionEndpoint: "Version Endpoint",
  authenticationType: "Authentication Type",
  navigation: "Navigation Definition",
  permissions: "Application Permissions",
  brandingVersion: "Branding Version",
  owner: "Owner",
  repositoryUrl: "Repository URL",
  description: "Description",
  icon: "Icon",
};

export interface PublishValidationSuccess {
  ok: true;
  manifest: MatrixPublishManifest;
}

export interface PublishValidationFailure {
  ok: false;
  /** Friendly, field-labelled validation error messages. */
  errors: string[];
}

export type PublishValidationResult =
  | PublishValidationSuccess
  | PublishValidationFailure;

/**
 * Validates a submitted publish manifest and returns friendly errors instead
 * of throwing. Structural validation only — SDK compatibility, branding
 * compliance, and registry version checks are separate pipeline steps.
 */
export function validatePublishManifest(input: unknown): PublishValidationResult {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    return { ok: false, errors: ["The manifest must be a JSON object."] };
  }
  const parsed = MatrixPublishManifestSchema.safeParse(input);
  if (parsed.success) return { ok: true, manifest: parsed.data };
  const errors = parsed.error.issues.map((issue) => {
    const root = String(issue.path[0] ?? "");
    const label = FIELD_LABELS[root] ?? (root || "Manifest");
    const where =
      issue.path.length > 1 ? ` (at ${issue.path.join(".")})` : "";
    if (issue.code === "invalid_type" && issue.input === undefined) {
      return `${label} is required${where}.`;
    }
    return `${label}${where}: ${issue.message}.`;
  });
  return { ok: false, errors: Array.from(new Set(errors)) };
}

export interface SdkCompatibilityResult {
  compatible: boolean;
  /** True when the manifest was built against an older SDK major version. */
  outOfDate: boolean;
  reason: string | null;
}

/**
 * Checks whether an application built against `sdkVersion` is compatible with
 * the platform's current Matrix SDK. Compatibility rule: same major version.
 * An older major is "SDK out of date"; a newer major is not yet supported.
 */
export function checkSdkCompatibility(
  sdkVersion: string,
  platformSdkVersion: string = MATRIX_SDK_VERSION,
): SdkCompatibilityResult {
  const app = parseVersion(sdkVersion);
  const platform = parseVersion(platformSdkVersion);
  if (!app || !platform) {
    return {
      compatible: false,
      outOfDate: false,
      reason: `SDK Version "${sdkVersion}" is not a valid semantic version.`,
    };
  }
  if (app.major < platform.major) {
    return {
      compatible: false,
      outOfDate: true,
      reason: `SDK Version ${sdkVersion} is out of date — the platform requires Matrix SDK ${platform.major}.x (current: ${platformSdkVersion}).`,
    };
  }
  if (app.major > platform.major) {
    return {
      compatible: false,
      outOfDate: false,
      reason: `SDK Version ${sdkVersion} is newer than the platform's Matrix SDK (${platformSdkVersion}) and is not yet supported.`,
    };
  }
  return { compatible: true, outOfDate: false, reason: null };
}

/** Whether the publish-manifest contract version is accepted by the platform. */
export function isSupportedManifestVersion(manifestVersion: string): boolean {
  return SUPPORTED_PUBLISH_MANIFEST_VERSIONS.includes(manifestVersion.trim());
}

/** Whether the branding standard version is accepted by the platform. */
export function isSupportedBrandingVersion(brandingVersion: string): boolean {
  return SUPPORTED_BRANDING_VERSIONS.includes(brandingVersion.trim());
}
