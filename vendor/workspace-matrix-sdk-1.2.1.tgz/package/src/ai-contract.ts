import { z } from "zod";

/** Deliberately small, closed JSON Schema subset. No refs, regexes or remote resolution. */
export interface AiJsonSchema {
  type: "object" | "array" | "string" | "number" | "integer" | "boolean" | "null";
  properties?: Record<string, AiJsonSchema>;
  required?: string[];
  additionalProperties?: false;
  items?: AiJsonSchema;
  enum?: (string | number | boolean | null)[];
}

export function validAiSchema(value: unknown): value is AiJsonSchema {
  let nodes = 0;
  function visit(v: unknown, depth: number): boolean {
    if (++nodes > 100 || depth > 6 || !v || typeof v !== "object" || Array.isArray(v)) return false;
    const s = v as AiJsonSchema;
    if (!["object", "array", "string", "number", "integer", "boolean", "null"].includes(s.type)) return false;
    const allowed = s.type === "object" ? ["type", "properties", "required", "additionalProperties"] :
      s.type === "array" ? ["type", "items"] : ["type", "enum"];
    if (Object.keys(v).some((k) => !allowed.includes(k))) return false;
    if (s.type === "object") {
      if (!s.properties || typeof s.properties !== "object" || Array.isArray(s.properties) ||
          s.additionalProperties !== false || !Array.isArray(s.required)) return false;
      const keys = Object.keys(s.properties);
      if (keys.length > 40 || s.required.length !== keys.length || new Set(s.required).size !== keys.length ||
          s.required.some((k) => !keys.includes(k)) ||
          keys.some((k) => !/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(k) || ["constructor", "prototype", "__proto__"].includes(k))) return false;
      return Object.values(s.properties).every((x) => visit(x, depth + 1));
    }
    if (s.type === "array") return visit(s.items, depth + 1);
    return s.enum === undefined || (Array.isArray(s.enum) && s.enum.length > 0 && s.enum.length <= 50 &&
      s.enum.every((x) => primitiveMatches(s.type, x) && (typeof x !== "string" || x.length <= 200)));
  }
  try { return JSON.stringify(value).length <= 16000 && visit(value, 0) && (value as AiJsonSchema).type === "object"; }
  catch { return false; }
}

function primitiveMatches(type: AiJsonSchema["type"], value: unknown): boolean {
  if (type === "null") return value === null;
  if (type === "integer") return typeof value === "number" && Number.isSafeInteger(value);
  if (type === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === type;
}

export function matchesAiSchema(schema: AiJsonSchema, value: unknown): boolean {
  let nodes = 0;
  function visit(s: AiJsonSchema, v: unknown): boolean {
    if (++nodes > 10000) return false;
    if (s.type === "object") {
      if (!v || typeof v !== "object" || Array.isArray(v)) return false;
      const obj = v as Record<string, unknown>;
      const properties = s.properties!;
      return Object.keys(obj).length === Object.keys(properties).length &&
        Object.entries(properties).every(([k, sub]) => Object.hasOwn(obj, k) && visit(sub, obj[k]));
    }
    if (s.type === "array") return Array.isArray(v) && v.length <= 1000 && v.every((x) => visit(s.items!, x));
    return primitiveMatches(s.type, v) && (!s.enum || s.enum.includes(v as never));
  }
  return visit(schema, value);
}

const fields = {
  instruction: z.string().min(1).max(8000),
  messages: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string().min(1).max(8000),
  }).strict()).min(1).max(30),
  maxOutputTokens: z.number().int().min(1).max(2048).optional(),
  temperature: z.number().min(0).max(1).optional(),
  /** Non-sensitive feature key, never a user's prompt or identity. */
  feature: z.string().regex(/^[a-zA-Z0-9._-]{1,64}$/).optional(),
};
function withinBudget(v: { instruction: string; messages: { content: string }[] }) {
  return v.instruction.length + v.messages.reduce((n, m) => n + m.content.length, 0) <= 24000;
}
export const aiTextRequestSchema = z.object(fields).strict().refine(withinBudget);
export const aiStructuredRequestSchema = z.object({
  ...fields, schema: z.custom<AiJsonSchema>(validAiSchema),
}).strict().refine(withinBudget);
export type AiTextRequest = z.infer<typeof aiTextRequestSchema>;
export type AiStructuredRequest = z.infer<typeof aiStructuredRequestSchema>;
const tokens = z.number().int().nonnegative().nullable();
export const aiUsageSchema = z.object({
  inputTokens: tokens, outputTokens: tokens, totalTokens: tokens,
  actualCost: z.number().nonnegative().nullable(),
});
export const aiMetadataSchema = z.object({
  requestId: z.string(), provider: z.string(), model: z.string(),
  durationMs: z.number().nonnegative(), usage: aiUsageSchema,
});
export const aiTextResultSchema = aiMetadataSchema.extend({ text: z.string().min(1) });
export const aiStructuredResultSchema = aiMetadataSchema.extend({ data: z.unknown() });
export type AiTextResult = z.infer<typeof aiTextResultSchema>;
export type AiStructuredResult = z.infer<typeof aiStructuredResultSchema>;