import { z } from "zod/v4";
import { MATRIX_SDK_VERSION, isValidVersion } from "./version";

/**
 * Matrix Application Manifest — the standard self-description every Matrix
 * application exposes. Served verbatim by `GET /matrix/app-info`.
 */
export const MatrixAppManifestSchema = z.object({
  /** Human-readable application name, e.g. "Matrix Infrastructure Hub". */
  name: z.string().min(1),
  /** URL-safe stable identifier, e.g. "matrix-infrastructure-hub". */
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "slug must be kebab-case"),
  /** Application semantic version, e.g. "1.4.0". */
  version: z.string().refine(isValidVersion, "must be a semantic version"),
  /** ISO-8601 build timestamp. */
  buildDate: z.iso.datetime(),
  /** Git commit SHA the build was produced from (null when unknown). */
  gitCommit: z.string().min(7).nullable(),
  /** Owning team or person. */
  owner: z.string().min(1),
  /** Where the application runs in production (http/https only). */
  productionUrl: z.url({ protocol: /^https?$/ }).nullable(),
  /** Where the application runs in development (http/https only). */
  developmentUrl: z.url({ protocol: /^https?$/ }).nullable(),
  /** The Matrix SDK version the application was built with. */
  sdkVersion: z.string().refine(isValidVersion, "must be a semantic version"),
  /** Path of the health endpoint (standard: "/matrix/health"). */
  healthEndpoint: z.string().startsWith("/"),
  /** Path of the readiness endpoint, or null until one is provided. */
  readinessEndpoint: z.string().startsWith("/").nullable(),
});

export type MatrixAppManifest = z.infer<typeof MatrixAppManifestSchema>;

export interface CreateManifestInput
  extends Omit<
    MatrixAppManifest,
    "sdkVersion" | "healthEndpoint" | "readinessEndpoint" | "buildDate" | "gitCommit" | "productionUrl" | "developmentUrl"
  > {
  buildDate?: string;
  gitCommit?: string | null;
  productionUrl?: string | null;
  developmentUrl?: string | null;
  sdkVersion?: string;
  healthEndpoint?: string;
  readinessEndpoint?: string | null;
}

/**
 * Builds and validates a Matrix Application Manifest, filling in SDK-managed
 * defaults (sdkVersion, standard endpoint paths, build date). Throws when the
 * result is not a valid manifest, so misconfiguration fails at boot — not in
 * production traffic.
 */
export function createManifest(input: CreateManifestInput): MatrixAppManifest {
  return MatrixAppManifestSchema.parse({
    buildDate: input.buildDate ?? new Date().toISOString(),
    gitCommit: input.gitCommit ?? null,
    productionUrl: input.productionUrl ?? null,
    developmentUrl: input.developmentUrl ?? null,
    sdkVersion: input.sdkVersion ?? MATRIX_SDK_VERSION,
    healthEndpoint: input.healthEndpoint ?? "/matrix/health",
    readinessEndpoint: input.readinessEndpoint ?? null,
    name: input.name,
    slug: input.slug,
    version: input.version,
    owner: input.owner,
  });
}
