/**
 * Matrix Application SDK — version helpers.
 *
 * Applications should stop duplicating version logic: declare the version in
 * their manifest once and use these helpers everywhere it is displayed or
 * compared.
 */

/** The version of the Matrix Application SDK itself. */
export const MATRIX_SDK_VERSION = "1.2.1";

export interface ParsedVersion {
  major: number;
  minor: number;
  patch: number;
  /** Pre-release suffix (e.g. "alpha"), or null for stable versions. */
  prerelease: string | null;
}

const VERSION_PATTERN = /^v?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/;

/** Parses a semantic version string ("1.2.3", "v1.2.3", "1.2.3-alpha"). */
export function parseVersion(version: string): ParsedVersion | null {
  const match = VERSION_PATTERN.exec(version.trim());
  if (!match) return null;
  return {
    major: Number(match[1]),
    minor: Number(match[2]),
    patch: Number(match[3]),
    prerelease: match[4] ?? null,
  };
}

/** True when the string is a valid semantic version. */
export function isValidVersion(version: string): boolean {
  return parseVersion(version) !== null;
}

/**
 * Compares two semantic versions. Returns -1, 0, or 1. A pre-release sorts
 * before the corresponding stable release. Invalid versions throw.
 */
export function compareVersions(a: string, b: string): -1 | 0 | 1 {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  if (!pa || !pb) {
    throw new Error(`Cannot compare invalid versions: "${a}" vs "${b}"`);
  }
  for (const key of ["major", "minor", "patch"] as const) {
    if (pa[key] !== pb[key]) return pa[key] < pb[key] ? -1 : 1;
  }
  if (pa.prerelease === pb.prerelease) return 0;
  if (pa.prerelease === null) return 1;
  if (pb.prerelease === null) return -1;
  return pa.prerelease < pb.prerelease ? -1 : 1;
}

/** Standard user-facing version label, e.g. "My App v1.4.0". */
export function formatVersionLabel(appName: string, version: string): string {
  const normalized = version.replace(/^v/, "");
  return `${appName} v${normalized}`;
}
