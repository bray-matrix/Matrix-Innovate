/**
 * Matrix SDK readiness registration points.
 *
 * Future readiness providers plug in here so an application can expose its
 * own readiness evidence. This does NOT change the platform Readiness Center
 * (T004/v0.11.0) — the platform continues to own the catalog and scoring.
 */

export type ReadinessCheckStatus = "pass" | "fail" | "not_applicable";

export interface ReadinessProviderResult {
  /** Platform readiness check id this result addresses. */
  checkId: string;
  status: ReadinessCheckStatus;
  /** Optional supporting evidence (URL, note). */
  evidence?: string;
}

export interface ReadinessProvider {
  /** Unique provider id within the application, e.g. "branding". */
  id: string;
  /** Produces this provider's readiness results. */
  collect(): Promise<ReadinessProviderResult[]> | ReadinessProviderResult[];
}

export interface ReadinessRegistry {
  register(provider: ReadinessProvider): void;
  list(): ReadinessProvider[];
  /** Runs all providers; provider failures surface as errors, not silence. */
  collectAll(): Promise<ReadinessProviderResult[]>;
}

export function createReadinessRegistry(): ReadinessRegistry {
  const providers = new Map<string, ReadinessProvider>();
  return {
    register(provider) {
      if (!provider.id) throw new Error("Readiness provider requires an id");
      if (providers.has(provider.id)) {
        throw new Error(
          `Readiness provider "${provider.id}" is already registered`,
        );
      }
      providers.set(provider.id, provider);
    },
    list() {
      return Array.from(providers.values());
    },
    async collectAll() {
      const results: ReadinessProviderResult[] = [];
      for (const provider of providers.values()) {
        results.push(...(await provider.collect()));
      }
      return results;
    },
  };
}
