export * from "./ai-contract";
export { createPlatformClient, PlatformServiceError } from "./platform-client";
export type {
  PlatformClient, PlatformClientOptions, PlatformErrorCode,
  AuthorizedPlatformUser, AuthorizedUsersSearchResult, AuthorizedUserResolution,
} from "./platform-client";

export {
  MATRIX_SDK_VERSION,
  parseVersion,
  isValidVersion,
  compareVersions,
  formatVersionLabel,
} from "./version";
export type { ParsedVersion } from "./version";

export { MatrixAppManifestSchema, createManifest } from "./manifest";
export type { MatrixAppManifest, CreateManifestInput } from "./manifest";

export {
  MATRIX_APP_INFO_PATH,
  MATRIX_HEALTH_PATH,
  buildHealthReport,
  createAppInfoHandler,
  createHealthHandler,
  registerMatrixEndpoints,
} from "./endpoints";
export type {
  HealthCheck,
  HealthReport,
  MatrixEndpointsOptions,
  MatrixEndpointHandler,
  MinimalResponse,
  RegistrableRouter,
} from "./endpoints";

export {
  MATRIX_PLATFORM_ISSUER,
  createLaunchTokenVerifier,
  toVerifiedLaunchIdentity,
} from "./launch-token";
export type {
  LaunchTokenVerifier,
  LaunchTokenVerifierOptions,
  VerifiedLaunchIdentity,
} from "./launch-token";

export { createNotificationService } from "./notifications";
export type {
  MatrixNotificationInput,
  MatrixNotificationService,
  NotificationPublisher,
} from "./notifications";

export {
  PUBLISH_MANIFEST_VERSION,
  SUPPORTED_PUBLISH_MANIFEST_VERSIONS,
  SUPPORTED_BRANDING_VERSIONS,
  MatrixPublishManifestSchema,
  PublishNavigationItemSchema,
  PublishPermissionSchema,
  validatePublishManifest,
  checkSdkCompatibility,
  isSupportedManifestVersion,
  isSupportedBrandingVersion,
} from "./publishing";
export type {
  MatrixPublishManifest,
  PublishValidationResult,
  PublishValidationSuccess,
  PublishValidationFailure,
  SdkCompatibilityResult,
} from "./publishing";

export { createReadinessRegistry } from "./readiness";
export type {
  ReadinessCheckStatus,
  ReadinessProvider,
  ReadinessProviderResult,
  ReadinessRegistry,
} from "./readiness";
