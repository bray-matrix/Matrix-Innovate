import { createRemoteJWKSet, jwtVerify } from "jose";

/**
 * Server-side verification of the Matrix Platform launch token, implementing
 * the contract in docs/App-Integration.md. No authentication behavior is
 * changed by this module — it codifies the existing Trust Layer contract so
 * applications stop hand-rolling it.
 */

export const MATRIX_PLATFORM_ISSUER = "matrix-platform";

export interface LaunchTokenVerifierOptions {
  /** Matrix Platform origin, e.g. "https://matrix-platform.replit.app". */
  platformOrigin: string;
  /** This application's registered API audience. */
  audience: string;
}

export interface VerifiedLaunchIdentity {
  /** Stable platform user id (Entra object id when available). */
  sub: string;
  oid: string | null;
  tid: string | null;
  name: string | null;
  email: string | null;
  roles: string[];
  /** Unique token id — usable for one-time-use enforcement. */
  jti: string | null;
}

export type LaunchTokenVerifier = (
  token: string,
) => Promise<VerifiedLaunchIdentity>;

/**
 * Creates a verifier bound to the platform JWKS. The JWKS is fetched lazily
 * and cached by `jose`; key rotation is handled via the token `kid` header.
 * Enforces signature, RS256, issuer, audience, and expiry — a token minted
 * for another application is rejected.
 */
export function createLaunchTokenVerifier(
  options: LaunchTokenVerifierOptions,
): LaunchTokenVerifier {
  const jwksUrl = new URL(
    "/api/platform/jwks",
    options.platformOrigin,
  );
  const jwks = createRemoteJWKSet(jwksUrl);
  return async (token: string) => {
    const { payload } = await jwtVerify(token, jwks, {
      issuer: MATRIX_PLATFORM_ISSUER,
      audience: options.audience,
      algorithms: ["RS256"],
    });
    return toVerifiedLaunchIdentity(payload);
  };
}

/**
 * Maps a verified JWT payload to the standard launch identity. Exported for
 * testing; production code reaches it only through the verifier, after
 * signature/issuer/audience/expiry enforcement.
 */
export function toVerifiedLaunchIdentity(
  payload: Record<string, unknown>,
): VerifiedLaunchIdentity {
  if (typeof payload.sub !== "string" || payload.sub.length === 0) {
    throw new Error("Launch token is missing a subject");
  }
  return {
    sub: payload.sub,
    oid: typeof payload.oid === "string" ? payload.oid : null,
    tid: typeof payload.tid === "string" ? payload.tid : null,
    name: typeof payload.name === "string" ? payload.name : null,
    email: typeof payload.email === "string" ? payload.email : null,
    roles: Array.isArray(payload.roles)
      ? payload.roles.filter((r): r is string => typeof r === "string")
      : [],
    jti: typeof payload.jti === "string" ? payload.jti : null,
  };
}
