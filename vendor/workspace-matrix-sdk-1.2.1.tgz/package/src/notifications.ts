/**
 * Matrix SDK notification service — registration point only.
 *
 * This release defines the standard contract future Matrix applications will
 * use to publish notifications toward the platform. It does NOT change any
 * existing Notification Center behavior; no transport is wired up yet.
 */

export interface MatrixNotificationInput {
  /** Stable event key, e.g. "invoice.approved". */
  action: string;
  /** Human-readable notification title. */
  title: string;
  /** Optional short description shown under the title. */
  description?: string;
  /** Optional in-app path the notification navigates to. */
  href?: string;
}

export type NotificationPublisher = (
  notification: MatrixNotificationInput,
) => Promise<void> | void;

export interface MatrixNotificationService {
  /** Queues/publishes a notification through the registered publisher. */
  publish(notification: MatrixNotificationInput): Promise<void>;
  /** Registers the transport. Exactly one publisher may be active. */
  registerPublisher(publisher: NotificationPublisher): void;
  /** True once a transport has been registered. */
  hasPublisher(): boolean;
}

/**
 * Creates the standard notification service. Until a publisher is registered,
 * `publish` fails loudly (no silent drops, no mock delivery).
 */
export function createNotificationService(): MatrixNotificationService {
  let publisher: NotificationPublisher | null = null;
  return {
    registerPublisher(next) {
      if (publisher) {
        throw new Error("A notification publisher is already registered");
      }
      publisher = next;
    },
    hasPublisher() {
      return publisher !== null;
    },
    async publish(notification) {
      if (!notification.action || !notification.title) {
        throw new Error("Notification requires an action and a title");
      }
      if (!publisher) {
        throw new Error(
          "No notification publisher registered — notification transport arrives in a future release",
        );
      }
      await publisher(notification);
    },
  };
}
