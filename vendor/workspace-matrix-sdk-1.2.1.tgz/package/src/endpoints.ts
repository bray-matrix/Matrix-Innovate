import type { MatrixAppManifest } from "./manifest";

/**
 * Standard Matrix application endpoints.
 *
 * Framework-agnostic: handlers are written against a minimal request/response
 * shape that Express (4/5) and most Node frameworks satisfy, so this package
 * does not force a web framework on the application.
 */

export interface MinimalResponse {
  status(code: number): MinimalResponse;
  json(body: unknown): unknown;
}

export type MatrixEndpointHandler = (
  req: unknown,
  res: MinimalResponse,
) => void | Promise<void>;

/** A single dependency check contributing to /matrix/health. */
export interface HealthCheck {
  name: string;
  /** Resolve true = healthy. Rejections/false mark the check unhealthy. */
  check: () => boolean | Promise<boolean>;
}

export interface HealthReport {
  status: "healthy" | "degraded";
  application: string;
  version: string;
  sdkVersion: string;
  timestamp: string;
  checks: Array<{ name: string; healthy: boolean }>;
}

export interface MatrixEndpointsOptions {
  manifest: MatrixAppManifest;
  /** Optional dependency checks folded into /matrix/health. */
  healthChecks?: HealthCheck[];
  /** Per-check timeout in milliseconds (default 2500). */
  healthCheckTimeoutMs?: number;
}

/** Standard paths every Matrix application serves. */
export const MATRIX_APP_INFO_PATH = "/matrix/app-info";
export const MATRIX_HEALTH_PATH = "/matrix/health";

async function runCheck(
  check: HealthCheck,
  timeoutMs: number,
): Promise<boolean> {
  try {
    const result = await Promise.race([
      Promise.resolve(check.check()),
      new Promise<boolean>((resolve) =>
        setTimeout(() => resolve(false), timeoutMs),
      ),
    ]);
    return result === true;
  } catch {
    return false;
  }
}

/** Computes the standard health report (also usable outside HTTP). */
export async function buildHealthReport(
  options: MatrixEndpointsOptions,
): Promise<HealthReport> {
  const timeout = options.healthCheckTimeoutMs ?? 2500;
  const checks = await Promise.all(
    (options.healthChecks ?? []).map(async (check) => ({
      name: check.name,
      healthy: await runCheck(check, timeout),
    })),
  );
  return {
    status: checks.every((c) => c.healthy) ? "healthy" : "degraded",
    application: options.manifest.slug,
    version: options.manifest.version,
    sdkVersion: options.manifest.sdkVersion,
    timestamp: new Date().toISOString(),
    checks,
  };
}

/** Handler for GET /matrix/app-info — serves the manifest verbatim. */
export function createAppInfoHandler(
  manifest: MatrixAppManifest,
): MatrixEndpointHandler {
  return (_req, res) => {
    res.status(200).json(manifest);
  };
}

/** Handler for GET /matrix/health — 200 healthy, 503 degraded. */
export function createHealthHandler(
  options: MatrixEndpointsOptions,
): MatrixEndpointHandler {
  return async (_req, res) => {
    const report = await buildHealthReport(options);
    res.status(report.status === "healthy" ? 200 : 503).json(report);
  };
}

/** Anything with `.get(path, handler)` — an Express app or router qualifies. */
export interface RegistrableRouter {
  get(path: string, handler: MatrixEndpointHandler): unknown;
}

/**
 * Registers the standard Matrix endpoints on an app/router with one call:
 *
 * ```ts
 * registerMatrixEndpoints(app, { manifest, healthChecks: [dbCheck] });
 * ```
 */
export function registerMatrixEndpoints(
  router: RegistrableRouter,
  options: MatrixEndpointsOptions,
): void {
  router.get(MATRIX_APP_INFO_PATH, createAppInfoHandler(options.manifest));
  router.get(MATRIX_HEALTH_PATH, createHealthHandler(options));
}
