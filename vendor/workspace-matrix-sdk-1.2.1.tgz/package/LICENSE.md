# License — Internal / Proprietary

Copyright &copy; Matrix Imaging Solutions. All rights reserved.

**This is a placeholder license for an internal, proprietary project.**

Matrix Platform, including all source code,
documentation, designs, and related materials in this repository (the
"Software"), are the confidential and proprietary property of Matrix Imaging
Solutions.

## Permitted use

The Software is provided solely for internal use by Matrix Imaging Solutions and
its authorized personnel. Authorized personnel may use, modify, and build upon
the Software in the course of their work for Matrix Imaging Solutions.

## Restrictions

Unless expressly authorized in writing by Matrix Imaging Solutions, you may not:

- copy, distribute, publish, or disclose the Software to any third party;
- use the Software outside the scope of Matrix Imaging Solutions business;
- remove or alter any proprietary notices.

## No warranty

The Software is provided "as is", without warranty of any kind, express or
implied. Matrix Imaging Solutions shall not be liable for any claim, damages, or
other liability arising from the Software or its use.

---

_This placeholder will be replaced by a formal license agreement approved by
Matrix Imaging Solutions._
