import { z } from "zod";
import {
  aiTextRequestSchema, aiStructuredRequestSchema, aiTextResultSchema, aiStructuredResultSchema,
  matchesAiSchema, type AiTextRequest, type AiStructuredRequest,
} from "./ai-contract";

/** Server-only application trust. Never pass this configuration to React or a manifest. */
export interface PlatformClientOptions {
  platformUrl: string;
  applicationId: string;
  applicationSecret: string;
  timeoutMs?: number;
  /** Test/host transport. Must preserve redirect:error and credential isolation. */
  fetch?: typeof globalThis.fetch;
}

export type PlatformErrorCode = "configuration_required" | "unauthorized" | "forbidden" |
  "invalid_request" | "unavailable" | "invalid_response" | "rate_limited";

/** Deliberately excludes response bodies, URLs, headers and credentials. */
export class PlatformServiceError extends Error {
  constructor(public readonly code: PlatformErrorCode, public readonly status?: number) {
    super(`Platform service: ${code}`);
    this.name = "PlatformServiceError";
  }
}

const userSchema = z.object({
  stableUserId: z.string().regex(/^[1-9]\d{0,9}$/).refine((id) => Number(id) <= 2147483647),
  displayName: z.string(),
  email: z.string(),
  active: z.literal(true),
  eligibleForApplication: z.literal(true),
});
const searchSchema = z.object({
  users: z.array(userSchema),
  limit: z.number().int().min(1).max(100),
  offset: z.number().int().min(0).max(10000),
  hasMore: z.boolean(),
});
const resolveSchema = z.union([
  z.object({ valid: z.literal(true), user: userSchema, reason: z.null() }),
  z.object({ valid: z.literal(false), user: z.null(), reason: z.literal("not_found_or_ineligible") }),
]);
const sessionSchema = z.object({
  ok: z.literal(true),
  token: z.string().regex(/^mxt_[A-Za-z0-9_-]{20,}$/),
  expiresAt: z.string().datetime(),
});

export type AuthorizedPlatformUser = z.infer<typeof userSchema>;
export type AuthorizedUsersSearchResult = z.infer<typeof searchSchema>;
export type AuthorizedUserResolution = z.infer<typeof resolveSchema>;

/** One instance per backend process; reuse across all approved Platform services.
 * Launch identity and local user authorization remain the host's responsibility.
 */
export function createPlatformClient(options: PlatformClientOptions) {
  if ("window" in globalThis) throw new PlatformServiceError("configuration_required");
  let origin: string;
  try {
    const url = new URL(options.platformUrl);
    if (url.protocol !== "https:" || url.username || url.password ||
        url.search || url.hash || (url.pathname !== "/" && url.pathname !== "")) throw new Error();
    origin = url.origin;
  } catch {
    throw new PlatformServiceError("configuration_required");
  }
  if (!options.applicationId?.trim() || !options.applicationSecret?.trim()) {
    throw new PlatformServiceError("configuration_required");
  }
  const timeout = options.timeoutMs ?? 10000;
  if (!Number.isFinite(timeout) || timeout < 1 || timeout > 60000) {
    throw new PlatformServiceError("configuration_required");
  }
  const transport = options.fetch ?? globalThis.fetch;
  let cached: { token: string; expiresAt: number } | undefined;
  let loginPromise: Promise<{ token: string; expiresAt: number }> | undefined;

  async function send(path: string, init: RequestInit, requestTimeout = timeout): Promise<Response> {
    try {
      return await transport(`${origin}${path}`, {
        ...init, redirect: "error", credentials: "omit",
        cache: "no-store", signal: AbortSignal.timeout(requestTimeout),
      });
    } catch {
      throw new PlatformServiceError("unavailable");
    }
  }

  function errorFor(status: number): PlatformServiceError {
    const code = status === 401 ? "unauthorized" : status === 403 ? "forbidden" :
      status === 400 ? "invalid_request" : status === 429 ? "rate_limited" : "unavailable";
    return new PlatformServiceError(code, status);
  }

  async function parse<T>(response: Response, schema: z.ZodType<T>): Promise<T> {
    if (!response.ok) throw errorFor(response.status);
    try {
      return schema.parse(await response.json());
    } catch {
      throw new PlatformServiceError("invalid_response", response.status);
    }
  }

  async function session() {
    if (cached && cached.expiresAt > Date.now() + 60000) return cached;
    if (!loginPromise) {
      loginPromise = (async () => {
        const response = await send("/api/bridge/login", {
          method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ applicationKey: options.applicationId, sharedSecret: options.applicationSecret }),
        });
        const data = await parse(response, sessionSchema);
        const expiresAt = Date.parse(data.expiresAt);
        if (expiresAt <= Date.now() + 60000) throw new PlatformServiceError("invalid_response");
        cached = { token: data.token, expiresAt };
        return cached;
      })();
    }
    try { return await loginPromise; }
    finally { loginPromise = undefined; }
  }

  // Only fixed, SDK-owned paths may receive credentials; never accept arbitrary URLs.
  async function read<T>(path: string, schema: z.ZodType<T>, body?: unknown): Promise<T> {
    const init = (token: string): RequestInit => ({
      method: body === undefined ? "GET" : "POST",
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json",
        ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    const requestTimeout = body === undefined ? timeout : Math.max(timeout, 30000);
    let identity = await session();
    let response = await send(path, init(identity.token), requestTimeout);
    if (response.status === 401) {
      // Do not discard a newer session obtained by a concurrent request.
      if (cached === identity) cached = undefined;
      identity = await session();
      response = await send(path, init(identity.token), requestTimeout);
      if (response.status === 401 && cached === identity) cached = undefined;
    }
    return parse(response, schema);
  }

  return {
    ai: {
      async generateText(input: AiTextRequest) {
        const parsed = aiTextRequestSchema.safeParse(input);
        if (!parsed.success) throw new PlatformServiceError("invalid_request");
        return read("/api/platform/ai/generate-text", aiTextResultSchema, parsed.data);
      },
      async generateStructured(input: AiStructuredRequest) {
        const parsed = aiStructuredRequestSchema.safeParse(input);
        if (!parsed.success) throw new PlatformServiceError("invalid_request");
        const result = await read("/api/platform/ai/generate-structured", aiStructuredResultSchema, parsed.data);
        if (!matchesAiSchema(parsed.data.schema, result.data)) throw new PlatformServiceError("invalid_response");
        return result;
      },
    },
    authorizedUsers: {
      async search(input: { q?: string; limit?: number; offset?: number } = {}): Promise<AuthorizedUsersSearchResult> {
        const valid = z.object({
          q: z.string().max(100).optional(),
          limit: z.number().int().min(1).max(100).optional(),
          offset: z.number().int().min(0).max(10000).optional(),
        }).strict().safeParse(input);
        if (!valid.success) throw new PlatformServiceError("invalid_request");
        const query = new URLSearchParams();
        for (const [key, value] of Object.entries(valid.data)) if (value !== undefined) query.set(key, String(value));
        return read(`/api/platform/applications/self/authorized-users?${query}`, searchSchema);
      },
      async resolve(stableUserId: string): Promise<AuthorizedUserResolution> {
        if (!userSchema.shape.stableUserId.safeParse(stableUserId).success) {
          throw new PlatformServiceError("invalid_request");
        }
        const result = await read(`/api/platform/applications/self/authorized-users/${stableUserId}`, resolveSchema);
        if (result.valid && result.user.stableUserId !== stableUserId) throw new PlatformServiceError("invalid_response");
        return result;
      },
    },
    /** Health-check helper for this capability, not proof that every service is enabled.
     * Performs a live authorized read; never returns user data or service tokens.
     */
    async checkAuthorizedUsers(): Promise<{ status: "ready" | "configuration_required" | "connection_failed"; code?: PlatformErrorCode }> {
      try {
        await read("/api/platform/applications/self/authorized-users?limit=1", searchSchema);
        return { status: "ready" };
      } catch (error) {
        if (!(error instanceof PlatformServiceError)) throw error;
        return {
          status: ["unauthorized", "forbidden", "configuration_required"].includes(error.code) ?
            "configuration_required" : "connection_failed",
          code: error.code,
        };
      }
    },
  };
}

export type PlatformClient = ReturnType<typeof createPlatformClient>;